import type { Metadata, Viewport } from "next";
import { Inter, Poppins, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import ServiceWorkerRegister from "@/components/ServiceWorkerRegister";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ChatVerse — AI Assistant by Mohammed Zayyan",
  description:
    "ChatVerse is an AI chat assistant built by Mohammed Zayyan. Chat, create images, generate videos, upload photos, make voice & video calls, and more.",
  keywords: [
    "AI Chat",
    "ChatVerse",
    "AI Assistant",
    "Mohammed Zayyan",
  ],
  authors: [{ name: "Mohammed Zayyan" }],
  manifest: "/manifest.json",
  applicationName: "ChatVerse AI",
  icons: {
    icon: [
      { url: "/chatverse-logo.png", sizes: "229x205", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
      { url: "/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: ["/icon-192.png"],
  },
  openGraph: {
    title: "ChatVerse — AI Assistant",
    description: "AI chat assistant built by Mohammed Zayyan.",
    siteName: "ChatVerse",
    type: "website",
    images: ["/chatverse-logo.png"],
  },
  // Apple mobile web app capabilities (PWA-style full screen on iOS)
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "ChatVerse AI",
  },
  // Prevent iOS from auto-detecting phone numbers as links (avoids random tap targets)
  formatDetection: {
    telephone: false,
  },
};

// Mobile-friendly viewport — uses dynamic viewport height (dvh) + safe-area-insets
// so iOS Safari address bar + iPhone notch don't hide content.
// (Next.js requires viewport to be in its own export, not in metadata.)
// We allow pinch-zoom (userScalable: true) so users can zoom in on small screens
// if the UI feels too small — this fixes the "minimized page" complaint on some Androids.
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  minimumScale: 0.8,
  maximumScale: 2,
  userScalable: true,
  viewportFit: "cover",
  themeColor: "#05070d",
};

// --- Register the service worker for PWA install + offline support ---
// (Moved to a client component: src/components/ServiceWorkerRegister.tsx)

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="application-name" content="ChatVerse AI" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="ChatVerse AI" />
        <meta name="theme-color" content="#05070d" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" href="/chatverse-logo.png" />
        <link rel="shortcut icon" href="/icon-192.png" />
      </head>
      <body
        className={`${inter.variable} ${poppins.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
