import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const maxDuration = 15

// GET /api/web-search?q=<query>
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const query = url.searchParams.get('q') || ''
    if (!query) {
      return NextResponse.json({ ok: false, error: 'Query is required' }, { status: 400 })
    }

    const results: Array<{ title: string; description: string; url: string }> = []

    // 1. Try Wikipedia
    try {
      const wikiRes = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`,
        { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; ChatVerse/1.0)' }, cache: 'no-store', signal: AbortSignal.timeout(8000) }
      )
      if (wikiRes.ok) {
        const wikiData = await wikiRes.json()
        if (wikiData.title && wikiData.extract && wikiData.type !== 'disambiguation') {
          results.push({
            title: wikiData.title,
            description: wikiData.extract,
            url: wikiData.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(query)}`,
          })
        }
      }
    } catch {}

    // 2. Try Wikipedia search API for related articles
    if (results.length < 3) {
      try {
        const searchRes = await fetch(
          `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=5`,
          { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; ChatVerse/1.0)' }, cache: 'no-store', signal: AbortSignal.timeout(8000) }
        )
        const searchData = await searchRes.json()
        const searchResults = searchData?.query?.search || []
        for (const r of searchResults) {
          if (results.length >= 5) break
          // Skip if already added
          if (results.find(x => x.title === r.title)) continue
          // Get summary for this article
          try {
            const summaryRes = await fetch(
              `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(r.title)}`,
              { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; ChatVerse/1.0)' }, cache: 'no-store', signal: AbortSignal.timeout(5000) }
            )
            if (summaryRes.ok) {
              const summaryData = await summaryRes.json()
              if (summaryData.extract) {
                results.push({
                  title: summaryData.title || r.title,
                  description: summaryData.extract,
                  url: summaryData.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodeURIComponent(r.title)}`,
                })
              }
            }
          } catch {}
        }
      } catch {}
    }

    // 3. Try DuckDuckGo as last resort
    if (results.length === 0) {
      try {
        const ddgRes = await fetch(
          `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`,
          { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; ChatVerse/1.0)' }, cache: 'no-store', signal: AbortSignal.timeout(8000) }
        )
        const ddgData = await ddgRes.json()
        if (ddgData.AbstractText) {
          results.push({
            title: ddgData.Heading || query,
            description: ddgData.Abstract,
            url: ddgData.AbstractURL || '',
          })
        }
        if (ddgData.RelatedTopics) {
          for (const topic of ddgData.RelatedTopics) {
            if (results.length >= 5) break
            if (topic.Text && topic.FirstURL) {
              results.push({ title: topic.Text.split(' - ')[0]?.slice(0, 80) || 'Result', description: topic.Text, url: topic.FirstURL })
            }
          }
        }
      } catch {}
    }

    if (results.length === 0) {
      return NextResponse.json({ ok: false, error: `No results found for "${query}"` }, { status: 404 })
    }

    return NextResponse.json({ ok: true, query, results, answer: results[0]?.description || '' })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'Search failed' }, { status: 500 })
  }
}
