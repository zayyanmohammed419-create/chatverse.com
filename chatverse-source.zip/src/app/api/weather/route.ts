import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const maxDuration = 15

// GET /api/weather?city=London
// Fetches weather from wttr.in (free, no API key needed)
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const city = url.searchParams.get('city') || 'Dubai'

    const res = await fetch(
      `https://wttr.in/${encodeURIComponent(city)}?format=j1`,
      { headers: { 'User-Agent': 'ChatVerse/1.0' }, cache: 'no-store' }
    )

    if (!res.ok) {
      return NextResponse.json({ ok: false, error: `Weather data not available for "${city}"` }, { status: 502 })
    }

    const data = await res.json()
    const current = data.current_condition?.[0]
    const area = data.nearest_area?.[0]

    if (!current) {
      return NextResponse.json({ ok: false, error: 'No weather data found' }, { status: 404 })
    }

    const weatherDesc = current.weatherDesc?.[0]?.value?.trim() || 'Unknown'
    const tempC = parseInt(current.temp_C || '0')
    const feelsLikeC = parseInt(current.FeelsLikeC || '0')
    const humidity = parseInt(current.humidity || '0')
    const windSpeed = parseInt(current.windspeedKmph || '0')

    // Map weather codes to emoji
    const code = parseInt(current.weatherCode || '0')
    const weatherEmoji: Record<number, string> = {
      113: '☀️', 116: '⛅', 119: '☁️', 122: '☁️', 143: '🌫️',
      176: '🌦️', 179: '🌨️', 182: '🌧️', 185: '🌧️',
      200: '⛈️', 227: '🌨️', 230: '❄️',
      248: '🌫️', 260: '🌫️',
      263: '🌦️', 266: '🌦️', 281: '🌧️', 284: '🌧️',
      293: '🌦️', 296: '🌧️', 299: '🌧️', 302: '🌧️', 305: '🌧️', 308: '🌧️',
      311: '🌧️', 314: '🌧️', 317: '🌨️', 320: '🌨️',
      323: '🌨️', 326: '🌨️', 329: '❄️', 332: '❄️', 335: '❄️', 338: '❄️',
      350: '🌧️', 353: '🌦️', 356: '🌧️', 359: '🌧️',
      362: '🌨️', 365: '🌨️',
      368: '🌨️', 371: '❄️',
      374: '🌨️', 377: '🌨️',
      386: '🌦️', 389: '🌧️', 392: '🌨️', 395: '❄️',
    }
    const emoji = weatherEmoji[code] || '🌤️'

    // Build 3-day forecast
    const daily: Array<{ date: string; max: number; min: number; desc: string; emoji: string }> = []
    if (data.weather) {
      for (let i = 0; i < Math.min(3, data.weather.length); i++) {
        const w = data.weather[i]
        const maxTemp = parseInt(w.maxtempC || '0')
        const minTemp = parseInt(w.mintempC || '0')
        const avgCode = parseInt(w.hourly?.[4]?.weatherCode || '0')
        const desc = w.hourly?.[4]?.weatherDesc?.[0]?.value?.trim() || 'Unknown'
        const dayEmoji = weatherEmoji[avgCode] || '🌤️'
        daily.push({ date: w.date, max: maxTemp, min: minTemp, desc, emoji: dayEmoji })
      }
    }

    return NextResponse.json({
      ok: true,
      city: area?.areaName?.[0]?.value || city,
      region: area?.region?.[0]?.value || '',
      country: area?.country?.[0]?.value || '',
      temperature: tempC,
      feelsLike: feelsLikeC,
      humidity,
      windSpeed,
      description: weatherDesc,
      emoji,
      daily,
    })
  } catch (err: any) {
    console.error('[api/weather] error:', err)
    return NextResponse.json({ ok: false, error: err?.message || 'Failed to fetch weather' }, { status: 500 })
  }
}
