import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const maxDuration = 30

// GET /api/news?category=technology
// GET /api/news?category=country&q=AE      (Google News RSS for the user's country)
// Fetches real-time news from free RSS feeds
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const category = url.searchParams.get('category') || 'general'
    const query = url.searchParams.get('q') || ''

    // RSS feed URLs (free, no API key needed)
    const feeds: Record<string, string> = {
      general: 'https://feeds.bbci.co.uk/news/world/rss.xml',
      technology: 'https://feeds.bbci.co.uk/news/technology/rss.xml',
      business: 'https://feeds.bbci.co.uk/news/business/rss.xml',
      science: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml',
      health: 'https://feeds.bbci.co.uk/news/health/rss.xml',
      // BBC region feeds (for "country" of staying)
      middle_east: 'https://feeds.bbci.co.uk/news/world/middle_east/rss.xml',
      asia: 'https://feeds.bbci.co.uk/news/world/asia/rss.xml',
      europe: 'https://feeds.bbci.co.uk/news/world/europe/rss.xml',
      us_canada: 'https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml',
      africa: 'https://feeds.bbci.co.uk/news/world/africa/rss.xml',
      latin_america: 'https://feeds.bbci.co.uk/news/world/latin_america/rss.xml',
    }

    let feedUrl: string
    if (category === 'country' && query) {
      // Google News RSS for a specific country (uses 2-letter country code: AE, US, IN, GB, etc.)
      const cc = query.toUpperCase()
      feedUrl = `https://news.google.com/rss?hl=en&gl=${cc}&ceid=${cc}:en`
    } else {
      feedUrl = feeds[category] || feeds.general
    }

    const res = await fetch(feedUrl, {
      headers: { 'User-Agent': 'ChatVerse/1.0' },
      cache: 'no-store',
    })

    if (!res.ok) {
      return NextResponse.json({ ok: false, error: 'Failed to fetch news' }, { status: 502 })
    }

    const xml = await res.text()

    // Simple RSS XML parser (extract <item> elements)
    const items: Array<{ title: string; description: string; link: string; pubDate: string; source?: string }> = []
    const itemRegex = /<item>([\s\S]*?)<\/item>/g
    let match: RegExpExecArray | null

    while ((match = itemRegex.exec(xml)) !== null && items.length < 10) {
      const itemXml = match[1]
      const title = itemXml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/)?.[1] || itemXml.match(/<title>(.*?)<\/title>/)?.[1] || ''
      const desc = itemXml.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>/)?.[1] || itemXml.match(/<description>(.*?)<\/description>/)?.[1] || ''
      const link = itemXml.match(/<link>(.*?)<\/link>/)?.[1] || ''
      const pubDate = itemXml.match(/<pubDate>(.*?)<\/pubDate>/)?.[1] || ''
      const source = itemXml.match(/<source[^>]*>(.*?)<\/source>/)?.[1] || ''

      // Strip HTML from description
      const cleanDesc = desc.replace(/<[^>]+>/g, '').trim().slice(0, 200)

      if (title) {
        items.push({ title, description: cleanDesc, link, pubDate, source: source || undefined })
      }
    }

    // Filter by query if provided (only used for non-country categories now)
    const filtered = (query && category !== 'country')
      ? items.filter((i) => i.title.toLowerCase().includes(query.toLowerCase()) || i.description.toLowerCase().includes(query.toLowerCase()))
      : items

    return NextResponse.json({ ok: true, news: filtered, category })
  } catch (err: any) {
    console.error('[api/news] error:', err)
    return NextResponse.json({ ok: false, error: err?.message || 'Failed to fetch news' }, { status: 500 })
  }
}
