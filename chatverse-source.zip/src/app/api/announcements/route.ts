import { NextRequest, NextResponse } from 'next/server'

// --- Owners ---
// Main owner: Mohammed Zayyan
// These tokens are simple shared secrets the frontend sends as ?owner=... or in body.
// (For a school project this is fine — not real security, just access control for the demo.)

const OWNERS: Record<string, { name: string; role: string }> = {
  mohammed: { name: 'Mohammed Zayyan', role: 'Main Owner' },
}

function isOwner(token: string | undefined): { ok: boolean; owner?: { name: string; role: string } } {
  if (!token) return { ok: false }
  const t = token.toLowerCase()
  if (OWNERS[t]) return { ok: true, owner: OWNERS[t] }
  return { ok: false }
}

interface Announcement {
  id: string
  text: string
  authorName: string
  authorRole: string
  createdAt: number
}

// --- In-memory announcement store (most recent first) ---
const announcements: Announcement[] = []
const MAX_ANNOUNCEMENTS = 50

export async function GET() {
  return NextResponse.json({
    ok: true,
    announcements: announcements.slice(0, 10), // return latest 10
    owners: Object.entries(OWNERS).map(([token, o]) => ({
      token,
      name: o.name,
      role: o.role,
    })),
  })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const ownerToken = (body?.ownerToken || '').toString().trim()
    const text = (body?.text || '').toString().trim()

    const check = isOwner(ownerToken)
    if (!check.ok || !check.owner) {
      return NextResponse.json(
        { ok: false, error: 'Only owners can post announcements.' },
        { status: 403 }
      )
    }
    if (!text) {
      return NextResponse.json({ ok: false, error: 'Announcement text is required.' }, { status: 400 })
    }
    if (text.length > 280) {
      return NextResponse.json(
        { ok: false, error: 'Announcement too long (max 280 characters).' },
        { status: 400 }
      )
    }

    const a: Announcement = {
      id: Math.random().toString(36).slice(2, 10),
      text,
      authorName: check.owner.name,
      authorRole: check.owner.role,
      createdAt: Date.now(),
    }
    announcements.unshift(a)
    if (announcements.length > MAX_ANNOUNCEMENTS) {
      announcements.length = MAX_ANNOUNCEMENTS
    }

    return NextResponse.json({ ok: true, announcement: a })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const ownerToken = url.searchParams.get('ownerToken') || ''
    const id = url.searchParams.get('id') || ''
    const check = isOwner(ownerToken)
    if (!check.ok) {
      return NextResponse.json(
        { ok: false, error: 'Only owners can delete announcements.' },
        { status: 403 }
      )
    }
    const idx = announcements.findIndex((a) => a.id === id)
    if (idx === -1) {
      return NextResponse.json({ ok: false, error: 'Announcement not found.' }, { status: 404 })
    }
    announcements.splice(idx, 1)
    return NextResponse.json({ ok: true })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
