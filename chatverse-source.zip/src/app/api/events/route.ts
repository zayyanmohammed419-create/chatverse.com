import { NextRequest, NextResponse } from 'next/server'

// --- Events store (in-memory) ---
export interface EventItem {
  id: string
  title: string
  description: string
  date: string // ISO date string (e.g. "2026-10-30")
  time: string // 24-hour time (e.g. "18:30")
  authorName: string
  authorRole: string
  createdAt: number
}

const events: EventItem[] = []
const MAX_EVENTS = 100

// --- Owner tokens ---
const OWNERS: Record<string, { name: string; role: string }> = {
  mohammed: { name: 'Mohammed Zayyan', role: 'Main Owner' },
}
function isOwnerToken(t: string | undefined | null): boolean {
  if (!t) return false
  return !!OWNERS[t.toLowerCase()]
}
function ownerInfo(t: string | undefined | null) {
  if (!t) return null
  return OWNERS[t.toLowerCase()] || null
}

// GET /api/events — public, returns events sorted by upcoming date (most recent first)
export async function GET() {
  const sorted = [...events].sort((a, b) => {
    const aDate = new Date(`${a.date}T${a.time || '00:00'}`).getTime()
    const bDate = new Date(`${b.date}T${b.time || '00:00'}`).getTime()
    return bDate - aDate // most recent first
  })
  return NextResponse.json({ ok: true, events: sorted.slice(0, 20) })
}

// POST /api/events  { ownerToken, title, description, date, time }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()
    const title = (body?.title || '').toString().trim()
    const description = (body?.description || '').toString().trim()
    const date = (body?.date || '').toString().trim()
    const time = (body?.time || '').toString().trim()

    if (!isOwnerToken(ownerToken)) {
      return NextResponse.json({ ok: false, error: 'Only owners can post events' }, { status: 403 })
    }
    const info = ownerInfo(ownerToken)
    if (!info) {
      return NextResponse.json({ ok: false, error: 'Invalid owner token' }, { status: 403 })
    }
    if (!title) {
      return NextResponse.json({ ok: false, error: 'Event title is required' }, { status: 400 })
    }
    if (title.length > 80) {
      return NextResponse.json({ ok: false, error: 'Title too long (max 80 chars)' }, { status: 400 })
    }
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return NextResponse.json({ ok: false, error: 'Date is required (YYYY-MM-DD)' }, { status: 400 })
    }
    if (time && !/^\d{2}:\d{2}$/.test(time)) {
      return NextResponse.json({ ok: false, error: 'Time must be in HH:MM 24-hour format' }, { status: 400 })
    }
    if (description.length > 280) {
      return NextResponse.json({ ok: false, error: 'Description too long (max 280 chars)' }, { status: 400 })
    }

    const evt: EventItem = {
      id: Math.random().toString(36).slice(2, 10),
      title,
      description,
      date,
      time: time || '00:00',
      authorName: info.name,
      authorRole: info.role,
      createdAt: Date.now(),
    }
    events.unshift(evt)
    if (events.length > MAX_EVENTS) events.length = MAX_EVENTS

    return NextResponse.json({ ok: true, event: evt })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}

// DELETE /api/events?id=...&ownerToken=...
export async function DELETE(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const ownerToken = (url.searchParams.get('ownerToken') || '').toLowerCase()
    const id = url.searchParams.get('id') || ''
    if (!isOwnerToken(ownerToken)) {
      return NextResponse.json({ ok: false, error: 'Only owners can delete events' }, { status: 403 })
    }
    const idx = events.findIndex((e) => e.id === id)
    if (idx === -1) {
      return NextResponse.json({ ok: false, error: 'Event not found' }, { status: 404 })
    }
    events.splice(idx, 1)
    return NextResponse.json({ ok: true })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
