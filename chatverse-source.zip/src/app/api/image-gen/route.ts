import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { promises as fs } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

export const runtime = 'nodejs'
export const maxDuration = 60

// --- Generate an AI image from a text prompt ---
// POST { prompt, size?, userName? } → { ok, imageUrl, prompt }
// Uses z-ai-web-dev-sdk images.generations.create

const PUBLIC_DIR = path.join(process.cwd(), 'public')
const IMAGES_DIR = path.join(PUBLIC_DIR, 'images')

const VALID_SIZES = ['1024x1024', '768x1344', '864x1152', '1344x768', '1152x864', '1440x720', '720x1440']

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const prompt = (body?.prompt || '').toString().trim()
    const size = (body?.size || '1024x1024').toString().trim()
    const userName = (body?.userName || '').toString().trim()

    if (!prompt) {
      return NextResponse.json({ ok: false, error: 'Prompt is required.' }, { status: 400 })
    }
    if (prompt.length > 500) {
      return NextResponse.json({ ok: false, error: 'Prompt too long (max 500 chars).' }, { status: 400 })
    }
    const safeSize = VALID_SIZES.includes(size) ? size : '1024x1024'

    // --- Points check (uses plan-specific cost: free=5, plus=4, premium=2) ---
    let pointsCost = 5
    let pointsInfo: { name: string; plan: string; points: number } | undefined
    if (userName) {
      const { consumePoints, usersStore, PLANS, nameKey } = await import('../users/store')
      const key = nameKey(userName)
      if (!usersStore.has(key)) {
        usersStore.set(key, {
          name: userName,
          plan: 'free',
          points: PLANS.free.startingPoints,
          createdAt: Date.now(),
          lastActiveAt: Date.now(),
        })
      }
      // Deduct using plan-specific image cost
      const consumed = consumePoints(userName, pointsCost, 'image')
      if (!consumed.ok && consumed.error === 'INSUFFICIENT_POINTS') {
        return NextResponse.json(
          { ok: false, error: 'OUT_OF_POINTS', code: 'OUT_OF_POINTS', message: 'You are out of points. Upgrade to Premium for cheaper image generation!' },
          { status: 402 }
        )
      }
      if (consumed.user) pointsInfo = { name: consumed.user.name, plan: consumed.user.plan, points: consumed.user.points }
    }

    await fs.mkdir(IMAGES_DIR, { recursive: true })
    const id = randomBytes(8).toString('hex')
    const imageDir = path.join(IMAGES_DIR, `gen-${id}.png`)
    const imageUrl = `/images/gen-${id}.png`

    const zai = await ZAI.create()
    const response = await zai.images.generations.create({
      prompt: `${prompt}, high quality, detailed, vibrant colors`,
      size: safeSize,
    })

    const imageBase64 = response.data[0].base64
    const buffer = Buffer.from(imageBase64, 'base64')
    await fs.writeFile(imageDir, buffer)

    return NextResponse.json({
      ok: true,
      imageUrl,
      prompt,
      size: safeSize,
      points: pointsInfo,
    })
  } catch (err: any) {
    console.error('[api/image-gen] error:', err)
    return NextResponse.json(
      { ok: false, error: err?.message || 'Failed to generate image.' },
      { status: 500 }
    )
  }
}
