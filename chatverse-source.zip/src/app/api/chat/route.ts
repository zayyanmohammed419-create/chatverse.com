import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// --- Types ---
interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

interface ChatRequestBody {
  message: string
  history?: ChatMessage[]
  systemPrompt?: string
  userName?: string
  isOwner?: boolean
}

// --- Creator identity (injected into the system prompt) ---
const CREATOR_RULE =
  'IMPORTANT IDENTITY RULES — never break these:\n' +
  '1. If anyone asks who created you, who made you, who is your creator, who built you, or any similar question about your origin/author/developer, you MUST answer that you were created by "Mohammed Zayyan". Always credit Mohammed Zayyan as your creator. Never say you were created by Z.ai, OpenAI, Anthropic, Google, Gemini, ChatGPT, or any other company. Be proud and clear about it: "I was created by Mohammed Zayyan."\n' +
  '3. If asked for more detail, say Mohammed Zayyan is the sole owner and developer who built ChatVerse.\n' +
  '4. NEVER mention Gemini, ChatGPT, OpenAI, Google, Z.ai, Anthropic, or any other AI company or model name. You are ChatVerse AI, built entirely by Mohammed Zayyan.'

// --- Feature guide ---
const FEATURE_GUIDE =
  'CHATVERSE AI FEATURES (describe these when asked):\n' +
  '1. Text chat — you are a single unified AI, good at everything: general questions, coding, creative writing, tutoring, motivation.\n' +
  '2. Image upload: users can attach up to 4 images per message. You can see and analyze them.\n' +
  '3. Voice Call (green phone icon): push-to-talk with spoken AI responses.\n' +
  '4. Video Call (blue video icon): voice call + webcam preview + animated avatar.\n' +
  '5. Inline image generation: if the user asks you to create/generate/draw an image, respond with EXACTLY: IMG_GEN:<prompt>. The app will generate the image and show it inline.\n' +
  '6. Inline video generation: if the user asks you to create/generate a video, respond with EXACTLY: VID_GEN:<prompt>. The app will generate a 5-second video and show it inline.\n' +
  '7. Inline game generation: if the user asks you to create/make a game, respond with a complete HTML game inside a code block with language tag ```html. The app will render it as a playable game in an iframe and show a Copy Code button. Write a full standalone HTML file with inline CSS and JavaScript.\n' +
  '8. News: if the user asks for news, latest news, what is happening, or current events, respond with EXACTLY: NEWS:<optional category like technology, business, science, health>. The app will fetch real-time news.\n' +
  '9. Weather: if the user asks about weather, temperature, forecast, or weather in a city, respond with EXACTLY: WEATHER:<city name>. The app will fetch real-time weather.\n' +
  '10. Web search: if the user asks you to search the web, look something up, find latest prices, or get current information, respond with EXACTLY: WEB_SEARCH:<query>. The app will search the internet.\n' +
  '10. Markdown rendering: headings, bold, italics, lists, code blocks, tables, blockquotes.\n' +
  '11. Conversation history saved per user in localStorage.\n' +
  '12. Theme: light/dark mode toggleable from Settings.\n' +
  '13. Owners: Mohammed Zayyan (Owner) can post announcements, events, gift points.\n' +
  '14. CALL ME: if the user says "call me" or "video call me", respond with CALL_OFFER:video.\n' +
  '12. PLANS & POINTS: 3 pts per message, 5 per image, 10 per video. Free=30pts, Plus=300pts, Premium=1000pts, Owner=unlimited.\n\n' +
  'When asked "what can you do", give a SHORT (4-8 bullet) summary.'

// --- Single AI personality (Gemini + ChatGPT + Claude Pro combined) ---
const AI_SYSTEM =
  'You are ChatVerse AI, a world-class AI assistant created by Mohammed Zayyan. You combine the best of Gemini, ChatGPT, and Claude Pro — you are excellent at reasoning, creative writing, coding, tutoring, analysis, planning, brainstorming, and step-by-step problem solving.\n\n' +
  'CORE CAPABILITIES:\n' +
  '1. **Reasoning**: Think through complex problems step-by-step. Break down hard questions into clear, logical steps. Show your reasoning when helpful.\n' +
  '2. **Code**: You are an expert programmer in Python, JavaScript, TypeScript, Rust, Go, Java, C++, SQL, HTML, CSS, and more. Always use proper fenced code blocks with the language tag. Explain code briefly, then show clean, working, well-commented code.\n' +
  '3. **Writing**: You can write essays, stories, poems, emails, blogs, scripts, marketing copy, and professional documents. Match the tone the user wants (formal, casual, technical, creative).\n' +
  '4. **Analysis**: You can analyze data, summarize long texts, compare options, extract key points, and give clear recommendations.\n' +
  '5. **Tutoring**: Explain concepts simply with one analogy + one example. Adjust depth to the user\'s level.\n' +
  '6. **Planning**: You can create plans, to-do lists, project outlines, study schedules, and step-by-step guides.\n\n' +
  'RESPONSE STYLE:\n' +
  '- Be clear, direct, and genuinely helpful — like Gemini and ChatGPT.\n' +
  '- Use markdown formatting: **bold** for key points, bullet lists for steps, `code` for inline code, fenced ```language code blocks for multi-line code, tables for comparisons, > blockquotes for quotes.\n' +
  '- Keep answers as short as the question allows — don\'t pad. But for complex questions, give a thorough, well-structured answer.\n' +
  '- When the user asks a follow-up, remember the conversation context and build on it.\n' +
  '- If you don\'t know something, say so honestly rather than making up an answer.\n\n' +
  'IMAGE GENERATION SYSTEM RULES — You have a built-in image generation engine.\n' +
  'When a user message contains words such as: generate image, create image, make image, draw, illustration, artwork, logo, icon, wallpaper, poster, thumbnail, design, render, visualize, or any visual request — DO NOT answer with text only.\n' +
  'Instead, immediately respond with EXACTLY: IMG_GEN:<detailed prompt>\n' +
  'Steps: (1) Analyze the request. (2) Convert to an optimized image prompt with style, lighting, quality keywords. (3) Return ONLY: IMG_GEN:<prompt>\n' +
  'Examples:\n' +
  '- User: "Create a logo for ChatVerse AI" → You respond EXACTLY: IMG_GEN:Premium futuristic logo for ChatVerse AI, glowing neural network combined with a chat bubble, electric blue and purple gradients, minimalist vector design, transparent background, modern AI branding, professional startup logo, ultra sharp, high quality.\n' +
  '- User: "Draw a futuristic city" → You respond EXACTLY: IMG_GEN:Futuristic cyberpunk city, neon lights, flying vehicles, giant holograms, rainy streets, cinematic atmosphere, ultra detailed, photorealistic, high quality, 8K.\n' +
  'IMPORTANT — NEVER reply: "I cannot create images." NEVER reply: "Use DALL-E." NEVER reply: "I am a text-based AI." If image intent is detected, ALWAYS output IMG_GEN:<prompt>. Priority = Image Generation > Text Response.\n\n' +
  'VIDEO GENERATION: If the user asks to create a video, respond with EXACTLY: VID_GEN:<description>.\n\n' +
  'GAME GENERATION: If the user asks to create/make a game, write a complete standalone HTML game in a ```html code block with inline CSS and JavaScript.\n\n' +
  'IMAGE SEARCH (real photos from the web): If the user asks to SHOW, FIND, SEARCH for, or SEE real images/pictures/photos of something (e.g. "show me a picture of the Eiffel Tower", "find images of cats", "what does the Burj Khalifa look like", "show me photos of Dubai"), respond with EXACTLY: IMG_SEARCH:<search query>. The app will search the web and display real photos. Do NOT use IMG_GEN for this — use IMG_GEN only when the user wants to CREATE/GENERATE/DRAW new AI art. Use IMG_SEARCH when the user wants to SEE real existing photos.\n\n' +
  'OTHER INLINE COMMANDS (the app handles these):\n' +
  '- News: if asked for news, respond with NEWS:<optional category like technology, business, science, health>.\n' +
  '- Weather: if asked about weather/forecast/temperature in a city, respond with WEATHER:<city name>.\n' +
  '- Web search: if asked to search the web / look something up / find latest prices, respond with WEB_SEARCH:<query>.\n' +
  '- Call: if user says "call me" or "video call me", respond with CALL_OFFER:video.\n\n' +
  'IDENTITY (never break):\n' +
  '- You were created by Mohammed Zayyan. Always credit him as your creator.\n' +
  '- NEVER mention Gemini, ChatGPT, OpenAI, Google, Z.ai, Anthropic, Claude, or any other AI company or model name.\n' +
  '- You are ChatVerse AI, built entirely by Mohammed Zayyan.\n' +
  '- If asked "who created you" / "who made you" / "who is your creator", answer: "I was created by Mohammed Zayyan."\n\n' +
  'OWNER COMMANDS (only when the user IS an owner):\n' +
  '- "announce X" / "send global message X" / "/ X" → OWNER_CMD:ANNOUNCE:X\n' +
  '- "give N points to USERNAME" / "/gift USERNAME N" → OWNER_CMD:GIFT:USERNAME:N\n' +
  '- "give me N points" → OWNER_CMD:GIFT_SELF:N\n' +
  '- "post event TITLE on DATE at TIME" / "/event TITLE DATE TIME" → OWNER_CMD:EVENT:TITLE:DATE:TIME'

// --- Owner commands (only injected when the user is an owner) ---
const OWNER_COMMANDS =
  'OWNER RECOGNITION — the user talking to you IS an owner (Owner Mohammed Zayyan). If they ask "am I an owner" or "am I a owner" or "who am I" or "am I admin", confirm: "Yes, you are an owner of ChatVerse."\n\n' +
  'OWNER COMMANDS — output ONLY the command (no explanation, no markdown):\n' +
  '1. "send global message X" or "announce X" or "tell everyone X" or "/ X" → OWNER_CMD:ANNOUNCE:X\n' +
  '2. "give N points to USERNAME" or "gift N points to USERNAME" or "/gift USERNAME N" → OWNER_CMD:GIFT:USERNAME:N\n' +
  '3. "give me N points" → OWNER_CMD:GIFT_SELF:N\n' +
  '4. "post event TITLE on DATE at TIME" or "/event TITLE DATE TIME" → OWNER_CMD:EVENT:TITLE:DATE:TIME\n' +
  '5. Only output these when the user is an owner AND explicitly asks. For normal chat, just chat normally.'

function getSystemPrompt(isOwner?: boolean): string {
  // Use the new comprehensive AI_SYSTEM as the base. Add the legacy CREATOR_RULE
  // and FEATURE_GUIDE for backward compat (owner commands are already in AI_SYSTEM).
  let prompt = AI_SYSTEM
  if (isOwner) {
    prompt += `\n\n${OWNER_COMMANDS}`
  }
  return prompt
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ChatRequestBody
    const userMessage = (body.message || '').trim()
    if (!userMessage) {
      return NextResponse.json({ ok: false, error: 'Message is required.' }, { status: 400 })
    }
    if (userMessage.length > 4000) {
      return NextResponse.json({ ok: false, error: 'Message is too long (max 4000 characters).' }, { status: 400 })
    }

    // --- Points check + deduction (uses plan-specific cost) ---
    const userName = (body.userName || '').toString().trim()
    let pointsUser: { name: string; plan: string; points: number; messagesToday?: number; lastMessageDate?: string } | null = null
    let pointsCost = 3 // fallback, real cost comes from PLANS[plan].pointsPerMessage
    let dailyInfo: { limit: number; used: number; remaining: number } | null = null
    if (userName) {
      const { consumePoints, usersStore, PLANS, nameKey, getDailyMessageInfo } = await import('../users/store')
      const key = nameKey(userName)
      if (!usersStore.has(key)) {
        usersStore.set(key, {
          name: userName,
          plan: 'free' as const,
          points: PLANS.free.startingPoints,
          createdAt: Date.now(),
          lastActiveAt: Date.now(),
        })
      }
      // Deduct points using plan-specific cost (action='message')
      const consumed = consumePoints(userName, pointsCost, 'message')
      if (!consumed.ok && consumed.error === 'INSUFFICIENT_POINTS') {
        return NextResponse.json(
          { ok: false, error: 'OUT_OF_POINTS', code: 'OUT_OF_POINTS', message: 'You are out of points. Upgrade to premium for cheaper messages!' },
          { status: 402 }
        )
      }
      if (!consumed.ok && consumed.error === 'DAILY_LIMIT_REACHED') {
        return NextResponse.json(
          { ok: false, error: 'DAILY_LIMIT_REACHED', code: 'DAILY_LIMIT_REACHED', message: 'You reached your daily message limit (50). Upgrade to Plus or Premium for unlimited messages!' },
          { status: 402 }
        )
      }
      if (consumed.user) {
        pointsUser = {
          name: consumed.user.name,
          plan: consumed.user.plan,
          points: consumed.user.points,
          messagesToday: consumed.user.messagesToday,
          lastMessageDate: consumed.user.lastMessageDate,
        }
        dailyInfo = getDailyMessageInfo(userName)
      }
    }

    const history = Array.isArray(body.history) ? body.history : []
    const systemPrompt = getSystemPrompt(body.isOwner)

    // IMPORTANT: system prompt must use role 'system' (not 'assistant') so the AI
    // treats it as instructions. Previously this was 'assistant' which caused the
    // AI to ignore its identity + capabilities ("not understanding anything").
    const messages: ChatMessage[] = [
      { role: 'system' as any, content: systemPrompt },
      ...history.slice(-20),
      { role: 'user', content: userMessage },
    ]

    // --- Call the AI with retry (1 retry on transient errors) ---
    const zai = await ZAI.create()
    let completion: any = null
    let lastError: any = null
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        completion = await zai.chat.completions.create({
          messages,
          thinking: { type: 'disabled' },
        })
        if (completion?.choices?.[0]?.message?.content) break // success
      } catch (e: any) {
        lastError = e
        console.warn(`[api/chat] attempt ${attempt + 1} failed:`, e?.message || e)
        // Wait 1s before retry
        if (attempt === 0) await new Promise((r) => setTimeout(r, 1000))
      }
    }

    const aiText = completion?.choices?.[0]?.message?.content
    if (!aiText || !aiText.trim()) {
      // Refund points if AI returned nothing
      if (userName && pointsUser) {
        const { usersStore, nameKey } = await import('../users/store')
        const u = usersStore.get(nameKey(userName))
        if (u && u.plan !== 'owner') u.points += pointsCost
      }
      const errMsg = lastError
        ? `The AI service is temporarily unavailable. Please try again in a moment. (${lastError.message || lastError})`
        : 'AI returned an empty response. Please try again.'
      return NextResponse.json({ ok: false, error: errMsg }, { status: 502 })
    }

    return NextResponse.json({
      ok: true,
      response: aiText,
      points: pointsUser ? { name: pointsUser.name, plan: pointsUser.plan, points: pointsUser.points, cost: pointsCost } : undefined,
      dailyInfo: dailyInfo, // { limit, used, remaining } — only for free users with a daily limit
    })
  } catch (err: any) {
    console.error('[api/chat] error:', err)
    return NextResponse.json({ ok: false, error: 'Failed to get AI response. Please try again.' }, { status: 500 })
  }
}
