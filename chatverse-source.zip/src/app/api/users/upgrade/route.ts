import { NextRequest, NextResponse } from 'next/server'
import { usersStore, publicUser, isOwnerToken, isValidPlanId, PLANS, type PlanId } from '../store'

// POST /api/users/upgrade  { ownerToken, userName, plan }
// Owner upgrades a user's plan for free.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()
    const userName = (body?.userName || '').toString().trim()
    const plan = body?.plan as PlanId

    if (!isOwnerToken(ownerToken)) {
      return NextResponse.json({ ok: false, error: 'Owner access required' }, { status: 403 })
    }
    if (!userName) {
      return NextResponse.json({ ok: false, error: 'userName is required' }, { status: 400 })
    }
    if (!isValidPlanId(plan)) {
      return NextResponse.json({ ok: false, error: 'Invalid plan. Use: free, plus, premium, or owner' }, { status: 400 })
    }
    if (plan === 'owner') {
      return NextResponse.json({ ok: false, error: 'Cannot promote a user to owner via this endpoint. Use the owner URL sign-in instead.' }, { status: 400 })
    }

    const key = userName.toLowerCase()
    const user = usersStore.get(key)
    if (!user) {
      return NextResponse.json({ ok: false, error: 'User not found' }, { status: 404 })
    }

    // Don't downgrade an owner
    if (user.plan === 'owner') {
      return NextResponse.json({ ok: false, error: 'Cannot downgrade an owner' }, { status: 400 })
    }

    // Upgrade plan + grant the new plan's starting points delta
    const oldPlan = user.plan
    user.plan = plan
    // If upgrading to a higher tier, top up to that tier's starting points (only if current balance is less)
    if (PLANS[plan].startingPoints > user.points) {
      user.points = PLANS[plan].startingPoints
    }
    return NextResponse.json({ ok: true, user: publicUser(user), previousPlan: oldPlan })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
