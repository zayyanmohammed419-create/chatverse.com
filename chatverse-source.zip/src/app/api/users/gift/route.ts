import { NextRequest, NextResponse } from 'next/server'
import { usersStore, publicUser, isOwnerToken } from '../store'

// POST /api/users/gift  { ownerToken, userName, points }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()
    const userName = (body?.userName || '').toString().trim()
    const points = Number(body?.points)

    if (!isOwnerToken(ownerToken)) {
      return NextResponse.json({ ok: false, error: 'Owner access required' }, { status: 403 })
    }
    if (!userName) {
      return NextResponse.json({ ok: false, error: 'userName is required' }, { status: 400 })
    }
    if (!Number.isFinite(points) || points === 0) {
      return NextResponse.json({ ok: false, error: 'points must be a non-zero number' }, { status: 400 })
    }

    const key = userName.toLowerCase()
    const user = usersStore.get(key)
    if (!user) {
      return NextResponse.json({ ok: false, error: 'User not found' }, { status: 404 })
    }
    if (user.plan === 'owner') {
      return NextResponse.json({ ok: false, error: 'Cannot gift points to an owner (unlimited)' }, { status: 400 })
    }

    user.points = Math.max(0, user.points + Math.floor(points))
    return NextResponse.json({ ok: true, user: publicUser(user) })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
