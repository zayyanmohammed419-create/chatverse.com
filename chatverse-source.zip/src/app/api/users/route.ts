import { NextRequest, NextResponse } from 'next/server'
import {
  PLANS,
  usersStore,
  normalizeName,
  nameKey,
  publicUser,
  isOwnerToken,
  type User,
} from './store'

// POST /api/users  { name, email?, ownerToken? }
// - Create user if not exists, or fetch existing.
// - If ownerToken matches an owner, the user is created/upgraded to 'owner' plan (unlimited points).
// - Otherwise, FREE plan + starting points.
// - email is optional, used for Google-styled sign-in display.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const name = normalizeName(body?.name || '')
    const email = (body?.email || '').toString().trim().toLowerCase()
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()

    if (!name) {
      return NextResponse.json({ ok: false, error: 'Name is required' }, { status: 400 })
    }
    if (name.length > 40) {
      return NextResponse.json({ ok: false, error: 'Name too long (max 40 chars)' }, { status: 400 })
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ ok: false, error: 'Invalid email format' }, { status: 400 })
    }

    const key = nameKey(name)
    const isOwner = isOwnerToken(ownerToken)

    let user = usersStore.get(key)
    if (!user) {
      user = {
        name,
        email: email || undefined,
        plan: isOwner ? 'owner' : 'free',
        points: isOwner ? 0 : PLANS.free.startingPoints,
        createdAt: Date.now(),
        lastActiveAt: Date.now(),
      }
      usersStore.set(key, user)
    } else if (isOwner && user.plan !== 'owner') {
      // Existing user but signing in as owner — upgrade to owner (unlimited)
      user.plan = 'owner'
      user.points = 0
    }
    // Always update email if provided (so re-login with email updates the stored email)
    if (email) user.email = email
    user.lastActiveAt = Date.now()

    return NextResponse.json({ ok: true, user: publicUser(user) })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}

// GET /api/users?ownerToken=...  — list all users (owner only)
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const ownerToken = (url.searchParams.get('ownerToken') || '').toLowerCase()
    if (!isOwnerToken(ownerToken)) {
      return NextResponse.json({ ok: false, error: 'Owner access required' }, { status: 403 })
    }
    const all = Array.from(usersStore.values()).map(publicUser)
    // Sort: owners first, then by lastActiveAt desc
    all.sort((a, b) => {
      if (a.plan === 'owner' && b.plan !== 'owner') return -1
      if (b.plan === 'owner' && a.plan !== 'owner') return 1
      return b.lastActiveAt - a.lastActiveAt
    })
    return NextResponse.json({ ok: true, users: all, total: all.length })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
