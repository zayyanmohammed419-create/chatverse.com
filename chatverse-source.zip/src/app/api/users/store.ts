// Shared in-memory user store + types
// Imported by /api/users, /api/users/gift, /api/users/upgrade, /api/chat, /api/chat-vision, /api/video

export type PlanId = 'free' | 'plus' | 'premium' | 'owner'

export interface User {
  name: string
  email?: string // optional — set when user signs in via Google-styled flow
  passwordHash?: string // SHA-256 hash of the password (only set if user registered with a password)
  plan: PlanId
  points: number
  createdAt: number
  lastActiveAt: number
  // Daily message tracking (for free plan daily limit)
  messagesToday?: number
  lastMessageDate?: string // YYYY-MM-DD
}

export interface PlanConfig {
  id: PlanId
  name: string
  badge: string
  startingPoints: number
  pointsPerMessage: number // cost per chat message in points
  pointsPerImage: number // cost per image generation in points
  pointsPerVideo: number // cost per video generation in points
  dailyMessageLimit: number // 0 = unlimited
  features: string[]
  gradient: string
  pricePerMonth: number
}

export const PLANS: Record<PlanId, PlanConfig> = {
  free: {
    id: 'free',
    name: 'Free',
    badge: 'Free',
    startingPoints: 30,
    pointsPerMessage: 3,
    pointsPerImage: 5,
    pointsPerVideo: 0, // free cannot generate videos
    dailyMessageLimit: 50, // 50 messages per day
    gradient: 'from-slate-500 to-slate-700',
    pricePerMonth: 0,
    features: [
      '50 messages per day',
      'Text chat with all AI personalities',
      'Image upload (up to 4 per message)',
      'Voice Call (push-to-talk)',
      'Video Call with animated avatar',
      'Markdown rendering',
      '30 starting points (~10 messages)',
      'Standard response speed',
      'Community support',
    ],
  },
  plus: {
    id: 'plus',
    name: 'ChatVerse Plus',
    badge: 'Plus',
    startingPoints: 300,
    pointsPerMessage: 2, // 33% cheaper than free
    pointsPerImage: 4,
    pointsPerVideo: 10,
    dailyMessageLimit: 0, // unlimited
    gradient: 'from-cyan-500 to-blue-600',
    pricePerMonth: 500,
    features: [
      'Unlimited messages',
      '33% fewer points per message (2 pts vs 3)',
      'Fast reply (priority queue)',
      'AI Video Generator (5-sec videos)',
      'Fast image generator',
      '300 starting points (~150 messages)',
      'Custom AI voice selection',
      'Premium button animations',
    ],
  },
  premium: {
    id: 'premium',
    name: 'ChatVerse Premium',
    badge: 'Premium',
    startingPoints: 1000,
    pointsPerMessage: 1, // 67% cheaper than free
    pointsPerImage: 2,
    pointsPerVideo: 5,
    dailyMessageLimit: 0, // unlimited
    gradient: 'from-amber-400 via-yellow-500 to-amber-600',
    pricePerMonth: 1500,
    features: [
      'Unlimited messages',
      '67% fewer points per message (1 pt vs 3)',
      'Cheaper images (2 pts) + videos (5 pts)',
      'Priority support',
      'Longer conversation history (50 messages)',
      'Extended video length (up to 10 sec)',
      'Multiple AI video styles',
      '1000 starting points (~1000 messages)',
      'Premium badge in profile',
      'Premium button animations',
      'Early access to new features',
    ],
  },
  owner: {
    id: 'owner',
    name: 'Owner',
    badge: 'Owner',
    startingPoints: 0,
    pointsPerMessage: 0,
    pointsPerImage: 0,
    pointsPerVideo: 0,
    dailyMessageLimit: 0,
    gradient: 'from-amber-400 to-orange-500',
    pricePerMonth: 0,
    features: [
      'Unlimited everything',
      'Post global announcements',
      'See all users + live count',
      'Gift points to any user',
      'Upgrade any user plan for free',
    ],
  },
}

// Plan helpers
export const PLAN_IDS: PlanId[] = ['free', 'plus', 'premium', 'owner']

export function isValidPlanId(s: any): s is PlanId {
  return typeof s === 'string' && PLAN_IDS.includes(s as PlanId)
}

// Owner tokens
const OWNERS: Record<string, { name: string; role: string }> = {
  mohammed: { name: 'Mohammed Zayyan', role: 'Main Owner' },
}

export function isOwnerToken(t: string | undefined | null): boolean {
  if (!t) return false
  return !!OWNERS[t.toLowerCase()]
}

export function getOwnerInfo(t: string | undefined | null) {
  if (!t) return null
  return OWNERS[t.toLowerCase()] || null
}

// --- In-memory user store ---
// Keyed by lowercased name. Persists across requests within the same server instance.
// IMPORTANT: in Next.js Turbopack dev mode, each route bundle gets its own module instance.
// To share state across routes, we stash the store on globalThis so all bundles see the same Map.
export const usersStore: Map<string, User> = (() => {
  const g = globalThis as any
  if (!g.__chatverseUsersStore) {
    g.__chatverseUsersStore = new Map<string, User>()
  }
  return g.__chatverseUsersStore
})()

export function normalizeName(name: string): string {
  return name.trim().replace(/\s+/g, ' ')
}
export function nameKey(name: string): string {
  return normalizeName(name).toLowerCase()
}

export function publicUser(u: User) {
  return {
    name: u.name,
    email: u.email,
    plan: u.plan,
    points: u.points,
    createdAt: u.createdAt,
    lastActiveAt: u.lastActiveAt,
    messagesToday: u.messagesToday,
    lastMessageDate: u.lastMessageDate,
  }
}

// Check + deduct points for a user action.
// Uses the plan-specific cost (PLANS[user.plan].pointsPerMessage / pointsPerImage / pointsPerVideo).
// Also enforces the daily message limit for free users.
// Returns { ok, error?, user? } — caller decides how to handle.
export function consumePoints(name: string, cost: number, action: 'message' | 'image' | 'video' = 'message'): { ok: boolean; error?: string; user?: User } {
  const key = nameKey(name)
  const user = usersStore.get(key)
  if (!user) {
    return { ok: false, error: 'User not found' }
  }
  // Owners: unlimited, no deduction
  if (user.plan === 'owner') {
    user.lastActiveAt = Date.now()
    return { ok: true, user }
  }

  const plan = PLANS[user.plan] || PLANS.free

  // Daily message limit for free users
  if (action === 'message' && plan.dailyMessageLimit > 0) {
    const today = new Date().toISOString().slice(0, 10) // YYYY-MM-DD
    if (user.lastMessageDate !== today) {
      user.lastMessageDate = today
      user.messagesToday = 0
    }
    if ((user.messagesToday ?? 0) >= plan.dailyMessageLimit) {
      return { ok: false, error: 'DAILY_LIMIT_REACHED' }
    }
  }

  // Use plan-specific cost
  let actualCost = cost
  if (action === 'message') actualCost = plan.pointsPerMessage
  else if (action === 'image') actualCost = plan.pointsPerImage
  else if (action === 'video') actualCost = plan.pointsPerVideo

  if (user.points < actualCost) {
    return { ok: false, error: 'INSUFFICIENT_POINTS' }
  }
  user.points -= actualCost
  // Increment daily message counter for messages
  if (action === 'message') {
    user.messagesToday = (user.messagesToday ?? 0) + 1
  }
  user.lastActiveAt = Date.now()
  return { ok: true, user }
}

// Check if a plan has a feature (used by /api/video to check video gen access)
export function planHasFeature(plan: PlanId, feature: 'video_gen' | 'fast_reply' | 'long_history' | 'image_gen' | 'voice_call' | 'video_call'): boolean {
  if (plan === 'owner') return true
  if (feature === 'video_gen') return plan === 'plus' || plan === 'premium'
  if (feature === 'image_gen') return true // all plans can generate images
  if (feature === 'voice_call') return true // all plans can voice call
  if (feature === 'video_call') return true // all plans can video call
  if (feature === 'fast_reply') return plan === 'plus' || plan === 'premium'
  if (feature === 'long_history') return plan === 'premium'
  return false
}

// Get the daily message limit + usage for a user (used by /api/chat to show remaining)
export function getDailyMessageInfo(name: string): { limit: number; used: number; remaining: number } {
  const key = nameKey(name)
  const user = usersStore.get(key)
  if (!user) return { limit: 0, used: 0, remaining: 0 }
  const plan = PLANS[user.plan] || PLANS.free
  if (plan.dailyMessageLimit === 0) return { limit: 0, used: 0, remaining: 0 } // unlimited
  const today = new Date().toISOString().slice(0, 10)
  if (user.lastMessageDate !== today) {
    user.lastMessageDate = today
    user.messagesToday = 0
  }
  const used = user.messagesToday ?? 0
  return {
    limit: plan.dailyMessageLimit,
    used,
    remaining: Math.max(0, plan.dailyMessageLimit - used),
  }
}
