import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 30

// POST { audioBase64 } → { ok, text }
// audioBase64 is a data URL: data:audio/wav;base64,... or raw base64

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const audioBase64 = (body?.audioBase64 || '').toString().trim()

    if (!audioBase64) {
      return NextResponse.json({ ok: false, error: 'audioBase64 is required' }, { status: 400 })
    }

    // Strip data URL prefix if present (z-ai expects raw base64)
    const commaIdx = audioBase64.indexOf(',')
    const rawBase64 = commaIdx !== -1 ? audioBase64.slice(commaIdx + 1) : audioBase64
    if (!rawBase64) {
      return NextResponse.json({ ok: false, error: 'Empty audio data.' }, { status: 400 })
    }
    // Limit ~5MB
    if (rawBase64.length > 7_000_000) {
      return NextResponse.json({ ok: false, error: 'Audio too large (max 5MB).' }, { status: 400 })
    }

    const zai = await ZAI.create()
    const response = await zai.audio.asr.create({
      file_base64: rawBase64,
    })

    const text = (response?.text || '').toString().trim()
    return NextResponse.json({ ok: true, text })
  } catch (err: any) {
    console.error('[api/asr] error:', err)
    return NextResponse.json(
      { ok: false, error: err?.message || 'Failed to transcribe audio.' },
      { status: 500 }
    )
  }
}
