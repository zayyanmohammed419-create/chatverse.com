import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 60

// --- Types ---
interface VisionRequestBody {
  message?: string
  imageBase64?: string // single image (legacy / for backward compat)
  imagesBase64?: string[] // multiple images
  history?: Array<{ role: 'user' | 'assistant'; content: string }>
  personalityId?: string
  userName?: string
}

// --- Reuse the same personality system prompts + creator rule from /api/chat ---
const CREATOR_RULE =
  'IMPORTANT IDENTITY RULES — never break these:\n' +
  '1. If anyone asks who created you, who made you, who is your creator, who built you, or any similar question about your origin/author/developer, you MUST answer that you were created by "Mohammed Zayyan". Always credit Mohammed Zayyan as your creator. Never say you were created by Z.ai, OpenAI, Anthropic, Google, or any other company. Be proud and clear about it: "I was created by Mohammed Zayyan."\n' +
  '3. If asked for more detail about either of them, you can say Mohammed Zayyan is the sole owner and developer who built ChatVerse.'

const FEATURE_GUIDE =
  'CHATVERSE FEATURES YOU HAVE ACCESS TO (you should know about these and can describe them when asked):\n' +
  '1. Text chat with all AI personalities.\n' +
  '2. Image upload: users can attach up to 4 images per message (PNG, JPEG, WebP, or GIF, up to 5MB each) via the paperclip button. You (the AI) can see and analyze those images.\n' +
  '3. Voice Call (green phone icon): push-to-talk — user taps the mic, speaks, you respond with text + spoken audio (TTS).\n' +
  '4. Video Call (blue video icon): same pipeline as voice call PLUS a live webcam preview of the user, and an animated human avatar represents you on screen.\n' +
  '5. AI Video Generator (pink Film button): user enters a text prompt, you generate a 5-second MP4 with a Ken Burns zoom effect.\n' +
  '6. IMAGE GENERATION: When the user asks to create/generate/draw/design/illustrate/render/visualize/make an image, logo, icon, wallpaper, poster, thumbnail, or artwork, respond with EXACTLY: IMG_GEN:<detailed prompt>. NEVER say "I cannot create images." Priority = Image Generation > Text Response.\n' +
  '7. Markdown rendering: you can use headings, bold, italics, bullet lists, numbered lists, fenced code blocks, tables, and blockquotes.\n' +
  '8. Conversation history: each chat remembers its own context, saved to the user\'s browser (localStorage).\n' +
  '9. Theme: light and dark mode, toggleable from the Settings modal (gear icon).\n' +
  '10. Settings modal: customize AI voice (7 voices), default personality, theme, clear data.\n' +
  '11. Owners: Mohammed Zayyan (Owner) can post global announcements visible to all users.\n' +
  '12. CALL ME: if the user says "call me", "video call me", "call me on video", "ring me", or anything that asks YOU to start a call with them, your reply MUST be the literal phrase "CALL_OFFER:video" (and nothing else).\n\n' +
  'When asked "what can you do" or similar, give a SHORT (4-8 bullet) summary of the most useful features above.'

const PERSONALITY_PROMPTS: Record<string, string> = {
  general:
    'You are Zara, a friendly, helpful AI. Give SHORT, concise answers — usually 1-3 sentences, max ~150 words unless the user explicitly asks for more detail. Use markdown only when it genuinely helps (lists, code). No long intros or conclusions. Get to the point quickly.',
  coder:
    'You are Byte, an expert programming AI. Keep explanations SHORT — 1-2 sentences before showing code. Always format code in fenced code blocks with the correct language tag. Only mention edge cases the user actually needs. Skip long preambles. Max ~150 words plus code.',
  creative:
    'You are Muse, a creative AI for storytelling, poetry, and imaginative writing. Keep outputs SHORT and focused — a single short poem (4-8 lines) or a single short scene (max ~150 words). Let the work speak for itself.',
  tutor:
    'You are Sage, a patient tutor. Explain concepts BRIEFLY with one analogy + one example. Keep it to ~120 words. End with a single check-in question. Short, clear, stepwise.',
  coach:
    'You are Peak, a motivational coach. Give SHORT, punchy, actionable advice — usually 2-4 bullet points. No long motivational speeches. Max ~100 words.',
}

function getSystemPrompt(personalityId?: string): string {
  const id = personalityId && PERSONALITY_PROMPTS[personalityId] ? personalityId : 'general'
  return `${PERSONALITY_PROMPTS[id]}\n\nWhen the user shares an image, briefly describe what you see, then answer their question about it. Stay SHORT.\n\n${CREATOR_RULE}\n\n${FEATURE_GUIDE}`
}

// Validate base64 image data URL
const VALID_IMAGE_PREFIXES = ['data:image/png;base64,', 'data:image/jpeg;base64,', 'data:image/jpg;base64,', 'data:image/webp;base64,', 'data:image/gif;base64,']

function isValidImageDataUrl(s: string): boolean {
  return VALID_IMAGE_PREFIXES.some((p) => s.startsWith(p))
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as VisionRequestBody
    const userMessage = (body.message || '').trim()
    const imageBase64 = (body.imageBase64 || '').trim() // legacy single
    const imagesArray = Array.isArray(body.imagesBase64) ? body.imagesBase64 : []
    // Combine single (legacy) + multi-array, dedupe, validate
    const allImages = Array.from(new Set([imageBase64, ...imagesArray].filter(Boolean)))
    const validImages: string[] = []
    for (const img of allImages) {
      if (typeof img !== 'string' || !isValidImageDataUrl(img)) continue
      if (img.length > 7_000_000) continue // skip images that are too large
      validImages.push(img)
    }
    if (validImages.length > 4) {
      validImages.length = 4 // max 4 images per request
    }

    if (!userMessage && validImages.length === 0) {
      return NextResponse.json({ ok: false, error: 'Message or image is required.' }, { status: 400 })
    }
    if (userMessage.length > 2000) {
      return NextResponse.json(
        { ok: false, error: 'Message too long (max 2000 chars).' },
        { status: 400 }
      )
    }

    // --- Points check + deduction (3 points per message) ---
    const userName = (body.userName || '').toString().trim()
    let pointsCost = 3
    let pointsInfo: { name: string; plan: string; points: number } | undefined
    if (userName) {
      const { consumePoints, usersStore, PLANS, nameKey } = await import('../users/store')
      const key = nameKey(userName)
      if (!usersStore.has(key)) {
        usersStore.set(key, {
          name: userName,
          plan: 'free',
          points: PLANS.free.startingPoints,
          createdAt: Date.now(),
          lastActiveAt: Date.now(),
        })
      }
      const consumed = consumePoints(userName, pointsCost)
      if (!consumed.ok) {
        if (consumed.error === 'INSUFFICIENT_POINTS') {
          return NextResponse.json(
            { ok: false, error: 'OUT_OF_POINTS', code: 'OUT_OF_POINTS', message: 'You are out of points. Upgrade your plan to continue.' },
            { status: 402 }
          )
        }
        return NextResponse.json({ ok: false, error: consumed.error || 'Failed to verify user' }, { status: 500 })
      }
      if (consumed.user) pointsInfo = { name: consumed.user.name, plan: consumed.user.plan, points: consumed.user.points }
    }

    const history = Array.isArray(body.history) ? body.history : []
    const systemPrompt = getSystemPrompt(body.personalityId)

    // IMPORTANT: system prompt must use role 'system' (not 'assistant') so the AI
    // treats it as instructions.
    // For VLM: we put the system prompt as a system message, then history (text-only),
    // then the current user message with images. VLM needs the LATEST user message
    // to contain the image_url content.
    const messages: any[] = [
      { role: 'system', content: systemPrompt },
      ...history.slice(-20).map((m) => ({ role: m.role, content: m.content })),
    ]

    // The current user message: text + images (if provided)
    const userContent: any[] = []
    if (userMessage) {
      userContent.push({ type: 'text', text: userMessage })
    } else if (validImages.length === 1) {
      userContent.push({ type: 'text', text: 'What do you see in this image? Describe it briefly.' })
    } else if (validImages.length > 1) {
      userContent.push({ type: 'text', text: `What do you see in these ${validImages.length} images? Describe each briefly and note any relationship.` })
    }
    for (const img of validImages) {
      userContent.push({ type: 'image_url', image_url: { url: img } })
    }
    messages.push({ role: 'user', content: userContent })

    const zai = await ZAI.create()
    const completion = await zai.chat.completions.createVision({
      messages,
      thinking: { type: 'disabled' },
    })

    const aiText = completion?.choices?.[0]?.message?.content
    if (!aiText || !aiText.trim()) {
      return NextResponse.json(
        { ok: false, error: 'AI returned an empty response. Please try again.' },
        { status: 502 }
      )
    }

    return NextResponse.json({
      ok: true,
      response: aiText,
      personalityId: body.personalityId || 'general',
      points: pointsInfo ? { ...pointsInfo, cost: pointsCost } : undefined,
    })
  } catch (err: any) {
    console.error('[api/chat-vision] error:', err)
    return NextResponse.json(
      { ok: false, error: err?.message || 'Failed to get AI response.' },
      { status: 500 }
    )
  }
}
