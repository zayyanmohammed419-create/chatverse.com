import { NextRequest, NextResponse } from 'next/server'
import { usersStore } from '../users/store'

// --- In-memory live user tracking (per server instance) ---
// We use a Map of sessionId -> lastHeartbeatTimestamp.
// A user is counted as "online" if they sent a heartbeat in the last 30 seconds.

const HEARTBEAT_TTL_MS = 30_000 // 30 seconds
const sessions = new Map<string, number>()

function pruneStale() {
  const now = Date.now()
  for (const [id, ts] of sessions) {
    if (now - ts > HEARTBEAT_TTL_MS) {
      sessions.delete(id)
    }
  }
}

// POST /api/stats  { sessionId }
// Records a heartbeat and returns the live online count.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const sessionId = (body?.sessionId || '').toString().trim()
    if (!sessionId) {
      return NextResponse.json({ ok: false, error: 'sessionId required' }, { status: 400 })
    }
    sessions.set(sessionId, Date.now())
    pruneStale()
    return NextResponse.json({ ok: true, online: sessions.size })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}

// GET /api/stats
// Returns real aggregate statistics pulled from the in-memory user store + live heartbeats.
// These numbers are NOT fake — they reflect the actual users registered on this server.
export async function GET() {
  pruneStale()

  let totalUsers = 0
  let premiumMembers = 0
  let totalPoints = 0
  let ownerCount = 0
  let plusCount = 0
  let premiumCount = 0
  let freeCount = 0

  for (const u of usersStore.values()) {
    totalUsers++
    totalPoints += u.points
    if (u.plan === 'owner') ownerCount++
    else if (u.plan === 'premium') { premiumCount++; premiumMembers++ }
    else if (u.plan === 'plus') { plusCount++; premiumMembers++ }
    else freeCount++
  }

  return NextResponse.json({
    ok: true,
    // Live (heartbeat-based) count of currently online users (real)
    online: sessions.size,
    // Real aggregate stats from the in-memory user store
    totalUsers,
    premiumMembers, // everyone who is not on 'free' (i.e. plus + premium + owner)
    totalPoints,
    ownerCount,
    plusCount,
    premiumCount,
    freeCount,
  })
}
