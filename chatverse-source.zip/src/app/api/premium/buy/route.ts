import { NextRequest, NextResponse } from 'next/server'
import { usersStore, publicUser, nameKey, type PlanId, PLANS } from '@/app/api/users/store'

// POST /api/premium/buy  { userName, plan }
// Lets a logged-in user buy a premium plan with their own points.
// Cost (in points):
//   plus    = 300   (ChatVerse Plus, 1 month)
//   premium = 1000  (ChatVerse Premium, 1 month)
//   premium-plus = 2500 (Premium Plus, 1 month)
// Owners get unlimited and are never charged.

const PRICES: Record<string, number> = {
  plus: 300,
  premium: 1000,
  'premium-plus': 2500,
}

// Map the buy page's plan id to the stored PlanId
const PLAN_MAP: Record<string, PlanId> = {
  plus: 'plus',
  premium: 'premium',
  'premium-plus': 'premium', // stored as 'premium' but with extra-points top-up
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const userName = (body?.userName || '').toString().trim()
    const plan = (body?.plan || '').toString().toLowerCase()

    if (!userName) {
      return NextResponse.json({ ok: false, error: 'userName is required' }, { status: 400 })
    }
    if (!PRICES[plan]) {
      return NextResponse.json({ ok: false, error: 'Invalid plan. Use: plus, premium, or premium-plus' }, { status: 400 })
    }

    const key = nameKey(userName)
    const user = usersStore.get(key)
    if (!user) {
      return NextResponse.json({ ok: false, error: 'User not found. Please sign in first.' }, { status: 404 })
    }
    if (user.plan === 'owner') {
      return NextResponse.json({
        ok: true,
        user: publicUser(user),
        message: 'You are an owner — you already have unlimited access.',
      })
    }

    const cost = PRICES[plan]
    if (user.points < cost) {
      return NextResponse.json({
        ok: false,
        error: 'INSUFFICIENT_POINTS',
        needed: cost,
        have: user.points,
        short: cost - user.points,
      }, { status: 402 })
    }

    // Deduct + upgrade
    const oldPlan = user.plan
    user.points -= cost
    const targetPlan = PLAN_MAP[plan]
    user.plan = targetPlan
    // For premium-plus, top up to 1500 starting points (extra)
    if (plan === 'premium-plus' && user.points < 1500) {
      user.points = 1500
    }
    user.lastActiveAt = Date.now()

    return NextResponse.json({
      ok: true,
      user: publicUser(user),
      previousPlan: oldPlan,
      plan: targetPlan,
      cost,
      remainingPoints: user.points,
    })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
