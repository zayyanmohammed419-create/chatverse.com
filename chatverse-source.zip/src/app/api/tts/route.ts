import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 30

// POST { text, voice?, speed? } → audio/wav binary response
// Voices: tongtong, chuichui, xiaochen, jam, kazi, douji, luodo
// Text limit: 1024 chars per request (we truncate if longer)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const text = (body?.text || '').toString().trim()
    const voice = (body?.voice || 'tongtong').toString().trim() || 'tongtong'
    const speed = Number.isFinite(Number(body?.speed)) ? Number(body.speed) : 1.0

    if (!text) {
      return NextResponse.json({ ok: false, error: 'text is required' }, { status: 400 })
    }
    // Clamp speed 0.5..2.0
    const safeSpeed = Math.max(0.5, Math.min(2.0, speed))
    // Truncate text to 1000 chars to stay safely under the 1024 limit
    const safeText = text.slice(0, 1000)

    const zai = await ZAI.create()
    const response = await zai.audio.tts.create({
      input: safeText,
      voice: voice,
      speed: safeSpeed,
      response_format: 'wav',
      stream: false,
    })

    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(new Uint8Array(arrayBuffer))

    return new NextResponse(new Uint8Array(buffer), {
      status: 200,
      headers: {
        'Content-Type': 'audio/wav',
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'no-cache',
      },
    })
  } catch (err: any) {
    console.error('[api/tts] error:', err)
    return NextResponse.json(
      { ok: false, error: err?.message || 'Failed to generate audio.' },
      { status: 500 }
    )
  }
}
