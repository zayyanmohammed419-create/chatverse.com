import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { promises as fs } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

export const runtime = 'nodejs'
export const maxDuration = 60 // image gen + ffmpeg can take some seconds

// --- Generate a 5-second AI video using image generation + ffmpeg Ken Burns effect ---
//
// Pipeline:
//   1. Generate an image from the user's prompt using z-ai-web-dev-sdk
//   2. Use ffmpeg to apply a Ken Burns zoom effect over 5 seconds and output an MP4

const PUBLIC_DIR = path.join(process.cwd(), 'public')
const VIDEOS_DIR = path.join(PUBLIC_DIR, 'videos')
const IMAGES_DIR = path.join(PUBLIC_DIR, 'images')

// Ensure output directories exist
async function ensureDirs() {
  await fs.mkdir(VIDEOS_DIR, { recursive: true })
  await fs.mkdir(IMAGES_DIR, { recursive: true })
}

// Run ffmpeg as a subprocess
async function runFfmpeg(args: string[]): Promise<{ code: number; stdout: string; stderr: string }> {
  const { spawn } = await import('child_process')
  return new Promise((resolve) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] })
    let stdout = ''
    let stderr = ''
    proc.stdout.on('data', (d) => (stdout += d.toString()))
    proc.stderr.on('data', (d) => (stderr += d.toString()))
    proc.on('error', (err) => resolve({ code: 1, stdout, stderr: err.message }))
    proc.on('close', (code) => resolve({ code: code ?? 0, stdout, stderr }))
  })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const prompt = (body?.prompt || '').toString().trim()
    const userName = (body?.userName || '').toString().trim()
    if (!prompt) {
      return NextResponse.json({ ok: false, error: 'Prompt is required.' }, { status: 400 })
    }
    if (prompt.length > 500) {
      return NextResponse.json({ ok: false, error: 'Prompt too long (max 500 chars).' }, { status: 400 })
    }

    // --- Points check (uses plan-specific cost: free=N/A, plus=10, premium=5) ---
    let pointsCost = 10
    let pointsInfo: { name: string; plan: string; points: number; cost: number } | undefined
    if (userName) {
      const { consumePoints, usersStore, PLANS, nameKey, planHasFeature } = await import('../users/store')
      // Auto-create user if not exists
      const key = nameKey(userName)
      if (!usersStore.has(key)) {
        usersStore.set(key, {
          name: userName,
          plan: 'free',
          points: PLANS.free.startingPoints,
          createdAt: Date.now(),
          lastActiveAt: Date.now(),
        })
      }
      // Check if user's plan allows video generation
      const u = usersStore.get(key)!
      if (!planHasFeature(u.plan, 'video_gen')) {
        return NextResponse.json(
          { ok: false, error: 'PLAN_REQUIRED', code: 'PLAN_REQUIRED', message: 'Video generation is available on Plus and Premium plans. Upgrade to unlock!' },
          { status: 403 }
        )
      }
      // Check + deduct points using plan-specific cost (action='video')
      const consumed = consumePoints(userName, pointsCost, 'video')
      if (!consumed.ok) {
        if (consumed.error === 'INSUFFICIENT_POINTS') {
          return NextResponse.json(
            { ok: false, error: 'OUT_OF_POINTS', code: 'OUT_OF_POINTS', message: 'You are out of points. Upgrade to Premium for cheaper video generation!' },
            { status: 402 }
          )
        }
        return NextResponse.json({ ok: false, error: consumed.error || 'Failed to verify user' }, { status: 500 })
      }
      if (consumed.user) {
        pointsInfo = { name: consumed.user.name, plan: consumed.user.plan, points: consumed.user.points, cost: pointsCost }
      }
    }

    await ensureDirs()
    const id = randomBytes(8).toString('hex')
    const imageDir = path.join(IMAGES_DIR, `${id}.png`)
    const videoDir = path.join(VIDEOS_DIR, `${id}.mp4`)
    const videoUrl = `/videos/${id}.mp4`
    const imageUrl = `/images/${id}.png`

    // 1. Generate the source image
    const zai = await ZAI.create()
    const response = await zai.images.generations.create({
      prompt: `${prompt}, high quality, detailed, cinematic, vibrant colors`,
      size: '1344x768', // landscape
    })
    const imageBase64 = response.data[0].base64
    const buffer = Buffer.from(imageBase64, 'base64')
    await fs.writeFile(imageDir, buffer)

    // 2. Build the 5-second MP4 with a Ken Burns zoom-in effect.
    //    zoompan filter: start at 1.0x and zoom to 1.15x over 5 seconds (125 frames @ 25 fps).
    //    We render at 1280x720 for fast playback and small file size.
    const fps = 25
    const durationSec = 5
    const totalFrames = fps * durationSec
    const ffmpegArgs = [
      '-y',
      '-i', imageDir,
      '-vf',
      `scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,zoompan=z='min(zoom+0.003,1.15)':d=${totalFrames}:s=1280x720:fps=${fps}`,
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart',
      '-t', String(durationSec),
      '-an', // no audio
      videoDir,
    ]
    const result = await runFfmpeg(ffmpegArgs)
    if (result.code !== 0) {
      console.error('[api/video] ffmpeg failed:', result.stderr.slice(-500))
      // Refund points if video generation failed
      if (userName && pointsInfo) {
        const { usersStore, nameKey } = await import('../users/store')
        const u = usersStore.get(nameKey(userName))
        if (u && u.plan !== 'owner') u.points += pointsCost
      }
      return NextResponse.json(
        { ok: false, error: 'Failed to render video. Please try again.' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      ok: true,
      videoUrl,
      imageUrl,
      prompt,
      durationSec,
      points: pointsInfo,
    })
  } catch (err: any) {
    console.error('[api/video] error:', err)
    return NextResponse.json(
      { ok: false, error: err?.message || 'Failed to generate video.' },
      { status: 500 }
    )
  }
}
