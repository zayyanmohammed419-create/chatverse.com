import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const maxDuration = 30

// POST /api/image-search  { query, count? }
// Searches Wikimedia Commons for real images matching the query.
// Returns image URLs that can be displayed directly in the chat.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const query = (body?.query || '').toString().trim()
    const count = Math.min(Math.max(parseInt(body?.count || '5', 10) || 5, 1), 10)

    if (!query) {
      return NextResponse.json({ ok: false, error: 'query is required' }, { status: 400 })
    }
    if (query.length > 200) {
      return NextResponse.json({ ok: false, error: 'query too long (max 200 chars)' }, { status: 400 })
    }

    // Search Wikimedia Commons for images
    const searchUrl = `https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=${count}&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=800`
    const res = await fetch(searchUrl, {
      headers: { 'User-Agent': 'ChatVerse/1.0 (AI assistant)' },
      signal: AbortSignal.timeout(15_000),
    })

    if (!res.ok) {
      return NextResponse.json({
        ok: false,
        error: 'Image search service unavailable. Please try again.',
        query,
      }, { status: 502 })
    }

    const data = await res.json()
    const pages = data?.query?.pages

    if (!pages) {
      return NextResponse.json({
        ok: false,
        error: 'No images found for this query. Try a different search term.',
        query,
      }, { status: 404 })
    }

    // Extract image URLs from the pages
    const images: Array<{ url: string; title: string; source: string; width?: number; height?: number }> = []
    for (const page of Object.values(pages) as any[]) {
      const info = page?.imageinfo?.[0]
      if (!info) continue
      // Skip non-image files (PDFs, SVGs that are too complex, etc.)
      const mime = info.mime || ''
      if (!mime.startsWith('image/')) continue
      if (mime === 'image/svg+xml') continue // skip SVGs

      const url = info.thumburl || info.url
      if (!url) continue

      images.push({
        url,
        title: (page.title || '').replace(/^File:/, '').replace(/\.(jpg|jpeg|png|gif|webp)$/i, ''),
        source: 'Wikimedia Commons',
        width: info.thumbwidth || info.width,
        height: info.thumbheight || info.height,
      })
    }

    if (images.length === 0) {
      return NextResponse.json({
        ok: false,
        error: 'No images found for this query. Try a different search term.',
        query,
      }, { status: 404 })
    }

    return NextResponse.json({
      ok: true,
      query,
      count: images.length,
      images,
    })
  } catch (err: any) {
    console.error('[api/image-search] error:', err?.message || err)
    return NextResponse.json({
      ok: false,
      error: 'Image search failed. Please try again in a moment.',
    }, { status: 500 })
  }
}
