import { NextRequest, NextResponse } from 'next/server'
import {
  usersStore,
  PLANS,
  normalizeName,
  nameKey,
  publicUser,
  isOwnerToken,
} from '../../users/store'
import { createHash } from 'crypto'

export const runtime = 'nodejs'

// POST /api/auth/register  { name, password, ownerToken? }
// - Creates a new user with a name + password.
// - If a user with that name already exists, returns an error.
// - If ownerToken matches an owner AND the name matches the owner's display name,
//   the new user is created as an owner with unlimited points.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const name = normalizeName(body?.name || '')
    const password = (body?.password || '').toString()
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()

    if (!name) {
      return NextResponse.json({ ok: false, error: 'Name is required' }, { status: 400 })
    }
    if (name.length > 40) {
      return NextResponse.json({ ok: false, error: 'Name too long (max 40 chars)' }, { status: 400 })
    }
    if (!password || password.length < 4) {
      return NextResponse.json({ ok: false, error: 'Password must be at least 4 characters' }, { status: 400 })
    }
    if (password.length > 200) {
      return NextResponse.json({ ok: false, error: 'Password too long (max 200 chars)' }, { status: 400 })
    }

    const key = nameKey(name)
    if (usersStore.has(key)) {
      return NextResponse.json({ ok: false, error: 'That name is already taken. Try logging in instead, or use a different name.' }, { status: 409 })
    }

    const passwordHash = createHash('sha256').update(password).digest('hex')
    const isOwner = isOwnerToken(ownerToken)
    let isActuallyOwner = false
    if (isOwner) {
      // Only register as owner if the name matches the owner's display name
      // (mirrors the security check in /api/users/route.ts)
      const ownerTokenMap: Record<string, string> = { mohammed: 'Mohammed Zayyan' }
      const ownerDisplayName = ownerTokenMap[ownerToken]
      if (ownerDisplayName && name.toLowerCase() === ownerDisplayName.toLowerCase()) {
        isActuallyOwner = true
      }
    }

    const user = {
      name,
      passwordHash,
      plan: isActuallyOwner ? 'owner' as const : 'free' as const,
      points: isActuallyOwner ? 0 : PLANS.free.startingPoints,
      createdAt: Date.now(),
      lastActiveAt: Date.now(),
    }
    usersStore.set(key, user)

    return NextResponse.json({ ok: true, user: publicUser(user) })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
