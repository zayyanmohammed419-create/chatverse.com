import { NextRequest, NextResponse } from 'next/server'
import {
  usersStore,
  nameKey,
  normalizeName,
  publicUser,
  isOwnerToken,
} from '../../users/store'
import { createHash } from 'crypto'

export const runtime = 'nodejs'

// POST /api/auth/login  { name, password, ownerToken? }
// - Logs in an existing user with name + password.
// - If ownerToken matches an owner and the name matches the owner's display name,
//   the user is upgraded to owner plan (this is the path for owners signing in via ?owner=...).
// - If the user has no password (legacy Google-styled account), they can still log in
//   if the name exists — but in that case we recommend they re-register with a password.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const name = normalizeName(body?.name || '')
    const password = (body?.password || '').toString()
    const ownerToken = (body?.ownerToken || '').toString().toLowerCase()

    if (!name) {
      return NextResponse.json({ ok: false, error: 'Name is required' }, { status: 400 })
    }
    if (!password) {
      return NextResponse.json({ ok: false, error: 'Password is required' }, { status: 400 })
    }

    const key = nameKey(name)
    const user = usersStore.get(key)
    if (!user) {
      return NextResponse.json({ ok: false, error: 'No account found with that name. Sign up first.' }, { status: 404 })
    }

    // If the user has a password hash, verify the password
    if (user.passwordHash) {
      const passwordHash = createHash('sha256').update(password).digest('hex')
      if (passwordHash !== user.passwordHash) {
        return NextResponse.json({ ok: false, error: 'Incorrect password. Please try again.' }, { status: 401 })
      }
    } else {
      // Legacy account (no password) — set the provided password as their password now.
      // This "claims" the old account with a new password so it can be used going forward.
      user.passwordHash = createHash('sha256').update(password).digest('hex')
    }

    // Owner token check — if matches and name matches owner's display name, upgrade to owner
    if (isOwnerToken(ownerToken)) {
      const ownerTokenMap: Record<string, string> = { mohammed: 'Mohammed Zayyan' }
      const ownerDisplayName = ownerTokenMap[ownerToken]
      if (ownerDisplayName && name.toLowerCase() === ownerDisplayName.toLowerCase() && user.plan !== 'owner') {
        user.plan = 'owner'
        user.points = 0
      }
    }
    user.lastActiveAt = Date.now()

    return NextResponse.json({ ok: true, user: publicUser(user) })
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'error' }, { status: 500 })
  }
}
