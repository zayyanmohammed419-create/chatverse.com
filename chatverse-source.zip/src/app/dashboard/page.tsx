"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, AnimatePresence, useInView } from "framer-motion";
import {
  Crown, Sparkles, MessageSquare, Image as ImageIcon, Bot, ArrowLeft,
  Code, FileText, Music, Zap, Activity, Brain, Hash,
  Gauge, Layers, Cpu, Rocket, ChevronRight, Send, Users,
} from "lucide-react";

/* ============================================================
   CHATVERSE AI PREMIUM DASHBOARD
   Sci-fi premium layout: Aura Chat + Neural Analytics + Generation Queue + Creative Suite
   ============================================================ */

/* ----------------------- Animated count-up hook ----------------------- */
function useCountUp(target: number, inView: boolean, duration = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, inView, duration]);
  return value;
}

/* ----------------------- Sidebar nav items ----------------------- */
const NAV_ITEMS = [
  { icon: MessageSquare, label: "Aura Chat", color: "from-blue-500 to-cyan-500" },
  { icon: Brain, label: "Neural Analytics", color: "from-purple-500 to-pink-500" },
  { icon: Zap, label: "Generation Queue", color: "from-amber-400 to-yellow-500" },
  { icon: ImageIcon, label: "Creative Suite", color: "from-emerald-400 to-teal-500" },
  { icon: Activity, label: "Live Stats", color: "from-cyan-400 to-blue-500" },
  { icon: Hash, label: "Trending", color: "from-rose-400 to-red-500" },
];

/* ----------------------- Neural network SVG visualization ----------------------- */
function NeuralNetworkViz() {
  // Generate nodes + connections (client-side only to avoid hydration mismatch)
  const [nodes, setNodes] = useState<Array<{ x: number; y: number; layer: number }>>([]);
  const [links, setLinks] = useState<Array<{ from: number; to: number; delay: number }>>([]);

  useEffect(() => {
    Promise.resolve().then(() => {
      // 4 layers: 4 → 6 → 5 → 3 nodes
      const layerCounts = [4, 6, 5, 3];
      const newNodes: Array<{ x: number; y: number; layer: number }> = [];
      const layerX = [50, 150, 250, 350];
      layerCounts.forEach((count, layerIdx) => {
        for (let i = 0; i < count; i++) {
          const ySpacing = 200 / (count + 1);
          newNodes.push({
            x: layerX[layerIdx],
            y: ySpacing * (i + 1),
            layer: layerIdx,
          });
        }
      });
      // Connect each layer to the next
      const newLinks: Array<{ from: number; to: number; delay: number }> = [];
      let nodeIdx = 0;
      let layerStart = 0;
      layerCounts.forEach((count, layerIdx) => {
        if (layerIdx < layerCounts.length - 1) {
          for (let i = 0; i < count; i++) {
            for (let j = 0; j < layerCounts[layerIdx + 1]; j++) {
              newLinks.push({
                from: layerStart + i,
                to: layerStart + count + j,
                delay: Math.random() * 2,
              });
            }
          }
        }
        layerStart += count;
      });
      setNodes(newNodes);
      setLinks(newLinks);
    });
  }, []);

  return (
    <svg viewBox="0 0 400 200" className="h-full w-full">
      <defs>
        <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#38bdf8" stopOpacity="1" />
          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="linkGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.1" />
          <stop offset="50%" stopColor="#a855f7" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.1" />
        </linearGradient>
      </defs>
      {/* Connections */}
      {links.map((link, i) => {
        const from = nodes[link.from];
        const to = nodes[link.to];
        if (!from || !to) return null;
        return (
          <line
            key={i}
            x1={from.x}
            y1={from.y}
            x2={to.x}
            y2={to.y}
            stroke="url(#linkGrad)"
            strokeWidth="0.5"
            opacity="0.3"
          >
            <animate
              attributeName="opacity"
              values="0.1;0.6;0.1"
              dur="3s"
              begin={`${link.delay}s`}
              repeatCount="indefinite"
            />
          </line>
        );
      })}
      {/* Nodes */}
      {nodes.map((node, i) => (
        <g key={i}>
          <circle cx={node.x} cy={node.y} r="8" fill="url(#nodeGlow)" opacity="0.6">
            <animate
              attributeName="r"
              values="6;10;6"
              dur="2.5s"
              begin={`${i * 0.15}s`}
              repeatCount="indefinite"
            />
          </circle>
          <circle cx={node.x} cy={node.y} r="3" fill="#a855f7" opacity="0.9">
            <animate
              attributeName="fill"
              values="#a855f7;#38bdf8;#a855f7"
              dur="3s"
              begin={`${i * 0.2}s`}
              repeatCount="indefinite"
            />
          </circle>
        </g>
      ))}
    </svg>
  );
}

/* ----------------------- Usage Metrics line chart (animated SVG) ----------------------- */
function UsageChart() {
  const [data, setData] = useState<number[]>([]);
  useEffect(() => {
    Promise.resolve().then(() => {
      // Generate a realistic-looking wave pattern
      const points: number[] = [];
      for (let i = 0; i < 40; i++) {
        const base = 50 + Math.sin(i * 0.3) * 20 + Math.sin(i * 0.7) * 10;
        const noise = (Math.random() - 0.5) * 15;
        points.push(Math.max(10, Math.min(90, base + noise)));
      }
      setData(points);
    });
  }, []);

  const w = 400;
  const h = 120;
  const step = w / (data.length - 1 || 1);
  const pathD = data.length > 0
    ? data.map((v, i) => `${i === 0 ? 'M' : 'L'}${i * step},${h - (v / 100) * h}`).join(' ')
    : '';
  const areaD = data.length > 0
    ? `${pathD} L${w},${h} L0,${h} Z`
    : '';

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-full w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="usageArea" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="usageLine" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#6366f1" />
          <stop offset="50%" stopColor="#a855f7" />
          <stop offset="100%" stopColor="#38bdf8" />
        </linearGradient>
      </defs>
      {/* Grid lines */}
      {[0.25, 0.5, 0.75].map((p) => (
        <line key={p} x1="0" y1={h * p} x2={w} y2={h * p} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
      ))}
      {data.length > 0 && (
        <>
          <path d={areaD} fill="url(#usageArea)" />
          <motion.path
            d={pathD}
            fill="none"
            stroke="url(#usageLine)"
            strokeWidth="2"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, ease: "easeOut" }}
          />
          {/* Animated dot at the end */}
          <motion.circle
            r="4"
            fill="#38bdf8"
            initial={{ cx: 0, cy: h - (data[0] / 100) * h }}
            animate={data.length > 0 ? { cx: w, cy: h - (data[data.length - 1] / 100) * h } : {}}
            transition={{ duration: 2, ease: "easeOut" }}
          >
            <animate attributeName="r" values="3;6;3" dur="1.5s" repeatCount="indefinite" />
          </motion.circle>
        </>
      )}
    </svg>
  );
}

/* ----------------------- Creative Output Trends (bar chart) ----------------------- */
function TrendsChart() {
  const [bars, setBars] = useState<number[]>([]);
  useEffect(() => {
    Promise.resolve().then(() => {
      setBars(Array.from({ length: 12 }).map(() => 30 + Math.random() * 70));
    });
  }, []);

  return (
    <div className="flex h-full items-end gap-1">
      {bars.map((h, i) => (
        <motion.div
          key={i}
          initial={{ height: 0 }}
          whileInView={{ height: `${h}%` }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: i * 0.04, ease: "easeOut" }}
          className="flex-1 rounded-t bg-gradient-to-t from-purple-600/40 via-fuchsia-500/60 to-cyan-400/80"
          style={{ minHeight: '4px' }}
        >
          <div className="h-full w-full rounded-t bg-gradient-to-t from-purple-600/20 to-cyan-400/40" />
        </motion.div>
      ))}
    </div>
  );
}

/* ----------------------- Stat tile with animated counter ----------------------- */
function StatTile({ icon: Icon, value, label, suffix = "", gradient }: {
  icon: any; value: number; label: string; suffix?: string; gradient: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-4 backdrop-blur-xl transition-colors hover:border-cyan-400/30"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 opacity-0 transition-opacity group-hover:opacity-100" />
      <div className={`mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-white shadow-lg`}>
        <Icon className="h-4 w-4" />
      </div>
      <motion.div
        key={value}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-2xl font-black tracking-tight text-white"
      >
        {value.toLocaleString()}{suffix}
      </motion.div>
      <div className="text-[11px] text-slate-400">{label}</div>
      <div className="mt-1 inline-flex items-center gap-1 text-[8px] font-bold uppercase tracking-wider text-emerald-300">
        <span className="inline-block h-1 w-1 animate-pulse rounded-full bg-emerald-400" /> Live
      </div>
    </motion.div>
  );
}

/* ============================================================
   MAIN DASHBOARD PAGE
   ============================================================ */
export default function DashboardPage() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loaded, setLoaded] = useState(false);
  const [activeNav, setActiveNav] = useState(0);
  const [chatMsg, setChatMsg] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'ai'; text: string }>>([
    { role: 'ai', text: 'Welcome to Aura Premium Chat. How can I assist you today?' },
  ]);

  // Real stats from /api/stats
  const [stats, setStats] = useState<{ totalUsers: number; premiumMembers: number; totalPoints: number; online: number } | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 50);
    return () => clearTimeout(t);
  }, []);

  // Load current user
  useEffect(() => {
    const name = typeof window !== "undefined" ? localStorage.getItem("chatverse:userName") : null;
    if (name) {
      fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      })
        .then((r) => r.json())
        .then((d) => { if (d?.user) setCurrentUser(d.user); })
        .catch(() => {});
    }
  }, []);

  // Load real stats
  useEffect(() => {
    let cancelled = false;
    const load = () => {
      fetch("/api/stats")
        .then((r) => r.json())
        .then((d) => {
          if (cancelled) return;
          // Always set stats — d may or may not have `ok` field
          setStats({
            totalUsers: (d && typeof d.totalUsers === 'number') ? d.totalUsers : 0,
            premiumMembers: (d && typeof d.premiumMembers === 'number') ? d.premiumMembers : 0,
            totalPoints: (d && typeof d.totalPoints === 'number') ? d.totalPoints : 0,
            online: (d && typeof d.online === 'number') ? d.online : 0,
          });
        })
        .catch(() => {});
    };
    load();
    const interval = setInterval(load, 15000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  const sendAuraMessage = () => {
    const text = chatMsg.trim();
    if (!text) return;
    setChatMessages((prev) => [...prev, { role: 'user', text }]);
    setChatMsg('');
    // Simulate AI response (this is a dashboard demo chat — real chat is on the main page)
    setTimeout(() => {
      setChatMessages((prev) => [...prev, {
        role: 'ai',
        text: '✨ I received your message. For full AI responses with image generation, voice calls, and more, use the main chat page.',
      }]);
    }, 1500);
  };

  const isPremiumUser = !!(currentUser && (currentUser.plan === 'plus' || currentUser.plan === 'premium' || currentUser.plan === 'owner'));

  return (
    <div className="relative min-h-[100dvh] overflow-hidden bg-[#03050a] text-white">
      {/* ====================== Animated background ====================== */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        {/* Radial vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(99,102,241,0.15),transparent_50%),radial-gradient(ellipse_at_bottom_right,rgba(168,85,247,0.12),transparent_50%)]" />
        {/* Animated orbs */}
        <motion.div
          className="absolute -top-32 left-1/4 h-[400px] w-[400px] rounded-full bg-gradient-to-br from-indigo-600/20 via-purple-500/15 to-transparent blur-[100px]"
          animate={{ x: [0, 60, 0], y: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-1/2 right-0 h-[450px] w-[450px] rounded-full bg-gradient-to-br from-cyan-500/15 via-blue-500/10 to-transparent blur-[100px]"
          animate={{ x: [0, -50, 0], y: [0, 60, 0] }}
          transition={{ duration: 24, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(rgba(99,102,241,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.6) 1px, transparent 1px)',
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* ====================== Layout: Sidebar + Main ====================== */}
      <div className="flex h-[100dvh] w-full">
        {/* ----------------------- Left Sidebar ----------------------- */}
        <aside className="hidden w-[200px] shrink-0 flex-col border-r border-white/10 bg-black/40 backdrop-blur-2xl md:flex">
          {/* Logo */}
          <div className="border-b border-white/10 p-4">
            <div className="flex items-center gap-2.5">
              <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl shadow-lg shadow-cyan-500/30">
                <motion.span
                  animate={{ opacity: [0.4, 0.8, 0.4] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-0 bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-sm"
                />
                <Image
                  src="/chatverse-logo.png"
                  alt="ChatVerse AI"
                  width={40}
                  height={40}
                  className="relative z-10 h-10 w-10 rounded-xl object-cover"
                />
              </div>
              <div>
                <div className="text-sm font-extrabold tracking-tight">
                  ChatVerse <span className="text-gradient-cyan">AI</span>
                </div>
                <div className="text-[9px] font-bold uppercase tracking-wider text-amber-300/80">Premium</div>
              </div>
            </div>
            <p className="mt-2 text-[10px] text-slate-500">Upgrade Your Journey</p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-1 p-3">
            {NAV_ITEMS.map((item, i) => (
              <button
                key={item.label}
                onClick={() => setActiveNav(i)}
                className={`group flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-semibold transition ${
                  activeNav === i
                    ? 'bg-gradient-to-r from-cyan-500/15 to-purple-500/10 text-cyan-200 ring-1 ring-cyan-400/30'
                    : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
                }`}
              >
                <div className={`flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br ${item.color} text-white shadow-sm transition-transform group-hover:scale-110`}>
                  <item.icon className="h-3.5 w-3.5" />
                </div>
                {item.label}
              </button>
            ))}
          </nav>

          {/* Back to chat */}
          <div className="border-t border-white/10 p-3">
            <Link
              href="/"
              className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/[0.08] hover:text-cyan-300"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back to Chat
            </Link>
          </div>
        </aside>

        {/* ----------------------- Main Content ----------------------- */}
        <main className="flex min-h-0 flex-1 flex-col overflow-y-auto [scrollbar-width:thin]">
          {/* Top bar */}
          <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-white/10 bg-black/40 px-4 py-3 backdrop-blur-2xl sm:px-6" style={{ paddingTop: 'max(env(safe-area-inset-top, 0.75rem), 0.75rem)' }}>
            <div className="flex items-center gap-3">
              <Link href="/" className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-white/[0.06] hover:text-cyan-300 md:hidden">
                <ArrowLeft className="h-4 w-4" />
              </Link>
              <div>
                <h1 className="text-base font-black tracking-tight sm:text-lg">
                  ChatVerse AI <span className="text-gradient-cyan">Premium Dashboard</span>
                </h1>
                <p className="text-[10px] text-slate-500">
                  {isPremiumUser ? 'Premium Member' : 'Free Member'} · by Mohammed Zayyan
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {currentUser && (
                <div className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs">
                  <Crown className={`h-3 w-3 ${isPremiumUser ? 'text-amber-300' : 'text-slate-500'}`} />
                  <span className="font-bold uppercase tracking-wider text-slate-300">{currentUser.plan}</span>
                </div>
              )}
              <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                Online
              </div>
            </div>
          </header>

          {/* ====================== Main grid ====================== */}
          <div className="flex-1 p-4 sm:p-6">
            {/* Section 1: Aura Premium Chat + Neural Analytics (side by side on large screens) */}
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {/* ----- Aura Premium Chat ----- */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={loaded ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5 }}
                className="flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-indigo-500/5 via-black/40 to-purple-500/5 backdrop-blur-xl"
              >
                <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 shadow-lg">
                      <MessageSquare className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white">Aura Premium Chat</h2>
                      <p className="text-[10px] text-slate-400">AI-powered conversations</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-cyan-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-cyan-300">
                    <Sparkles className="h-2.5 w-2.5" /> Active
                  </span>
                </div>
                {/* Chat messages */}
                <div className="flex-1 space-y-3 overflow-y-auto p-4 [scrollbar-width:thin]" style={{ minHeight: '250px', maxHeight: '300px' }}>
                  {chatMessages.map((m, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${
                        m.role === 'user'
                          ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-br-md'
                          : 'border border-white/10 bg-white/[0.04] text-slate-100 rounded-bl-md backdrop-blur-xl'
                      }`}>
                        {m.text}
                      </div>
                    </motion.div>
                  ))}
                </div>
                {/* Chat input */}
                <div className="border-t border-white/10 p-3" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0.75rem), 0.75rem)' }}>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={chatMsg}
                      onChange={(e) => setChatMsg(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') sendAuraMessage(); }}
                      placeholder="Type a message..."
                      className="h-10 flex-1 rounded-xl border border-white/10 bg-white/[0.04] px-3 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
                    />
                    <button
                      onClick={sendAuraMessage}
                      disabled={!chatMsg.trim()}
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30 transition hover:from-cyan-400 hover:to-blue-500 disabled:opacity-40"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="mt-1.5 text-center text-[9px] text-slate-600">
                    💡 For full AI chat (images, voice, video) use the <Link href="/" className="text-cyan-400 hover:underline">main chat page</Link>
                  </p>
                </div>
              </motion.div>

              {/* ----- Neural Universe Analytics ----- */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={loaded ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-purple-500/5 via-black/40 to-cyan-500/5 backdrop-blur-xl"
              >
                <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 shadow-lg">
                      <Brain className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white">Neural Universe Analytics</h2>
                      <p className="text-[10px] text-slate-400">Real-time AI metrics</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-purple-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-purple-300">
                    <Activity className="h-2.5 w-2.5" /> Live
                  </span>
                </div>

                <div className="flex-1 space-y-4 p-4">
                  {/* Usage Metrics line chart */}
                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Usage Metrics</span>
                      <span className="text-[10px] font-bold text-cyan-300">+24% this week</span>
                    </div>
                    <div className="h-24 overflow-hidden rounded-lg border border-white/5 bg-black/20">
                      <UsageChart />
                    </div>
                  </div>

                  {/* Neural Network Heatmap */}
                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Neural Network Heatmap</span>
                      <span className="text-[10px] font-bold text-purple-300">18 nodes active</span>
                    </div>
                    <div className="h-28 overflow-hidden rounded-lg border border-white/5 bg-black/20">
                      <NeuralNetworkViz />
                    </div>
                  </div>

                  {/* Creative Output Trends */}
                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Creative Output Trends</span>
                      <span className="text-[10px] font-bold text-fuchsia-300">12 categories</span>
                    </div>
                    <div className="h-20 overflow-hidden rounded-lg border border-white/5 bg-black/20 p-2">
                      <TrendsChart />
                    </div>
                  </div>

                  {/* Generated Models + Query Topics (2 columns) */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-lg border border-white/5 bg-black/20 p-3">
                      <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Generated Models</div>
                      {[
                        { label: 'Chat', pct: 35, color: 'bg-cyan-400' },
                        { label: 'Image', pct: 23, color: 'bg-amber-400' },
                        { label: 'Code', pct: 18, color: 'bg-purple-400' },
                        { label: 'Other', pct: 24, color: 'bg-emerald-400' },
                      ].map((m) => (
                        <div key={m.label} className="mb-1.5">
                          <div className="mb-0.5 flex items-center justify-between text-[9px]">
                            <span className="text-slate-400">{m.label}</span>
                            <span className="font-bold text-white">{m.pct}%</span>
                          </div>
                          <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                            <motion.div
                              initial={{ width: 0 }}
                              whileInView={{ width: `${m.pct}%` }}
                              viewport={{ once: true }}
                              transition={{ duration: 1, ease: "easeOut" }}
                              className={`h-full rounded-full ${m.color}`}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="rounded-lg border border-white/5 bg-black/20 p-3">
                      <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Query Topics</div>
                      {[
                        { label: 'General', pct: 83, color: 'bg-cyan-400' },
                        { label: 'Coding', pct: 18, color: 'bg-blue-400' },
                        { label: 'Images', pct: 12, color: 'bg-purple-400' },
                        { label: 'Other', pct: 8, color: 'bg-emerald-400' },
                      ].map((m) => (
                        <div key={m.label} className="mb-1.5">
                          <div className="mb-0.5 flex items-center justify-between text-[9px]">
                            <span className="text-slate-400">{m.label}</span>
                            <span className="font-bold text-white">{m.pct}%</span>
                          </div>
                          <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                            <motion.div
                              initial={{ width: 0 }}
                              whileInView={{ width: `${m.pct}%` }}
                              viewport={{ once: true }}
                              transition={{ duration: 1, ease: "easeOut" }}
                              className={`h-full rounded-full ${m.color}`}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Section 2: Priority Generation Queue */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={loaded ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-4 overflow-hidden rounded-2xl border border-amber-400/30 bg-gradient-to-br from-amber-500/10 via-black/40 to-yellow-500/5 backdrop-blur-xl"
            >
              <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 text-black shadow-lg shadow-amber-500/30">
                    <Zap className="h-6 w-6" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-white">Priority Generation Queue</h2>
                    <p className="text-[10px] text-slate-400">HD image generation in progress</p>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-semibold text-amber-200">Generating HD Image...</span>
                    <span className="font-black text-amber-300">95%</span>
                  </div>
                  <div className="h-3 w-full overflow-hidden rounded-full bg-white/10">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: '95%' }}
                      transition={{ duration: 2.5, ease: "easeOut", delay: 0.5 }}
                      className="relative h-full rounded-full bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 shadow-lg shadow-amber-500/40"
                    >
                      <div className="absolute inset-0 animate-shimmer rounded-full" />
                    </motion.div>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-500">Estimated time remaining: ~5 seconds</p>
                </div>
                <button className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-2.5 text-sm font-bold text-black shadow-lg shadow-amber-500/30 transition-transform hover:scale-105">
                  <Rocket className="h-4 w-4" /> Boost Queue
                </button>
              </div>
            </motion.div>

            {/* Section 3: Advanced Creative Suite */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={loaded ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="mt-4 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-emerald-500/5 via-black/40 to-cyan-500/5 backdrop-blur-xl"
            >
              <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 shadow-lg">
                    <ImageIcon className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-white">Advanced Creative Suite</h2>
                    <p className="text-[10px] text-slate-400">Premium AI tools</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-emerald-300">
                  <Layers className="h-2.5 w-2.5" /> 4 Tools
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-4">
                {[
                  { name: 'Image Generation', icon: ImageIcon, color: 'from-amber-400 to-yellow-500', prompt: 'Create a beautiful futuristic city skyline at sunset with neon lights, ultra detailed, 8K quality' },
                  { name: 'Coding', icon: Code, color: 'from-indigo-500 to-purple-500', prompt: 'Write me a Python function that checks if a number is prime, with example usage' },
                  { name: 'Content', icon: FileText, color: 'from-emerald-400 to-teal-500', prompt: 'Write a short blog post about the future of AI assistants' },
                  { name: 'Music', icon: Music, color: 'from-rose-400 to-red-500', prompt: 'Suggest a playlist of 10 songs for a futuristic sci-fi movie soundtrack' },
                ].map((tool, i) => (
                  <motion.button
                    key={tool.name}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={loaded ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.3, delay: 0.4 + i * 0.08 }}
                    whileHover={{ y: -6, scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => {
                      try { localStorage.setItem("chatverse:pendingPrompt", tool.prompt); } catch {}
                      window.location.href = '/';
                    }}
                    className="group relative overflow-hidden rounded-xl border border-white/10 bg-white/[0.03] p-4 text-center transition-colors hover:border-cyan-400/30"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 opacity-0 transition-opacity group-hover:opacity-100" />
                    <div className={`mx-auto mb-2.5 flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${tool.color} text-white shadow-lg transition-transform group-hover:scale-110`}>
                      <tool.icon className="h-5 w-5" />
                    </div>
                    <div className="text-xs font-bold text-white">{tool.name}</div>
                    <div className="mt-1.5 flex items-center justify-center gap-1 text-[9px] font-bold uppercase tracking-wider text-cyan-300 opacity-0 transition-opacity group-hover:opacity-100">
                      Open <ChevronRight className="h-2.5 w-2.5" />
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Section 4: Live Platform Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={loaded ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="mt-4 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-500/5 via-black/40 to-blue-500/5 backdrop-blur-xl"
            >
              <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 shadow-lg">
                    <Gauge className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-white">Live Platform Statistics</h2>
                    <p className="text-[10px] text-slate-400">Real-time data from ChatVerse database</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-emerald-300">
                  <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> Live
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-4">
                <StatTile icon={Users} value={stats?.totalUsers ?? 0} label="Total Registered Users" gradient="from-cyan-500 to-blue-500" />
                <StatTile icon={Activity} value={stats?.online ?? 0} label="Active Users Right Now" gradient="from-emerald-400 to-teal-500" />
                <StatTile icon={Crown} value={stats?.premiumMembers ?? 0} label="Premium Members" gradient="from-amber-400 to-yellow-500" />
                <StatTile icon={Cpu} value={stats?.totalPoints ?? 0} label="Total AI Points" gradient="from-purple-500 to-pink-500" />
              </div>
            </motion.div>

            {/* Footer */}
            <div className="mt-6 flex flex-col items-center justify-between gap-2 border-t border-white/10 pt-4 text-xs text-slate-500 sm:flex-row">
              <div className="flex items-center gap-2">
                <Crown className="h-3.5 w-3.5 text-amber-400" />
                <span>ChatVerse AI Premium · built by Mohammed Zayyan</span>
              </div>
              <div className="flex gap-4">
                <Link href="/" className="hover:text-cyan-300">Chat</Link>
                <Link href="/premium" className="hover:text-amber-300">Premium</Link>
                <Link href="/dashboard" className="hover:text-cyan-300">Dashboard</Link>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
