'use client'

import { useEffect, useMemo, useRef, useState, useCallback } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import InstallAppButton from '@/components/InstallAppButton'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Send, Sparkles, Sun, Moon, Plus, MessageCircle, MessageSquare, Trash2, Menu, X, Check, Copy,
  Bot, Search, Settings, ChevronLeft, Square, User, Zap, Code, BookOpen, Heart,
  Lightbulb, FileText, Image as ImageIcon, Mic, Paperclip, Phone, Video as VideoIcon, MoreVertical,
  CheckCheck, PenSquare, LayoutGrid, ChevronDown, Megaphone, Users, Film, Play, Pause, Crown, Shield,
  Link2, LogOut, CalendarDays, Bell, History, Brain, UserPlus, Share2, ClipboardList, Download,
  Cloud, Newspaper, MapPin, Droplets, Wind, Thermometer,
} from 'lucide-react'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'

// --- Types ---
type PersonalityId = 'general'

interface Personality {
  id: PersonalityId
  name: string
  emoji: string
  tagline: string
  gradient: string
  ringColor: string
  icon: React.ComponentType<{ className?: string }>
}

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
  personalityId?: PersonalityId
  status?: 'sending' | 'sent' | 'error' | 'generating'
  generatingType?: 'image' | 'video'
  imageBase64?: string // data URL of an uploaded image (legacy single image)
  imagesBase64?: string[] // data URLs of uploaded images (multi-image)
}

interface Conversation {
  id: string
  personalityId: PersonalityId
  title: string
  messages: ChatMessage[]
  createdAt: number
  updatedAt: number
}

interface Announcement {
  id: string
  text: string
  authorName: string
  authorRole: string
  createdAt: number
}

// --- Owners ---
// Main owner: Mohammed Zayyan (token: mohammed)
const OWNERS: Record<string, { name: string; role: string; badge: string; gradient: string; icon: 'crown' | 'shield' }> = {
  mohammed: { name: 'Mohammed Zayyan', role: 'Main Owner', badge: 'Main Owner', gradient: 'from-amber-400 to-orange-500', icon: 'crown' },
}

// --- Personalities (Discord-style "servers" + WhatsApp-style "contacts") ---
const SINGLE_AI: Personality = {
  id: 'general',
  name: 'ChatVerse AI',
  emoji: '✨',
  tagline: 'Your AI assistant',
  gradient: 'from-teal-500 via-cyan-500 to-emerald-500',
  ringColor: 'ring-teal-400',
  icon: Sparkles,
}

const PERSONALITIES: Personality[] = [SINGLE_AI]

const getPersonality = (_id: PersonalityId) => SINGLE_AI

// Welcome message + suggestions for the single AI
const WELCOME_MESSAGE = "Hi! I'm ChatVerse AI. I can chat, answer questions, write code, help with homework, create images, generate videos, and more. What can I help you with today?"
const SUGGESTIONS = ['What can you do?', 'Write a haiku about the ocean', 'Explain quantum computing simply', 'Create an image of a sunset']

// Conversations are stored per-user so each account has its own chat history.
// Key format: chatverse:conversations:${userName}
function getUserStorageKey(userName: string): string {
  return `chatverse:conversations:${userName.toLowerCase().trim()}`
}
const THEME_KEY = 'chatverse:theme:v1'

// --- Helpers ---
const uid = () => Math.random().toString(36).slice(2, 10)
const now = () => Date.now()

function formatTime(ts: number): string {
  const d = new Date(ts)
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function formatDate(ts: number): string {
  const d = new Date(ts)
  const today = new Date()
  const yest = new Date()
  yest.setDate(today.getDate() - 1)
  if (d.toDateString() === today.toDateString()) return 'Today'
  if (d.toDateString() === yest.toDateString()) return 'Yesterday'
  return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })
}

function titleFrom(text: string): string {
  const t = text.trim().replace(/\s+/g, ' ')
  return t.length > 38 ? t.slice(0, 38) + '…' : t
}

// --- Main component ---
export default function Home() {
  const [theme, setTheme] = useState<'light' | 'dark'>('dark')
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [inputMessage, setInputMessage] = useState('')
  const [isThinking, setIsThinking] = useState(false)
  const [mobileSidebar, setMobileSidebar] = useState(false) // show sidebar on mobile
  const [mobileChat, setMobileChat] = useState(true) // show chat on mobile
  const [showPersonalityPicker, setShowPersonalityPicker] = useState(false) // kept for compat but unused
  const [search, setSearch] = useState('')

  // --- New feature state ---
  const [ownerToken, setOwnerToken] = useState<string | null>(null) // 'mohammed' or null
  const [onlineCount, setOnlineCount] = useState<number>(0)
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false)
  const [newAnnouncementText, setNewAnnouncementText] = useState('')

  // --- Events (owners can post; everyone sees upcoming events) ---
  type EventItem = { id: string; title: string; description: string; date: string; time: string; authorName: string; authorRole: string; createdAt: number }
  const [events, setEvents] = useState<EventItem[]>([])
  const [showEventModal, setShowEventModal] = useState(false)
  const [newEvent, setNewEvent] = useState<{ title: string; description: string; date: string; time: string }>({ title: '', description: '', date: '', time: '' })

  const [showOwnerPanel, setShowOwnerPanel] = useState(false)
  const [showVideoModal, setShowVideoModal] = useState(false)
  const [videoPrompt, setVideoPrompt] = useState('')
  const [showImageGenModal, setShowImageGenModal] = useState(false)
  const [imageGenPrompt, setImageGenPrompt] = useState('')
  const [imageGenStatus, setImageGenStatus] = useState<'idle' | 'generating' | 'done' | 'error'>('idle')
  const [imageGenResult, setImageGenResult] = useState<{ imageUrl: string; prompt: string } | null>(null)
  const [videoStatus, setVideoStatus] = useState<'idle' | 'generating' | 'done' | 'error'>('idle')
  const [videoResult, setVideoResult] = useState<{ videoUrl: string; imageUrl: string; prompt: string } | null>(null)

  // --- New: user/login/plan/points state ---
  type PlanId = 'free' | 'plus' | 'premium' | 'owner'
  interface UserInfo { name: string; email?: string; plan: PlanId; points: number; createdAt: number; lastActiveAt: number }
  const [currentUser, setCurrentUser] = useState<UserInfo | null>(null)
  // --- Derived: is the current user on a premium plan? (plus / premium / owner) ---
  // Premium users get extra button animations (glow, shimmer, float, gradient shift) across the chat UI.
  const isPremiumUser = !!(currentUser && (currentUser.plan === 'plus' || currentUser.plan === 'premium' || currentUser.plan === 'owner'))
  const [showNameModal, setShowNameModal] = useState(false)
  const [enteredName, setEnteredName] = useState('')
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [showPlansModal, setShowPlansModal] = useState(false)
  const [buyingPlan, setBuyingPlan] = useState<string | null>(null)
  const [showOutOfPointsModal, setShowOutOfPointsModal] = useState(false)
  const [showUsersModal, setShowUsersModal] = useState(false) // owner-only users dashboard
  const [showNotificationsModal, setShowNotificationsModal] = useState(false)
  const [showKnowledgeBase, setShowKnowledgeBase] = useState(false)
  const [showContextPanel, setShowContextPanel] = useState(false)
  const [lightboxImage, setLightboxImage] = useState<string | null>(null) // image lightbox (full-size view)
  const [allUsers, setAllUsers] = useState<UserInfo[]>([])
  const [giftPointsAmount, setGiftPointsAmount] = useState<Record<string, string>>({}) // per-user gift input

  // --- New: image upload + voice call + video call + settings ---
  const [pendingImage, setPendingImage] = useState<string | null>(null) // data URL (legacy single image)
  const [pendingImages, setPendingImages] = useState<string[]>([]) // data URLs (multi-image support)
  const [showSettingsModal, setShowSettingsModal] = useState(false)
  // Settings (persisted to localStorage)
  const [settingsTtsVoice, setSettingsTtsVoice] = useState<string>('tongtong')
  const [settingsDefaultPersonality, setSettingsDefaultPersonality] = useState<PersonalityId | 'ask'>('ask')
  const [showVoiceCallModal, setShowVoiceCallModal] = useState(false)
  const [voiceCallState, setVoiceCallState] = useState<'idle' | 'listening' | 'transcribing' | 'thinking' | 'speaking' | 'error'>('idle')
  const [voiceCallTranscript, setVoiceCallTranscript] = useState('')
  const [voiceCallResponse, setVoiceCallResponse] = useState('')
  const [voiceCallError, setVoiceCallError] = useState('')
  const [voiceCallHistory, setVoiceCallHistory] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([])

  // --- Video call: reuses voice pipeline, but shows webcam preview + AI avatar ---
  const [showVideoCallModal, setShowVideoCallModal] = useState(false)
  const [videoCallState, setVideoCallState] = useState<'idle' | 'listening' | 'transcribing' | 'thinking' | 'speaking' | 'error'>('idle')
  const [videoCallTranscript, setVideoCallTranscript] = useState('')
  const [videoCallResponse, setVideoCallResponse] = useState('')

  // --- Incoming call offer (when AI says "call me" / "video call me") ---
  const [incomingCall, setIncomingCall] = useState<{ personality: Personality | null } | null>(null)
  const [videoCallError, setVideoCallError] = useState('')
  const [videoCallHistory, setVideoCallHistory] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([])

  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const audioRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const voiceCallAudioRef = useRef<HTMLAudioElement | null>(null)
  const videoCallStreamRef = useRef<MediaStream | null>(null)
  const videoCallRecorderRef = useRef<MediaRecorder | null>(null)
  const videoCallChunksRef = useRef<Blob[]>([])
  const videoCallAudioRef = useRef<HTMLAudioElement | null>(null)
  const videoCallVideoRef = useRef<HTMLVideoElement | null>(null)

  const sessionIdRef = useRef<string>('')

  const messagesEndRef = useRef<HTMLDivElement | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const messagesScrollRef = useRef<HTMLDivElement | null>(null)

  // --- Generate / load a stable session id (used for live-user tracking) ---
  useEffect(() => {
    let id = ''
    try { id = localStorage.getItem('chatverse:sid') || '' } catch {}
    if (!id) {
      id = Math.random().toString(36).slice(2, 14) + Date.now().toString(36)
      try { localStorage.setItem('chatverse:sid', id) } catch {}
    }
    sessionIdRef.current = id
  }, [])

  // --- Load settings from localStorage on mount ---
  useEffect(() => {
    try {
      const v = localStorage.getItem('chatverse:voice')
      if (v) setSettingsTtsVoice(v)
      const p = localStorage.getItem('chatverse:defaultPersonality') as PersonalityId | 'ask' | null
      if (p) setSettingsDefaultPersonality(p)
    } catch {}
  }, [])

  // --- Save settings to localStorage on change ---
  useEffect(() => {
    try { localStorage.setItem('chatverse:voice', settingsTtsVoice) } catch {}
  }, [settingsTtsVoice])
  useEffect(() => {
    try { localStorage.setItem('chatverse:defaultPersonality', settingsDefaultPersonality) } catch {}
  }, [settingsDefaultPersonality])

  // --- Detect owner from URL on first mount (?owner=mohammed) ---
  useEffect(() => {
    if (typeof window === 'undefined') return
    try {
      const u = new URL(window.location.href)
      const token = (u.searchParams.get('owner') || '').toLowerCase().trim()
      if (token && OWNERS[token]) {
        setOwnerToken(token)
        try { localStorage.setItem('chatverse:owner', token) } catch {}
        toast.success(`Welcome back, ${OWNERS[token].name}! 👑`, { duration: 3500 })
        // remove ?owner from URL so it isn't shared accidentally
        u.searchParams.delete('owner')
        window.history.replaceState({}, '', u.toString())
      } else {
        // try remembered owner
        const remembered = localStorage.getItem('chatverse:owner')
        if (remembered && OWNERS[remembered]) {
          setOwnerToken(remembered)
        }
      }
    } catch {}
  }, [])

  // --- Auto-create or restore a guest user on first visit (NO login screen) ---
  const afterAuth = useCallback((user: UserInfo) => {
    setCurrentUser(user)
    try { localStorage.setItem('chatverse:userName', user.name) } catch {}
    if (user.plan === 'owner') {
      const matchToken = Object.entries(OWNERS).find(([, o]) => o.name.toLowerCase() === String(user.name).toLowerCase())
      if (matchToken) {
        setOwnerToken(matchToken[0])
        try { localStorage.setItem('chatverse:owner', matchToken[0]) } catch {}
      }
    }
  }, [])

  useEffect(() => {
    if (typeof window === 'undefined') return
    const savedName = localStorage.getItem('chatverse:userName')
    if (savedName) {
      // Restore the saved user (no name prompt — just fetch their data)
      fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: savedName }),
      })
        .then(res => res.json())
        .then(data => {
          if (data.ok) afterAuth(data.user as UserInfo)
          else {
            // If the saved user doesn't exist anymore, show the name prompt
            localStorage.removeItem('chatverse:userName')
            setShowNameModal(true)
          }
        })
        .catch(() => setShowNameModal(true))
    } else {
      // First visit — show the name prompt
      setShowNameModal(true)
    }
  }, [])

  // --- Pending prompt (from Dashboard feature cards) ---
  // We check + queue it here, but the actual send happens in an effect that runs after
  // sendMessage is defined (further down the component). This avoids the temporal dead zone.
  const pendingPromptConsumed = useRef(false)

  // Create user with the entered name (called when user submits the name prompt)
  const createUserWithName = useCallback(async (name: string) => {
    setIsLoggingIn(true)
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      })
      const data = await res.json()
      if (data.ok) {
        afterAuth(data.user as UserInfo)
        setShowNameModal(false)
        setEnteredName('')
        toast.success(`Welcome, ${data.user.name}! You have ${data.user.plan === 'owner' ? 'unlimited' : data.user.points + ' points'}.`)
      } else {
        toast.error(data.error || 'Failed to create user')
      }
    } catch (e: any) {
      toast.error(e?.message || 'Something went wrong')
    }
    setIsLoggingIn(false)
  }, [afterAuth])

  const handleNameSubmit = (e?: React.FormEvent) => {
    e?.preventDefault()
    const name = enteredName.trim()
    if (!name) return
    createUserWithName(name)
  }

  // --- Refresh current user (points/plan) from server ---
  const refreshCurrentUser = useCallback(async () => {
    if (!currentUser) return
    try {
      // Only pass ownerToken if the name matches the owner's display name
      let effectiveOwnerToken: string | undefined = undefined
      if (ownerToken && OWNERS[ownerToken]) {
        const ownerDisplayName = OWNERS[ownerToken].name.toLowerCase()
        if (currentUser.name.toLowerCase() === ownerDisplayName) {
          effectiveOwnerToken = ownerToken
        }
      }
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: currentUser.name, ownerToken: effectiveOwnerToken }),
      })
      const data = await res.json()
      if (res.ok && data.ok) setCurrentUser(data.user as UserInfo)
    } catch {}
  }, [currentUser, ownerToken])

  const ownerInfo = ownerToken ? OWNERS[ownerToken] : null

  // --- Live user counter: heartbeat + poll ---
  useEffect(() => {
    let active = true
    const heartbeat = async () => {
      try {
        const res = await fetch('/api/stats', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId: sessionIdRef.current }),
        })
        const data = await res.json()
        if (active && data?.ok) setOnlineCount(data.online as number)
      } catch {}
    }
    heartbeat()
    const interval = setInterval(heartbeat, 30_000) // 30s (was 15s — reduces API call volume)
    return () => { active = false; clearInterval(interval) }
  }, [])

  // --- Load announcements + poll for new ones ---
  useEffect(() => {
    let active = true
    const loadAnnouncements = async () => {
      try {
        const res = await fetch('/api/announcements')
        const data = await res.json()
        if (active && data?.ok && Array.isArray(data.announcements)) {
          setAnnouncements(data.announcements)
        }
      } catch {}
    }
    loadAnnouncements()
    const interval = setInterval(loadAnnouncements, 60_000) // 60s (was 20s — reduces API call volume)
    return () => { active = false; clearInterval(interval) }
  }, [])

  // --- Post an announcement (owner only) ---
  const postAnnouncement = async () => {
    const text = newAnnouncementText.trim()
    if (!text) return
    if (!ownerToken) {
      toast.error('Only owners can post announcements.')
      return
    }
    try {
      const res = await fetch('/api/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerToken, text }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to post')
      setNewAnnouncementText('')
      setShowAnnouncementModal(false)
      toast.success('Announcement posted! 📣')
      // Reload announcements
      const r2 = await fetch('/api/announcements')
      const d2 = await r2.json()
      if (d2?.ok) setAnnouncements(d2.announcements)
    } catch (e: any) {
      toast.error(e?.message || 'Failed to post announcement')
    }
  }

  // --- Events: load (everyone) + post (owner only) + delete (owner) ---
  useEffect(() => {
    let active = true
    const loadEvents = async () => {
      try {
        const res = await fetch('/api/events')
        const data = await res.json()
        if (active && data?.ok && Array.isArray(data.events)) setEvents(data.events)
      } catch {}
    }
    loadEvents()
    const interval = setInterval(loadEvents, 90_000) // 90s (was 30s — reduces API call volume)
    return () => { active = false; clearInterval(interval) }
  }, [])

  const postEvent = async () => {
    if (!ownerToken) { toast.error('Only owners can post events'); return }
    const { title, description, date, time } = newEvent
    if (!title.trim()) { toast.error('Event title is required'); return }
    if (!date) { toast.error('Event date is required'); return }
    try {
      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerToken, title: title.trim(), description: description.trim(), date, time }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to post event')
      setNewEvent({ title: '', description: '', date: '', time: '' })
      setShowEventModal(false)
      toast.success('Event posted! 📅')
      const r2 = await fetch('/api/events')
      const d2 = await r2.json()
      if (d2?.ok) setEvents(d2.events)
    } catch (e: any) {
      toast.error(e?.message || 'Failed to post event')
    }
  }

  const deleteEvent = async (id: string) => {
    if (!ownerToken) return
    try {
      const res = await fetch(`/api/events?id=${encodeURIComponent(id)}&ownerToken=${encodeURIComponent(ownerToken)}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to delete event')
      toast.success('Event deleted')
      const r2 = await fetch('/api/events')
      const d2 = await r2.json()
      if (d2?.ok) setEvents(d2.events)
    } catch (e: any) {
      toast.error(e?.message || 'Failed to delete event')
    }
  }

  // --- Generate a 5-second AI video ---
  const generateVideo = async () => {
    const prompt = videoPrompt.trim()
    if (!prompt) return
    setVideoStatus('generating')
    setVideoResult(null)
    try {
      const res = await fetch('/api/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, userName: currentUser?.name || undefined }),
      })
      const data = await res.json()
      if (res.status === 403 && data?.code === 'PLAN_REQUIRED') {
        // Plan required — show upgrade modal
        setShowVideoModal(false)
        setShowPlansModal(true)
        throw new Error(data.message || 'Plan required')
      }
      if (res.status === 402 && data?.code === 'OUT_OF_POINTS') {
        setShowVideoModal(false)
        setShowOutOfPointsModal(true)
        throw new Error('OUT_OF_POINTS')
      }
      if (!res.ok || !data.ok) throw new Error(data.error || data.message || 'Failed to generate video')
      // Update points if returned
      if (data.points) {
        setCurrentUser((prev) => prev ? { ...prev, points: data.points.points, plan: data.points.plan } : prev)
      }
      setVideoResult({
        videoUrl: data.videoUrl,
        imageUrl: data.imageUrl,
        prompt: data.prompt,
      })
      setVideoStatus('done')
      toast.success('Video ready! 🎬')
    } catch (e: any) {
      setVideoStatus('error')
      if (e?.message !== 'OUT_OF_POINTS' && e?.message !== 'Plan required') {
        toast.error(e?.message || 'Failed to generate video')
      }
    }
  }

  // --- Generate an AI image ---
  const generateImage = async () => {
    const prompt = imageGenPrompt.trim()
    if (!prompt) return
    setImageGenStatus('generating')
    setImageGenResult(null)
    try {
      const res = await fetch('/api/image-gen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, userName: currentUser?.name || undefined }),
      })
      const data = await res.json()
      if (res.status === 402 && data?.code === 'OUT_OF_POINTS') {
        setShowImageGenModal(false)
        setShowOutOfPointsModal(true)
        throw new Error('OUT_OF_POINTS')
      }
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to generate image')
      if (data.points) {
        setCurrentUser((prev) => prev ? { ...prev, points: data.points.points, plan: data.points.plan } : prev)
      }
      setImageGenResult({ imageUrl: data.imageUrl, prompt: data.prompt })
      setImageGenStatus('done')
      toast.success('Image generated! 🎨')
    } catch (e: any) {
      setImageGenStatus('error')
      if (e?.message !== 'OUT_OF_POINTS') {
        toast.error(e?.message || 'Failed to generate image')
      }
    }
  }

  // --- Owner link copy ---
  const copyOwnerLink = useCallback((token: string) => {
    if (typeof window === 'undefined') return
    const url = `${window.location.origin}/?owner=${token}`
    navigator.clipboard.writeText(url).then(() => {
      toast.success(`${OWNERS[token].name}'s link copied!`, {
        description: url,
        duration: 4000,
      })
    })
  }, [])

  // --- Sign out as owner ---
  const signOutOwner = () => {
    setOwnerToken(null)
    try { localStorage.removeItem('chatverse:owner') } catch {}
    toast.info('Signed out of owner mode')
  }

  // --- Owner: load all users (for users dashboard) ---
  const loadAllUsers = useCallback(async () => {
    if (!ownerToken) return
    try {
      const res = await fetch(`/api/users?ownerToken=${encodeURIComponent(ownerToken)}`)
      const data = await res.json()
      if (res.ok && data.ok) setAllUsers(data.users as UserInfo[])
    } catch {}
  }, [ownerToken])

  // --- Owner: gift points to a user ---
  const giftPointsToUser = useCallback(async (userName: string, points: number) => {
    if (!ownerToken) return
    try {
      const res = await fetch('/api/users/gift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerToken, userName, points }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to gift points')
      toast.success(`Gifted ${points > 0 ? '+' : ''}${points} points to ${userName}`)
      // Refresh the users list + current user (in case it was self)
      await loadAllUsers()
      await refreshCurrentUser()
    } catch (e: any) {
      toast.error(e?.message || 'Failed to gift points')
    }
  }, [ownerToken, loadAllUsers, refreshCurrentUser])

  // --- Owner: upgrade a user's plan ---
  const upgradeUserPlan = useCallback(async (userName: string, plan: PlanId) => {
    if (!ownerToken) return
    try {
      const res = await fetch('/api/users/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerToken, userName, plan }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || 'Failed to upgrade plan')
      toast.success(`${userName} upgraded to ${plan.toUpperCase()}! 🎉`)
      await loadAllUsers()
      await refreshCurrentUser()
    } catch (e: any) {
      toast.error(e?.message || 'Failed to upgrade plan')
    }
  }, [ownerToken, loadAllUsers, refreshCurrentUser])

  // --- Buy a premium plan using the user's own points ---
  const buyPlanWithPoints = useCallback(async (plan: 'plus' | 'premium') => {
    if (!currentUser?.name) {
      toast.error('Please sign in first.')
      return
    }
    setBuyingPlan(plan)
    try {
      const res = await fetch('/api/premium/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName: currentUser.name, plan }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        if (data?.error === 'INSUFFICIENT_POINTS') {
          toast.error(`You need ${data.needed} pts but only have ${data.have}. Ask Mohammed Zayyan to gift you points.`)
        } else {
          throw new Error(data.error || 'Failed to buy plan')
        }
        return
      }
      toast.success(`🎉 Upgraded to ${plan.toUpperCase()}! Enjoy your premium features.`)
      await refreshCurrentUser()
      setShowPlansModal(false)
    } catch (e: any) {
      toast.error(e?.message || 'Failed to buy plan')
    } finally {
      setBuyingPlan(null)
    }
  }, [currentUser, refreshCurrentUser])

  // --- Theme: load + apply to <html> ---
  useEffect(() => {
    const saved = (typeof window !== 'undefined' && localStorage.getItem(THEME_KEY)) as 'light' | 'dark' | null
    setTheme(saved || 'dark')
  }, [])

  useEffect(() => {
    if (typeof document === 'undefined') return
    document.documentElement.classList.toggle('dark', theme === 'dark')
    if (typeof window !== 'undefined') localStorage.setItem(THEME_KEY, theme)
  }, [theme])

  // --- Load conversations from localStorage (per-user) ---
  // Only reload when the user's NAME changes (not on every points/plan update).
  // This prevents the conversation list from being overwritten when points are
  // updated after each message.
  const currentUserNameRef = useRef<string | null>(null)
  useEffect(() => {
    const newName = currentUser?.name || null
    // Only reload if the name actually changed (or user logged out)
    if (newName === currentUserNameRef.current) return
    currentUserNameRef.current = newName

    if (!newName) {
      setConversations([])
      setActiveId(null)
      return
    }
    try {
      const key = getUserStorageKey(newName)
      const raw = localStorage.getItem(key)
      if (raw) {
        const parsed = JSON.parse(raw) as Conversation[]
        if (Array.isArray(parsed) && parsed.length > 0) {
          setConversations(parsed)
          setActiveId(parsed[0].id)
        } else {
          setConversations([])
          setActiveId(null)
        }
      } else {
        setConversations([])
        setActiveId(null)
      }
    } catch (e) {
      console.warn('[ChatVerse] failed to load conversations:', e)
      setConversations([])
      setActiveId(null)
    }
  }, [currentUser?.name]) // only depends on the name, not the full user object

  // --- Save conversations to localStorage (per-user) ---
  useEffect(() => {
    const name = currentUserNameRef.current
    if (!name || conversations.length === 0) return
    try {
      const key = getUserStorageKey(name)
      const toSave = conversations.slice(0, 50)
      localStorage.setItem(key, JSON.stringify(toSave))
    } catch (e) {
      console.warn('[ChatVerse] failed to save conversations:', e)
    }
  }, [conversations])

  const activeConversation = useMemo(
    () => conversations.find((c) => c.id === activeId) || null,
    [conversations, activeId]
  )

  const activePersonality = activeConversation
    ? getPersonality(activeConversation.personalityId)
    : null

  // --- Auto-scroll to latest message ---
  useEffect(() => {
    if (!activeConversation) return
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [activeConversation?.messages, isThinking])

  // --- Filter conversations by search ---
  const filteredConversations = useMemo(() => {
    if (!search.trim()) return conversations
    const q = search.toLowerCase()
    return conversations.filter((c) => {
      const p = getPersonality(c.personalityId)
      return (
        c.title.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q))
      )
    })
  }, [conversations, search])

  // --- Create a new conversation with a given personality ---
  const createConversation = (personalityId: PersonalityId) => {
    const conv: Conversation = {
      id: uid(),
      personalityId,
      title: `Chat with ${getPersonality(personalityId).name}`,
      messages: [],
      createdAt: now(),
      updatedAt: now(),
    }
    setConversations((prev) => [conv, ...prev])
    setActiveId(conv.id)
    setShowPersonalityPicker(false)
    setMobileSidebar(false)
    setMobileChat(true)
  }

  // --- Delete a conversation ---
  const deleteConversation = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id))
    if (activeId === id) {
      const remaining = conversations.filter((c) => c.id !== id)
      setActiveId(remaining.length > 0 ? remaining[0].id : null)
    }
    toast.success('Conversation deleted')
  }

  // --- Send message ---
  const sendMessage = async (e?: React.FormEvent, overrideContent?: string) => {
    e?.preventDefault()
    const content = (overrideContent ?? inputMessage).trim()
    const images = pendingImages.length > 0 ? pendingImages : (pendingImage ? [pendingImage] : [])
    if ((!content && images.length === 0) || isThinking) return

    // --- Owner slash commands (only for owners) ---
    // /<text> → send a global announcement
    // /gift <username> <amount> → gift points
    // /event <title> <date> <time> → post an event
    if (ownerToken && content.startsWith('/')) {
      const slashMsg: ChatMessage = {
        id: uid(),
        role: 'user',
        content,
        timestamp: now(),
        status: 'sending',
      }
      let conv = activeConversation
      if (!conv) {
        conv = {
          id: uid(),
          personalityId: 'general',
          title: titleFrom(content),
          messages: [],
          createdAt: now(),
          updatedAt: now(),
        }
        setConversations((prev) => [conv as Conversation, ...prev])
        setActiveId(conv.id)
      }
      setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: [...c.messages, slashMsg], updatedAt: now() } : c))
      setInputMessage('')

      // Parse the slash command
      const cmdText = content.slice(1).trim() // remove leading /
      if (cmdText.toLowerCase().startsWith('gift ')) {
        // /gift USERNAME AMOUNT
        const parts = cmdText.slice(5).trim().split(/\s+/)
        const giftUser = parts[0]
        const giftAmount = parseInt(parts[1] || '0', 10)
        if (giftUser && giftAmount > 0) {
          try {
            const r = await fetch('/api/users/gift', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerToken, userName: giftUser, points: giftAmount }) })
            const d = await r.json()
            if (d.ok) {
              toast.success(`🎁 Gifted ${giftAmount} points to ${giftUser}!`)
              setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: [...c.messages, { id: uid(), role: 'assistant', content: `🎁 Gifted ${giftAmount} points to ${giftUser}!`, timestamp: now(), personalityId: 'general', status: 'sent' }], updatedAt: now() } : c))
            } else { toast.error(d.error || 'Failed to gift points') }
          } catch { toast.error('Failed to gift points') }
        }
      } else if (cmdText.toLowerCase().startsWith('event ')) {
        // /event TITLE DATE TIME
        const parts = cmdText.slice(6).trim().split(/\s+/)
        const evtTitle = parts.slice(0, -2).join(' ') || parts[0]
        const evtDate = parts[parts.length - 2] || ''
        const evtTime = parts[parts.length - 1] || '00:00'
        if (evtTitle && evtDate) {
          try {
            const r = await fetch('/api/events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerToken, title: evtTitle, description: '', date: evtDate, time: evtTime }) })
            const d = await r.json()
            if (d.ok) {
              toast.success('📅 Event posted!')
              fetch('/api/events').then(r => r.json()).then(d => { if (d?.ok) setEvents(d.events) })
              setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: [...c.messages, { id: uid(), role: 'assistant', content: `📅 Event posted: "${evtTitle}" on ${evtDate} at ${evtTime}`, timestamp: now(), personalityId: 'general', status: 'sent' }], updatedAt: now() } : c))
            } else { toast.error(d.error || 'Failed to post event') }
          } catch { toast.error('Failed to post event') }
        }
      } else {
        // /<anything> → global announcement
        const message = cmdText
        if (message) {
          try {
            const r = await fetch('/api/announcements', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerToken, text: message }) })
            const d = await r.json()
            if (d.ok) {
              toast.success('📢 Global announcement sent!')
              fetch('/api/announcements').then(r => r.json()).then(d => { if (d?.ok) setAnnouncements(d.announcements) })
              setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: [...c.messages, { id: uid(), role: 'assistant', content: `📢 Global announcement sent to all users: "${message}"`, timestamp: now(), personalityId: 'general', status: 'sent' }], updatedAt: now() } : c))
            } else { toast.error(d.error || 'Failed to send') }
          } catch { toast.error('Failed to send announcement') }
        }
      }
      return // skip the normal AI chat flow
    }

    // --- Normal chat flow ---

    // If no active conversation, create one with the chosen default personality (from settings)
    let conv = activeConversation
    if (!conv) {
      const initialPersonality: PersonalityId = settingsDefaultPersonality === 'ask' ? 'general' : settingsDefaultPersonality
      conv = {
        id: uid(),
        personalityId: initialPersonality,
        title: titleFrom(content || (images.length > 1 ? `${images.length} images` : 'Image question')),
        messages: [],
        createdAt: now(),
        updatedAt: now(),
      }
      setConversations((prev) => [conv as Conversation, ...prev])
      setActiveId(conv.id)
    }

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content,
      timestamp: now(),
      status: 'sending',
      imagesBase64: images.length > 0 ? images : undefined,
    }
    const aiPlaceholderId = uid()
    const aiPlaceholder: ChatMessage = {
      id: aiPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: now() + 1,
      personalityId: conv.personalityId,
      status: 'sending',
    }

    // Update conversation with user message + AI placeholder
    setConversations((prev) =>
      prev.map((c) =>
        c.id === conv!.id
          ? {
              ...c,
              title: c.messages.length === 0 ? titleFrom(content || (images.length > 1 ? `${images.length} images` : 'Image question')) : c.title,
              messages: [...c.messages, userMsg, aiPlaceholder],
              updatedAt: now(),
            }
          : c
      )
    )
    setInputMessage('')
    setPendingImage(null)
    setPendingImages([])
    setIsThinking(true)

    // Build history (exclude the placeholder we just added)
    const history = conv.messages
      .filter((m) => m.role === 'user' || (m.role === 'assistant' && m.content))
      .map((m) => ({ role: m.role, content: m.content }))

    try {
      abortRef.current = new AbortController()
      // Route to vision endpoint if any image is attached, otherwise regular chat
      const endpoint = images.length > 0 ? '/api/chat-vision' : '/api/chat'
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: content,
          imagesBase64: images.length > 0 ? images : undefined,
          history,
          personalityId: conv.personalityId,
          userName: currentUser?.name || undefined,
          isOwner: !!ownerToken,
        }),
        signal: abortRef.current.signal,
      })
      const data = await res.json()
      if (res.status === 402 && data?.code === 'OUT_OF_POINTS') {
        // Out of points — show upgrade modal
        setShowOutOfPointsModal(true)
        throw new Error('OUT_OF_POINTS')
      }
      if (res.status === 402 && data?.code === 'DAILY_LIMIT_REACHED') {
        // Free user hit daily message limit — show upgrade modal
        toast.error('You reached your daily 50-message limit. Upgrade to Plus or Premium for unlimited messages!')
        setShowPlansModal(true)
        throw new Error('DAILY_LIMIT_REACHED')
      }
      if (!res.ok || !data.ok) {
        throw new Error(data.error || data.message || 'Failed to get response')
      }
      // Update points if returned
      if (data.points) {
        setCurrentUser((prev) => prev ? { ...prev, points: data.points.points, plan: data.points.plan } : prev)
      }
      const aiText: string = data.response || ''
      // Detect call offer from the AI ("CALL_OFFER:video")
      const callOfferMatch = aiText.trim().match(/^CALL_OFFER:(\w+)$/i)
      let displayText = aiText
      if (callOfferMatch) {
        const callType = callOfferMatch[1].toLowerCase()
        if (callType === 'video' || callType === 'voice') {
          setIncomingCall({ personality: getPersonality(conv!.personalityId) })
        }
        displayText = callType === 'video'
          ? '📞 Calling you on video... please accept the incoming call.'
          : '📞 Calling you... please accept the incoming call.'
      }

      // Detect owner commands from the AI ("OWNER_CMD:ANNOUNCE:msg" etc.)
      const ownerCmdMatch = aiText.trim().match(/^OWNER_CMD:(\w+)(?::(.*))?$/i)
      if (ownerCmdMatch && ownerToken) {
        const cmdType = ownerCmdMatch[1].toUpperCase()
        const cmdArgs = ownerCmdMatch[2] || ''
        if (cmdType === 'ANNOUNCE') {
          const message = cmdArgs.trim()
          if (message) {
            fetch('/api/announcements', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ownerToken, text: message }),
            }).then(() => {
              toast.success('📢 Global announcement sent!')
              fetch('/api/announcements').then(r => r.json()).then(d => { if (d?.ok) setAnnouncements(d.announcements) })
            }).catch(() => toast.error('Failed to send announcement'))
          }
          displayText = `📢 Global announcement sent to all users: "${message}"`
        } else if (cmdType === 'GIFT') {
          // Format: OWNER_CMD:GIFT:USERNAME:AMOUNT
          const parts = cmdArgs.split(':')
          const giftUser = parts[0]?.trim()
          const giftAmount = parseInt(parts[1] || '0', 10)
          if (giftUser && giftAmount > 0) {
            fetch('/api/users/gift', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ownerToken, userName: giftUser, points: giftAmount }),
            }).then(r => r.json()).then(d => {
              if (d.ok) {
                toast.success(`🎁 Gifted ${giftAmount} points to ${giftUser}!`)
                refreshCurrentUser()
              } else {
                toast.error(d.error || 'Failed to gift points')
              }
            }).catch(() => toast.error('Failed to gift points'))
            displayText = `🎁 Gifted ${giftAmount} points to ${giftUser}!`
          } else {
            displayText = `❌ Could not parse gift command. Usage: give N points to USERNAME`
          }
        } else if (cmdType === 'GIFT_SELF') {
          // Owner wants to give points to themselves — but owners have unlimited, so just confirm
          const giftAmount = parseInt(cmdArgs.trim() || '0', 10)
          if (giftAmount > 0) {
            toast.success(`✅ You have unlimited points as an owner!`)
            displayText = `✅ As an owner, you already have unlimited points! No need to gift yourself more.`
          }
        } else if (cmdType === 'EVENT') {
          // Format: OWNER_CMD:EVENT:TITLE:DATE:TIME
          const parts = cmdArgs.split(':')
          const evtTitle = parts[0]?.trim()
          const evtDate = parts[1]?.trim()
          const evtTime = parts[2]?.trim() || '00:00'
          if (evtTitle && evtDate) {
            fetch('/api/events', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ownerToken, title: evtTitle, description: '', date: evtDate, time: evtTime }),
            }).then(() => {
              toast.success('📅 Event posted!')
              fetch('/api/events').then(r => r.json()).then(d => { if (d?.ok) setEvents(d.events) })
            }).catch(() => toast.error('Failed to post event'))
            displayText = `📅 Event posted: "${evtTitle}" on ${evtDate} at ${evtTime}`
          }
        }
      }

      // Detect inline image generation request ("IMG_GEN:prompt")
      const imgGenMatch = aiText.trim().match(/^IMG_GEN:(.+)$/i)
      // Detect inline image search request ("IMG_SEARCH:query") — fetches REAL images from the web
      const imgSearchMatch = aiText.trim().match(/^IMG_SEARCH:(.+)$/i)

      if (imgGenMatch) {
        const imgPrompt = imgGenMatch[1].trim()
        displayText = `🎨 Generating image: "${imgPrompt}"`
        const genType = 'image' as const
        // Generate the image in the background
        fetch('/api/image-gen', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: imgPrompt, userName: currentUser?.name || undefined }),
        }).then(r => r.json()).then(d => {
          if (d.ok && d.imageUrl) {
            setConversations((prev) =>
              prev.map((c) =>
                c.id === conv!.id
                  ? {
                      ...c,
                      messages: c.messages.map((m) =>
                        m.id === aiPlaceholderId
                          ? { ...m, content: `🎨 Here's your image:`, imagesBase64: [d.imageUrl], status: 'sent' as const, timestamp: now() }
                          : m
                      ),
                    }
                  : c
              )
            )
            if (d.points) setCurrentUser((prev) => prev ? { ...prev, points: d.points.points, plan: d.points.plan } : prev)
            toast.success('Image generated! 🎨')
          } else {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ Failed to generate image. Please try again.`, status: 'error' as const } : m) } : c))
            toast.error('Failed to generate image')
          }
        }).catch(() => {
          toast.error('Failed to generate image')
        })
      }

      // --- Image search: fetch real images from Wikimedia Commons (client-side, no API key needed) ---
      if (imgSearchMatch) {
        const searchQuery = imgSearchMatch[1].trim()
        displayText = `🔍 Searching the web for: "${searchQuery}"`
        const searchType = 'search' as const
        // Fetch from Wikimedia Commons API directly from the browser (avoids server-side rate limits)
        const wikiUrl = `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(searchQuery)}&gsrnamespace=6&gsrlimit=5&prop=imageinfo&iiprop=url|mime&iiurlwidth=800`
        fetch(wikiUrl)
          .then(r => r.json())
          .then(d => {
            const pages = d?.query?.pages || {}
            const imageUrls: string[] = []
            for (const page of Object.values(pages) as any[]) {
              const info = page?.imageinfo?.[0]
              if (!info) continue
              const mime = info.mime || ''
              if (!mime.startsWith('image/') || mime === 'image/svg+xml') continue
              const url = info.thumburl || info.url
              if (url) imageUrls.push(url)
            }
            if (imageUrls.length > 0) {
              setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `🔍 Here are real images from the web for "${searchQuery}":`, imagesBase64: imageUrls, status: 'sent' as const, timestamp: now() } : m) } : c))
              toast.success(`Found ${imageUrls.length} images! 📸`)
            } else {
              setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ No images found for "${searchQuery}". Try a different search term.`, status: 'error' as const } : m) } : c))
              toast.error('No images found')
            }
          })
          .catch(() => {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ Image search failed. Please try again.`, status: 'error' as const } : m) } : c))
            toast.error('Image search failed')
          })
      }

      // Detect inline video generation request ("VID_GEN:prompt")
      const vidGenMatch = aiText.trim().match(/^VID_GEN:(.+)$/i)
      if (vidGenMatch) {
        const vidPrompt = vidGenMatch[1].trim()
        displayText = `🎬 Generating video: "${vidPrompt}"... This can take 30-90 seconds.`
        fetch('/api/video', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: vidPrompt, userName: currentUser?.name || undefined }),
        }).then(r => r.json()).then(d => {
          if (d.ok && d.videoUrl) {
            setConversations((prev) =>
              prev.map((c) =>
                c.id === conv!.id
                  ? {
                      ...c,
                      messages: c.messages.map((m) =>
                        m.id === aiPlaceholderId
                          ? { ...m, content: `🎬 Here's your 5-second video:`, status: 'sent' as const, timestamp: now() }
                          : m
                      ),
                    }
                  : c
              )
            )
            // Add a second message with the video URL as markdown link
            setTimeout(() => {
              setConversations((prev) =>
                prev.map((c) =>
                  c.id === conv!.id
                    ? { ...c, messages: [...c.messages, { id: uid() as any, role: 'assistant' as const, content: `[▶️ Watch your video](${d.videoUrl})\n\n[⬇️ Download video](${d.videoUrl})`, timestamp: now(), personalityId: 'general' as PersonalityId, status: 'sent' as const }] }
                    : c
                )
              )
            }, 100)
            if (d.points) setCurrentUser((prev) => prev ? { ...prev, points: d.points.points, plan: d.points.plan } : prev)
            toast.success('Video generated! 🎬')
          } else {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ Failed to generate video. Please try again.`, status: 'error' as const } : m) } : c))
            toast.error('Failed to generate video')
          }
        }).catch(() => {
          toast.error('Failed to generate video')
        })
      }

      // Detect inline news request ("NEWS:category")
      const newsMatch = aiText.trim().match(/^NEWS:(.*)$/i)
      if (newsMatch) {
        const category = newsMatch[1].trim().toLowerCase() || 'general'
        displayText = `📰 Fetching latest ${category} news...`
        fetch(`/api/news?category=${encodeURIComponent(category)}`).then(r => r.json()).then(d => {
          if (d.ok && d.news && d.news.length > 0) {
            let newsText = `📰 **Latest ${category} news:**\n\n`
            d.news.forEach((item: any, i: number) => {
              newsText += `**${i + 1}. ${item.title}**\n${item.description}\n[${item.pubDate ? new Date(item.pubDate).toLocaleDateString() : ''}]\n\n`
            })
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: newsText, status: 'sent' as const, timestamp: now() } : m) } : c))
          } else {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: '❌ Failed to fetch news. Please try again.', status: 'error' as const } : m) } : c))
          }
        }).catch(() => {
          setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: '❌ Failed to fetch news.', status: 'error' as const } : m) } : c))
        })
      }

      // Detect inline weather request ("WEATHER:city")
      const weatherMatch = aiText.trim().match(/^WEATHER:(.+)$/i)
      if (weatherMatch) {
        const city = weatherMatch[1].trim()
        displayText = `🌤️ Fetching weather for ${city}...`
        fetch(`/api/weather?city=${encodeURIComponent(city)}`).then(r => r.json()).then(d => {
          if (d.ok) {
            let weatherText = `🌤️ **Weather in ${d.city}${d.region ? ', ' + d.region : ''}, ${d.country}**\n\n`
            weatherText += `${d.emoji} **${d.description}**\n`
            weatherText += `🌡️ Temperature: **${d.temperature}°C** (feels like ${d.feelsLike}°C)\n`
            weatherText += `💧 Humidity: ${d.humidity}%\n`
            weatherText += `💨 Wind: ${d.windSpeed} km/h\n\n`
            if (d.daily && d.daily.length > 0) {
              weatherText += `**3-day forecast:**\n`
              d.daily.forEach((day: any) => {
                weatherText += `${day.emoji} ${day.date}: ${day.min}°C - ${day.max}°C (${day.desc})\n`
              })
            }
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: weatherText, status: 'sent' as const, timestamp: now() } : m) } : c))
          } else {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ ${d.error || 'Failed to fetch weather.'}`, status: 'error' as const } : m) } : c))
          }
        }).catch(() => {
          setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: '❌ Failed to fetch weather.', status: 'error' as const } : m) } : c))
        })
      }

      // Detect inline web search request ("WEB_SEARCH:query")
      const webSearchMatch = aiText.trim().match(/^WEB_SEARCH:(.+)$/i)
      if (webSearchMatch) {
        const searchQuery = webSearchMatch[1].trim()
        displayText = `🔍 Searching the web for "${searchQuery}"...`
        fetch(`/api/web-search?q=${encodeURIComponent(searchQuery)}`).then(r => r.json()).then(d => {
          if (d.ok && d.results && d.results.length > 0) {
            let searchText = `🔍 **Web search results for "${searchQuery}":**\n\n`
            if (d.answer) {
              searchText += `**Quick answer:** ${d.answer}\n\n`
            }
            d.results.forEach((r: any, i: number) => {
              searchText += `**${i + 1}. ${r.title}**\n${r.description}\n`
              if (r.url) searchText += `[Read more](${r.url})\n`
              searchText += `\n`
            })
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: searchText, status: 'sent' as const, timestamp: now() } : m) } : c))
          } else {
            setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: `❌ No results found for "${searchQuery}".`, status: 'error' as const } : m) } : c))
          }
        }).catch(() => {
          setConversations((prev) => prev.map((c) => c.id === conv!.id ? { ...c, messages: c.messages.map((m) => m.id === aiPlaceholderId ? { ...m, content: '❌ Search failed.', status: 'error' as const } : m) } : c))
        })
      }

      setConversations((prev) =>
        prev.map((c) =>
          c.id === conv!.id
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === aiPlaceholderId
                    ? {
                        ...m,
                        content: displayText,
                        status: (imgGenMatch || imgSearchMatch || vidGenMatch || newsMatch || weatherMatch || webSearchMatch) ? 'generating' : 'sent',
                        generatingType: imgGenMatch ? 'image' : imgSearchMatch ? 'search' : vidGenMatch ? 'video' : newsMatch ? 'news' : weatherMatch ? 'weather' : webSearchMatch ? 'search' : undefined,
                        timestamp: now(),
                      }
                    : m.role === 'user' && m.id === userMsg.id
                    ? { ...m, status: 'sent' }
                    : m
                ),
                updatedAt: now(),
              }
            : c
        )
      )
    } catch (err: any) {
      const errorMsg = err?.name === 'AbortError' ? 'Stopped.' : err?.message || 'Something went wrong.'
      setConversations((prev) =>
        prev.map((c) =>
          c.id === conv!.id
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === aiPlaceholderId
                    ? { ...m, content: `⚠️ ${errorMsg}`, status: 'error' }
                    : m.id === userMsg.id
                    ? { ...m, status: 'sent' }
                    : m
                ),
              }
            : c
        )
      )
      toast.error(errorMsg)
    } finally {
      setIsThinking(false)
      abortRef.current = null
    }
  }

  // --- New: image upload handler ---
  const onPickImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    const validFiles: File[] = []
    for (let i = 0; i < files.length; i++) {
      const f = files[i]
      if (!/image\/(png|jpeg|jpg|webp|gif)/i.test(f.type)) {
        toast.error(`${f.name}: Only PNG, JPEG, WebP, or GIF images are supported.`)
        continue
      }
      if (f.size > 5 * 1024 * 1024) {
        toast.error(`${f.name}: Image too large (max 5MB).`)
        continue
      }
      validFiles.push(f)
    }
    if (validFiles.length === 0) {
      e.target.value = ''
      return
    }
    // Limit to 4 images total per message
    const remaining = 4 - pendingImages.length
    if (remaining <= 0) {
      toast.error('You can attach up to 4 images per message.')
      e.target.value = ''
      return
    }
    const toRead = validFiles.slice(0, remaining)
    if (validFiles.length > remaining) {
      toast.error(`You can attach up to 4 images. Only the first ${remaining} were added.`)
    }
    for (const f of toRead) {
      const reader = new FileReader()
      reader.onload = () => {
        const dataUrl = reader.result as string
        setPendingImages((prev) => [...prev, dataUrl])
      }
      reader.onerror = () => toast.error(`Failed to read ${f.name}.`)
      reader.readAsDataURL(f)
    }
    // reset input value so the same file can be re-selected
    e.target.value = ''
  }

  const removePendingImage = (idx: number) => {
    setPendingImages((prev) => prev.filter((_, i) => i !== idx))
  }

  // --- Paste image from clipboard (Ctrl+V / long-press paste on mobile) ---
  const handlePaste = useCallback((e: ClipboardEvent) => {
    // Only handle paste when the chat input area is in view (mobile) or always on desktop
    const items = e.clipboardData?.items
    if (!items || items.length === 0) return
    const imageFiles: File[] = []
    for (let i = 0; i < items.length; i++) {
      const item = items[i]
      if (item.kind === 'file' && item.type.startsWith('image/')) {
        const file = item.getAsFile()
        if (file) {
          // Normalize filename for pasted images
          if (!file.name || file.name === 'image.png') {
            const ext = file.type.split('/')[1] || 'png'
            Object.defineProperty(file, 'name', { value: `pasted-${Date.now()}.${ext}`, configurable: true })
          }
          imageFiles.push(file)
        }
      }
    }
    if (imageFiles.length === 0) return
    // Don't prevent default if no images — let text paste work normally
    e.preventDefault()
    // Reuse the same validation logic as onPickImage
    const validFiles: File[] = []
    for (const f of imageFiles) {
      if (!/image\/(png|jpeg|jpg|webp|gif|bmp)/i.test(f.type)) {
        toast.error(`Only PNG, JPEG, WebP, or GIF images are supported.`)
        continue
      }
      if (f.size > 5 * 1024 * 1024) {
        toast.error(`Pasted image too large (max 5MB).`)
        continue
      }
      validFiles.push(f)
    }
    if (validFiles.length === 0) return
    const remaining = 4 - pendingImages.length
    if (remaining <= 0) {
      toast.error('You can attach up to 4 images per message.')
      return
    }
    const toRead = validFiles.slice(0, remaining)
    if (validFiles.length > remaining) {
      toast.error(`You can attach up to 4 images. Only the first ${remaining} were added.`)
    }
    for (const f of toRead) {
      const reader = new FileReader()
      reader.onload = () => {
        const dataUrl = reader.result as string
        setPendingImages((prev) => [...prev, dataUrl])
      }
      reader.onerror = () => toast.error(`Failed to read pasted image.`)
      reader.readAsDataURL(f)
    }
    toast.success(`Pasted ${toRead.length === 1 ? 'image' : `${toRead.length} images`} added!`)
  }, [pendingImages.length])

  // Attach the paste listener to the window (so it works anywhere on the chat page)
  useEffect(() => {
    if (typeof window === 'undefined') return
    const listener = (e: ClipboardEvent) => handlePaste(e)
    window.addEventListener('paste', listener)
    return () => window.removeEventListener('paste', listener)
  }, [handlePaste])

  // --- New: Voice call - record + transcribe + AI + TTS ---
  const startVoiceCall = async () => {
    setVoiceCallError('')
    setVoiceCallTranscript('')
    setVoiceCallResponse('')
    setVoiceCallState('listening')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      audioRecorderRef.current = mr
      audioChunksRef.current = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data)
      }
      mr.onstop = async () => {
        // Stop all tracks so the mic indicator turns off
        stream.getTracks().forEach((t) => t.stop())
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' })
        if (blob.size === 0) {
          setVoiceCallState('error')
          setVoiceCallError('No audio captured. Please try again.')
          return
        }
        // Convert to base64
        const reader = new FileReader()
        reader.onloadend = async () => {
          const audioDataUrl = reader.result as string
          setVoiceCallState('transcribing')
          try {
            // 1. Transcribe via ASR
            const asrRes = await fetch('/api/asr', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audioBase64: audioDataUrl }),
            })
            const asrData = await asrRes.json()
            if (!asrRes.ok || !asrData.ok) throw new Error(asrData.error || 'Transcription failed')
            const transcript = (asrData.text || '').toString().trim()
            setVoiceCallTranscript(transcript)
            if (!transcript) {
              setVoiceCallState('error')
              setVoiceCallError("Couldn't hear you — try again.")
              return
            }
            // 2. Get AI response
            setVoiceCallState('thinking')
            const aiRes = await fetch('/api/chat', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: transcript,
                history: voiceCallHistory,
                personalityId: activeConversation?.personalityId || 'general',
              }),
            })
            const aiData = await aiRes.json()
            if (!aiRes.ok || !aiData.ok) throw new Error(aiData.error || 'AI failed to respond')
            const aiText = aiData.response
            setVoiceCallResponse(aiText)
            // Update call history
            setVoiceCallHistory((h) => [...h, { role: 'user', content: transcript }, { role: 'assistant', content: aiText }])
            // 3. Speak the response via TTS
            setVoiceCallState('speaking')
            const ttsRes = await fetch('/api/tts', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ text: aiText, voice: settingsTtsVoice, speed: 1.0 }),
            })
            if (!ttsRes.ok) throw new Error('TTS failed')
            const audioBlob = await ttsRes.blob()
            const audioUrl = URL.createObjectURL(audioBlob)
            const audio = new Audio(audioUrl)
            voiceCallAudioRef.current = audio
            audio.onended = () => {
              setVoiceCallState('idle')
              // Release the object URL
              URL.revokeObjectURL(audioUrl)
            }
            audio.onerror = () => {
              setVoiceCallState('idle')
              URL.revokeObjectURL(audioUrl)
            }
            await audio.play().catch(() => {
              setVoiceCallState('idle')
              URL.revokeObjectURL(audioUrl)
            })
          } catch (err: any) {
            setVoiceCallState('error')
            setVoiceCallError(err?.message || 'Something went wrong.')
          }
        }
        reader.readAsDataURL(blob)
      }
      mr.start()
    } catch (err: any) {
      setVoiceCallState('error')
      setVoiceCallError(err?.message || 'Microphone access denied. Please allow mic permissions.')
    }
  }

  const stopVoiceCallRecording = () => {
    const mr = audioRecorderRef.current
    if (mr && mr.state !== 'inactive') {
      mr.stop()
    }
  }

  const endVoiceCall = () => {
    // Stop any recording
    if (audioRecorderRef.current && audioRecorderRef.current.state !== 'inactive') {
      audioRecorderRef.current.stop()
    }
    // Stop any playing audio
    if (voiceCallAudioRef.current) {
      voiceCallAudioRef.current.pause()
      voiceCallAudioRef.current = null
    }
    setVoiceCallState('idle')
    setVoiceCallTranscript('')
    setVoiceCallResponse('')
    setVoiceCallError('')
    setShowVoiceCallModal(false)
  }

  // --- New: Video call — same pipeline (mic → ASR → AI → TTS → speaker) + webcam preview ---
  const startVideoCall = async () => {
    setVideoCallError('')
    setVideoCallTranscript('')
    setVideoCallResponse('')
    setVideoCallState('listening')
    try {
      // Request both audio + video. The webcam stream stays alive for the whole call,
      // but we only RECORD the audio track to send to ASR.
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
      videoCallStreamRef.current = stream
      // Show webcam preview
      if (videoCallVideoRef.current) {
        videoCallVideoRef.current.srcObject = stream
        videoCallVideoRef.current.muted = true
        try { await videoCallVideoRef.current.play() } catch {}
      }
      // Record only audio (we don't send the video to the AI; it's just a preview)
      const audioTrack = stream.getAudioTracks()[0]
      const audioOnlyStream = new MediaStream([audioTrack])
      const mr = new MediaRecorder(audioOnlyStream)
      videoCallRecorderRef.current = mr
      videoCallChunksRef.current = []
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) videoCallChunksRef.current.push(e.data)
      }
      mr.onstop = async () => {
        const blob = new Blob(videoCallChunksRef.current, { type: 'audio/webm' })
        if (blob.size === 0) {
          setVideoCallState('error')
          setVideoCallError('No audio captured. Please try again.')
          return
        }
        const reader = new FileReader()
        reader.onloadend = async () => {
          const audioDataUrl = reader.result as string
          setVideoCallState('transcribing')
          try {
            const asrRes = await fetch('/api/asr', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audioBase64: audioDataUrl }),
            })
            const asrData = await asrRes.json()
            if (!asrRes.ok || !asrData.ok) throw new Error(asrData.error || 'Transcription failed')
            const transcript = (asrData.text || '').toString().trim()
            setVideoCallTranscript(transcript)
            if (!transcript) {
              setVideoCallState('error')
              setVideoCallError("Couldn't hear you — try again.")
              return
            }
            setVideoCallState('thinking')
            const aiRes = await fetch('/api/chat', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: transcript,
                history: videoCallHistory,
                personalityId: activeConversation?.personalityId || 'general',
              }),
            })
            const aiData = await aiRes.json()
            if (!aiRes.ok || !aiData.ok) throw new Error(aiData.error || 'AI failed to respond')
            const aiText = aiData.response
            setVideoCallResponse(aiText)
            setVideoCallHistory((h) => [...h, { role: 'user', content: transcript }, { role: 'assistant', content: aiText }])
            setVideoCallState('speaking')
            const ttsRes = await fetch('/api/tts', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ text: aiText, voice: settingsTtsVoice, speed: 1.0 }),
            })
            if (!ttsRes.ok) throw new Error('TTS failed')
            const audioBlob = await ttsRes.blob()
            const audioUrl = URL.createObjectURL(audioBlob)
            const audio = new Audio(audioUrl)
            videoCallAudioRef.current = audio
            audio.onended = () => { setVideoCallState('idle'); URL.revokeObjectURL(audioUrl) }
            audio.onerror = () => { setVideoCallState('idle'); URL.revokeObjectURL(audioUrl) }
            await audio.play().catch(() => { setVideoCallState('idle'); URL.revokeObjectURL(audioUrl) })
          } catch (err: any) {
            setVideoCallState('error')
            setVideoCallError(err?.message || 'Something went wrong.')
          }
        }
        reader.readAsDataURL(blob)
      }
      mr.start()
    } catch (err: any) {
      setVideoCallState('error')
      setVideoCallError(err?.message || 'Camera/mic access denied. Please allow permissions.')
    }
  }

  const stopVideoCallRecording = () => {
    const mr = videoCallRecorderRef.current
    if (mr && mr.state !== 'inactive') {
      mr.stop()
    }
  }

  const endVideoCall = () => {
    // Stop audio recorder
    if (videoCallRecorderRef.current && videoCallRecorderRef.current.state !== 'inactive') {
      videoCallRecorderRef.current.stop()
    }
    // Stop all webcam tracks so the camera light turns off
    if (videoCallStreamRef.current) {
      videoCallStreamRef.current.getTracks().forEach((t) => t.stop())
      videoCallStreamRef.current = null
    }
    // Stop any playing AI audio
    if (videoCallAudioRef.current) {
      videoCallAudioRef.current.pause()
      videoCallAudioRef.current = null
    }
    if (videoCallVideoRef.current) {
      videoCallVideoRef.current.srcObject = null
    }
    setVideoCallState('idle')
    setVideoCallTranscript('')
    setVideoCallResponse('')
    setVideoCallError('')
    setShowVideoCallModal(false)
  }

  const stopGeneration = () => {
    if (abortRef.current) {
      abortRef.current.abort()
      abortRef.current = null
      setIsThinking(false)
    }
  }

  const copyMessage = (text: string) => {
    if (!text) return
    navigator.clipboard.writeText(text).then(() => toast.success('Copied to clipboard'))
  }

  // --- Close image lightbox on Escape key ---
  useEffect(() => {
    if (typeof window === 'undefined') return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightboxImage(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  // --- Pending prompt (from Dashboard feature cards): once user is loaded, auto-send the queued prompt ---
  // (Declared here so `sendMessage` is already defined above and accessible without TDZ error.)
  useEffect(() => {
    if (typeof window === 'undefined' || pendingPromptConsumed.current) return
    if (!currentUser) return // wait until the user is signed in
    const pending = localStorage.getItem('chatverse:pendingPrompt')
    if (!pending) return
    pendingPromptConsumed.current = true
    localStorage.removeItem('chatverse:pendingPrompt')
    // Create a general chat and send the pending prompt
    const newConv: Conversation = {
      id: uid(),
      personalityId: 'general',
      title: titleFrom(pending),
      messages: [],
      createdAt: now(),
      updatedAt: now(),
    }
    setConversations((prev) => [newConv, ...prev])
    setActiveId(newConv.id)
    setMobileChat(true)
    setMobileSidebar(false)
    // Defer to let the conversation state settle, then send
    setTimeout(() => {
      sendMessage(undefined, pending)
    }, 400)
  }, [currentUser, sendMessage])

  // --- Layout ---
  return (
    <div className="relative min-h-[100dvh] overflow-hidden bg-[#05070d] text-slate-100">
      {/* Background decoration — premium midnight + deep-blue + cyan + gold orbs */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        {/* Radial vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.10),transparent_55%),radial-gradient(ellipse_at_bottom,rgba(251,191,36,0.06),transparent_55%)]" />
        {/* Large slow orbs */}
        <div className="absolute -top-40 -left-40 h-[32rem] w-[32rem] animate-blob rounded-full bg-gradient-to-br from-blue-500/20 via-cyan-400/15 to-transparent blur-3xl" />
        <div className="absolute top-1/4 -right-40 h-[32rem] w-[32rem] animate-blob rounded-full bg-gradient-to-br from-amber-500/15 via-yellow-400/10 to-transparent blur-3xl [animation-delay:4s]" />
        <div className="absolute bottom-0 left-1/3 h-[28rem] w-[28rem] animate-blob rounded-full bg-gradient-to-br from-cyan-500/15 via-blue-500/10 to-transparent blur-3xl [animation-delay:8s]" />
        {/* Subtle grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(to right, rgba(56,189,248,0.5) 1px, transparent 1px), linear-gradient(to bottom, rgba(56,189,248,0.5) 1px, transparent 1px)',
            backgroundSize: '52px 52px',
          }}
        />
      </div>

      {/* Floating particles (subtle gold + cyan) */}
      <FloatingParticles />

      <div className="flex h-[100dvh] w-full flex-col">
        {/* ============================== Top status bar: live counter + events + announcements + owner badge ============================== */}
        <TopStatusBar
          onlineCount={onlineCount}
          announcements={announcements}
          events={events}
          isOwner={!!ownerToken}
          ownerInfo={ownerInfo}
          onOpenAnnouncementModal={() => setShowAnnouncementModal(true)}
          onOpenOwnerPanel={() => { setShowOwnerPanel(true); loadAllUsers(); }}
          onSignOutOwner={signOutOwner}
          onDeleteEvent={deleteEvent}
        />

      <div className="flex min-h-0 flex-1 overflow-hidden">
        {/* ============================== Discord-style left rail (personality icons) ============================== */}
        <aside className="hidden w-[76px] shrink-0 flex-col items-center gap-3 border-r border-white/10 bg-black/30 py-4 backdrop-blur-2xl md:flex">
          {/* Brand — new ChatVerse logo */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileHover={{ scale: 1.08, rotate: 4 }}
            transition={{ type: 'spring', stiffness: 300 }}
            className="relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl shadow-lg shadow-cyan-500/30"
            title="ChatVerse AI"
          >
            {/* Glow halo */}
            <motion.span
              animate={{ opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-md"
            />
            {/* Logo image */}
            <Image
              src="/chatverse-logo.png"
              alt="ChatVerse AI"
              width={48}
              height={48}
              className="relative z-10 h-12 w-12 rounded-2xl object-cover"
              priority
            />
          </motion.div>
          <div className="h-px w-8 bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />

          {/* Personality buttons */}
          <div className="flex flex-col items-center gap-3">
            {PERSONALITIES.map((p) => {
              const isActive = activeConversation?.personalityId === p.id
              const Icon = p.icon
              return (
                <motion.button
                  key={p.id}
                  whileHover={{ scale: 1.08, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    // If conversation with this personality exists, switch to it; else create new
                    const existing = conversations.find((c) => c.personalityId === p.id)
                    if (existing) {
                      setActiveId(existing.id)
                      setMobileChat(true)
                    } else {
                      createConversation(p.id)
                    }
                  }}
                  title={`${p.name} — ${p.tagline}`}
                  className={`group relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${p.gradient} text-white shadow-md transition-all duration-300 ${
                    isActive ? 'ring-2 ring-cyan-400 scale-105' : ''
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  {/* Active indicator (Discord-style left pill) */}
                  <span
                    className={`absolute -left-[18px] top-1/2 h-7 w-1.5 -translate-y-1/2 rounded-r-full bg-cyan-400 transition-all ${
                      isActive ? 'h-7 opacity-100' : 'h-2 opacity-0 group-hover:h-3 group-hover:opacity-60'
                    }`}
                  />
                  {/* Hover label */}
                  <span className="pointer-events-none absolute left-14 z-50 hidden whitespace-nowrap rounded-lg border border-white/10 bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-white shadow-xl backdrop-blur-xl group-hover:block">
                    {p.name} · {p.tagline}
                  </span>
                </motion.button>
              )
            })}
          </div>

          <div className="mt-auto flex flex-col items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition hover:bg-white/[0.1]"
              title="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </motion.button>
          </div>
        </aside>

        {/* ============================== WhatsApp-style conversation list ============================== */}
        <aside
          className={`${
            mobileSidebar ? 'flex' : 'hidden'
          } w-full shrink-0 flex-col border-r border-white/10 bg-black/40 backdrop-blur-2xl md:flex md:w-72 md:max-w-72`}
        >
          {/* Header — new branded logo + ChatVerse AI */}
          <div className="flex items-center justify-between gap-2 border-b border-white/10 p-4">
            <div className="flex items-center gap-2.5">
              <div className="relative h-9 w-9 shrink-0 overflow-hidden rounded-xl shadow-md shadow-cyan-500/30">
                <motion.span
                  animate={{ opacity: [0.4, 0.8, 0.4] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute inset-0 bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-sm"
                />
                <Image
                  src="/chatverse-logo.png"
                  alt="ChatVerse AI"
                  width={36}
                  height={36}
                  className="relative z-10 h-9 w-9 rounded-xl object-cover md:hidden"
                />
              </div>
              <div>
                <h1 className="text-lg font-extrabold tracking-tight">
                  Chat<span className="text-gradient-cyan">Verse</span> <span className="text-xs font-bold text-slate-400">AI</span>
                </h1>
                <p className="text-[11px] text-slate-400">
                  by Mohammed Zayyan
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Link
                href="/dashboard"
                className="grid h-8 w-8 place-items-center rounded-lg text-slate-300 transition hover:bg-white/[0.06] hover:text-cyan-300"
                title="Open dashboard"
              >
                <LayoutGrid className="h-4 w-4" />
              </Link>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="h-8 w-8 text-slate-300 md:hidden"
                title="Toggle theme"
              >
                {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => setShowNotificationsModal(true)}
                className="relative h-8 w-8 text-slate-300 hover:bg-white/[0.06]"
                title="Notifications"
              >
                <Bell className="h-4 w-4" />
                {(announcements.length > 0 || events.length > 0) && (
                  <span className="absolute -right-0.5 -top-0.5 grid h-4 w-4 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 text-[9px] font-bold text-black">
                    {announcements.length + events.length}
                  </span>
                )}
              </Button>
            </div>
          </div>

          {/* Menu row — Create bot / History / Knowledge Base / Settings (like the ChatVerse AI template) */}
          <div className="flex items-center gap-1 border-b border-white/10 bg-black/20 px-2 py-1.5">
            <button
              onClick={() => setShowPersonalityPicker(true)}
              className="flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[10px] font-bold uppercase tracking-wider text-cyan-300 transition hover:bg-cyan-500/10"
              title="Create a new chat / bot"
            >
              <Bot className="h-3.5 w-3.5" /> Create bot
            </button>
            <button
              onClick={() => document.querySelector('[data-convo-list]')?.scrollIntoView({ behavior: 'smooth' })}
              className="flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 transition hover:bg-white/[0.06] hover:text-slate-200"
              title="Chat history"
            >
              <History className="h-3.5 w-3.5" /> History
            </button>
            <button
              onClick={() => setShowKnowledgeBase(true)}
              className="flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 transition hover:bg-white/[0.06] hover:text-slate-200"
              title="Saved notes & knowledge"
            >
              <BookOpen className="h-3.5 w-3.5" /> Knowledge
            </button>
            <button
              onClick={() => setShowSettingsModal(true)}
              className="flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 transition hover:bg-white/[0.06] hover:text-slate-200"
              title="Settings"
            >
              <Settings className="h-3.5 w-3.5" /> Settings
            </button>
          </div>

          {/* Search */}
          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search chats..."
                className="h-9 border-white/10 bg-white/[0.04] pl-9 text-sm text-white placeholder:text-slate-500 focus-visible:ring-cyan-400/50"
              />
            </div>
          </div>

          {/* New chat button (large) — premium shimmer for premium users */}
          <div className="px-3 pb-2">
            <Button
              onClick={() => setShowPersonalityPicker(true)}
              className={`h-10 w-full justify-start gap-2 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black shadow-md shadow-amber-500/30 hover:from-amber-300 hover:to-yellow-400 ${isPremiumUser ? 'premium-btn-shimmer premium-gradient-shift' : ''}`}
            >
              <Plus className="h-4 w-4" /> New chat
            </Button>
          </div>

          {/* Conversation list */}
          <div data-convo-list className="flex-1 overflow-y-auto px-2 [scrollbar-width:thin]">
            <div className="space-y-1 pb-4">
              {filteredConversations.length === 0 ? (
                <div className="px-3 py-10 text-center">
                  <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-cyan-300">
                    <MessageCircle className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium text-slate-300">
                    {conversations.length === 0 ? 'No chats yet' : 'No matches found'}
                  </p>
                  <p className="text-xs text-slate-500">
                    {conversations.length === 0 ? 'Tap "New chat" to begin' : 'Try a different search'}
                  </p>
                </div>
              ) : (
                filteredConversations.map((c) => {
                  const p = getPersonality(c.personalityId)
                  const lastMsg = c.messages[c.messages.length - 1]
                  const lastText = lastMsg
                    ? lastMsg.role === 'user'
                      ? `You: ${lastMsg.content.slice(0, 40)}`
                      : lastMsg.content
                      ? `${p.name}: ${lastMsg.content.slice(0, 40)}`
                      : `${p.name} is typing...`
                    : 'No messages yet'
                  const isActive = activeId === c.id
                  return (
                    <motion.div
                      key={c.id}
                      layout
                      role="button"
                      tabIndex={0}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      whileHover={{ x: 2 }}
                      onClick={() => {
                        setActiveId(c.id)
                        setMobileSidebar(false)
                        setMobileChat(true)
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault()
                          setActiveId(c.id)
                          setMobileSidebar(false)
                          setMobileChat(true)
                        }
                      }}
                      className={`group flex w-full cursor-pointer items-center gap-3 rounded-xl px-2.5 py-2.5 text-left transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-cyan-500/15 to-blue-500/10 ring-1 ring-cyan-400/40'
                          : 'hover:bg-white/[0.04]'
                      }`}
                    >
                      <div className="relative shrink-0">
                        <Avatar className="h-11 w-11 ring-2 ring-white/10">
                          <AvatarFallback className={`bg-gradient-to-br ${p.gradient} text-white font-bold`}>
                            {p.emoji}
                          </AvatarFallback>
                        </Avatar>
                        <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-[#05070d] bg-cyan-400 shadow-[0_0_6px_rgba(34,211,238,0.7)]" />
                      </div>
                      <div className="flex-1 overflow-hidden">
                        <div className="flex items-center justify-between gap-2">
                          <span className={`truncate text-sm font-semibold ${isActive ? 'text-cyan-200' : 'text-white'}`}>
                            {p.name}
                          </span>
                          <span className="shrink-0 text-[10px] text-slate-500">
                            {c.updatedAt ? formatRelative(c.updatedAt) : ''}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="truncate text-xs text-slate-400">
                            {lastText}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteConversation(c.id)
                            }}
                            className="shrink-0 rounded-md p-1 text-slate-500 opacity-0 transition hover:bg-rose-500/15 hover:text-rose-400 group-hover:opacity-100"
                            title="Delete chat"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )
                })
              )}
            </div>
          </div>

          {/* Permanent Weather + News widget (always visible in sidebar) */}
          <PermanentWeatherNews />

          {/* Footer (settings + user plan/points) */}
          <div className="border-t border-white/10 p-3">
            <button
              onClick={() => setShowSettingsModal(true)}
              className="flex w-full items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-2 text-left transition hover:bg-white/[0.06]"
              title="Open settings"
            >
              <Avatar className="h-9 w-9">
                {currentUser?.plan === 'owner' && ownerInfo ? (
                  <AvatarFallback className={`bg-gradient-to-br ${ownerInfo.gradient} text-white`}>
                    {ownerInfo.icon === 'crown' ? <Crown className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
                  </AvatarFallback>
                ) : currentUser ? (
                  <AvatarFallback className={
                    currentUser.plan === 'premium' ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 text-white' :
                    currentUser.plan === 'plus' ? 'bg-gradient-to-br from-teal-500 to-cyan-500 text-white' :
                    'bg-gradient-to-br from-slate-500 to-slate-700 text-white'
                  }>
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-slate-500 to-slate-700 text-white">
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-100">
                  {currentUser ? currentUser.name : 'Guest'}
                </p>
                {currentUser?.email ? (
                  <p className="truncate text-[10px] text-slate-500 dark:text-slate-400">
                    {currentUser.email}
                  </p>
                ) : null}
                <div className="flex items-center gap-1.5">
                  {currentUser?.plan && (
                    <span className={`rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white ${
                      currentUser.plan === 'owner' ? 'bg-gradient-to-r from-amber-400 to-orange-500' :
                      currentUser.plan === 'premium' ? 'bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500' :
                      currentUser.plan === 'plus' ? 'bg-gradient-to-r from-teal-500 to-cyan-500' :
                      'bg-gradient-to-r from-slate-500 to-slate-700'
                    } ${isPremiumUser ? 'premium-text-shimmer' : ''}`}>
                      {currentUser.plan === 'owner' ? 'OWNER' : currentUser.plan}
                    </span>
                  )}
                  {currentUser && (
                    <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      {currentUser.plan === 'owner' ? '∞ points' : `${currentUser.points} pts`}
                    </span>
                  )}
                </div>
              </div>
              <Settings className="h-4 w-4 shrink-0 text-slate-400" />
            </button>
            {currentUser && currentUser.plan !== 'owner' && (
              <Button
                size="sm"
                onClick={() => setShowPlansModal(true)}
                className="mt-2 h-8 w-full justify-center gap-1.5 rounded-lg bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-xs font-extrabold text-black shadow-md transition-transform hover:scale-[1.02] hover:shadow-amber-500/30"
              >
                <Crown className="h-3.5 w-3.5" /> Upgrade with points
              </Button>
            )}
            {/* Install App button (shows on Android Chrome + Edge desktop when install is available; on iOS shows an Add to Home Screen hint) */}
            <div className="mt-2">
              <InstallAppButton compact />
            </div>
          </div>
        </aside>

        {/* ============================== Main chat area ============================== */}
        <main
          className={`${
            mobileChat ? 'flex' : 'hidden'
          } min-h-0 flex-1 flex-col bg-[#05070d] md:flex`}
        >
          {activeConversation && activePersonality ? (
            <>
              {/* Chat header (WhatsApp style) — compact on mobile */}
              <header className="flex items-center justify-between gap-2 border-b border-white/10 bg-black/40 px-2 py-1.5 backdrop-blur-2xl sm:gap-3 sm:px-4 sm:py-2.5">
                <div className="flex min-w-0 items-center gap-2 sm:gap-3">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      setMobileChat(false)
                      setMobileSidebar(true)
                    }}
                    className="h-7 w-7 shrink-0 text-slate-300 md:hidden"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Avatar className="h-8 w-8 shrink-0 ring-2 ring-cyan-400/40 sm:h-10 sm:w-10">
                    <AvatarFallback className={`bg-gradient-to-br ${activePersonality.gradient} text-white`}>
                      {activePersonality.emoji}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <h2 className="truncate text-sm font-bold text-white sm:text-base">
                        {activePersonality.name}
                      </h2>
                      <span className={`hidden shrink-0 rounded-full bg-gradient-to-r ${activePersonality.gradient} px-2 py-0.5 text-[10px] font-semibold text-white sm:inline`}>
                        {activePersonality.tagline}
                      </span>
                    </div>
                    <p className="text-[10px] text-cyan-300 sm:text-xs">
                      <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-400 align-middle shadow-[0_0_6px_rgba(34,211,238,0.8)]" />
                      online
                    </p>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-0.5 sm:gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setVoiceCallHistory([])
                      setVoiceCallState('idle')
                      setVoiceCallTranscript('')
                      setVoiceCallResponse('')
                      setVoiceCallError('')
                      setShowVoiceCallModal(true)
                    }}
                    className={`h-7 w-7 gap-1.5 rounded-lg bg-cyan-500/10 p-0 text-cyan-300 hover:bg-cyan-500/20 sm:h-8 sm:w-auto sm:px-2.5 ${isPremiumUser ? 'premium-btn-glow premium-btn-shimmer' : ''}`}
                    title="Voice call with AI"
                  >
                    <Phone className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                    <span className="hidden text-xs font-semibold lg:inline">Call</span>
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setVideoCallHistory([])
                      setVideoCallState('idle')
                      setVideoCallTranscript('')
                      setVideoCallResponse('')
                      setVideoCallError('')
                      setShowVideoCallModal(true)
                    }}
                    className={`h-7 w-7 gap-1.5 rounded-lg bg-blue-500/10 p-0 text-blue-300 hover:bg-blue-500/20 sm:h-8 sm:w-auto sm:px-2.5 ${isPremiumUser ? 'premium-btn-glow premium-btn-shimmer' : ''}`}
                    title="Video call with AI"
                  >
                    <VideoIcon className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                    <span className="hidden text-xs font-semibold lg:inline">Video</span>
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => deleteConversation(activeConversation.id)}
                    className="h-7 w-7 text-slate-400 hover:text-rose-500 sm:h-8 sm:w-8"
                    title="Delete chat"
                  >
                    <Trash2 className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className={`h-7 w-7 text-slate-400 hover:text-amber-400 sm:h-8 sm:w-8 ${isPremiumUser ? 'premium-btn-float' : ''}`}
                    title="Toggle theme"
                  >
                    {theme === 'dark' ? <Sun className="h-3.5 w-3.5 sm:h-4 sm:w-4" /> : <Moon className="h-3.5 w-3.5 sm:h-4 sm:w-4" />}
                  </Button>
                  {/* Context panel toggle — PREMIUM ONLY (plus / premium / owner). Free users don't see this button. */}
                  {isPremiumUser && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setShowContextPanel(!showContextPanel)}
                      className={`hidden h-7 w-7 transition sm:flex sm:h-8 sm:w-8 ${showContextPanel ? 'bg-cyan-500/15 text-cyan-300' : 'text-slate-400 hover:text-cyan-300'} premium-border-shimmer`}
                      title="Toggle context panel (Premium feature)"
                    >
                      <LayoutGrid className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                    </Button>
                  )}
                </div>
              </header>

              {/* Messages — fills available height, scrolls when overflowing. Explicit dark bg prevents white flash on Android. */}
              <div
                ref={messagesScrollRef}
                className="min-h-0 flex-1 overflow-y-auto bg-[#05070d] px-3 py-4 sm:px-6 [scrollbar-width:thin]"
              >
                <div className="mx-auto max-w-3xl space-y-1">
                  {/* Welcome banner */}
                  {activeConversation.messages.length === 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mb-6 mt-4 text-center"
                    >
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
                        className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br text-3xl shadow-lg"
                        style={{
                          backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))`,
                        }}
                      >
                        <span className={`grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br ${activePersonality.gradient} text-3xl shadow-lg`}>
                          {activePersonality.emoji}
                        </span>
                      </motion.div>
                      <h3 className="text-xl font-extrabold text-white">
                        Hi, I'm {activePersonality.name}!
                      </h3>
                      <p className="mx-auto mt-1 max-w-md text-sm text-slate-400">
                        {WELCOME_MESSAGE}
                      </p>
                      <div className="mx-auto mt-4 flex flex-wrap items-center justify-center gap-2">
                        {SUGGESTIONS.map((s) => (
                          <button
                            key={s}
                            onClick={() => setInputMessage(s)}
                            className="rounded-full border border-cyan-400/20 bg-cyan-500/5 px-3 py-1.5 text-xs font-medium text-cyan-200 transition hover:bg-cyan-500/15 hover:border-cyan-400/40"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Render messages with date separators */}
                  {activeConversation.messages.map((m, idx) => {
                    const prev = activeConversation.messages[idx - 1]
                    const showDate =
                      !prev || formatDate(prev.timestamp) !== formatDate(m.timestamp)
                    return (
                      <div key={m.id}>
                        {showDate && (
                          <div className="my-4 flex justify-center">
                            <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-medium text-slate-400 backdrop-blur-xl">
                              {formatDate(m.timestamp)}
                            </span>
                          </div>
                        )}
                        <MessageBubble
                          message={m}
                          personality={activePersonality}
                          onCopy={() => copyMessage(m.content)}
                          onImageClick={(img) => setLightboxImage(img)}
                        />
                      </div>
                    )
                  })}

                  {/* Thinking indicator */}
                  <AnimatePresence>
                    {isThinking && (
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="flex items-end gap-2"
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className={`bg-gradient-to-br ${activePersonality.gradient} text-white text-sm`}>
                            {activePersonality.emoji}
                          </AvatarFallback>
                        </Avatar>
                        <div className="rounded-2xl rounded-tl-sm border border-white/10 bg-white/[0.04] px-4 py-3 shadow-md backdrop-blur-xl">
                          <div className="flex gap-1">
                            {[0, 1, 2].map((i) => (
                              <motion.span
                                key={i}
                                animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }}
                                transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
                                className="inline-block h-2 w-2 rounded-full bg-cyan-400"
                              />
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Input bar (floating premium style) — compact on mobile, with iOS safe-area bottom padding */}
              <div className="border-t border-white/10 bg-black/40 p-2 backdrop-blur-2xl sm:p-4" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0.5rem), 0.5rem)' }}>
                <form
                  onSubmit={sendMessage}
                  className="mx-auto max-w-3xl space-y-2"
                >
                  {/* Pending images preview (multi-image support) */}
                  <AnimatePresence>
                    {pendingImages.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="flex flex-wrap gap-2"
                      >
                        {pendingImages.map((img, idx) => (
                          <motion.div
                            key={idx}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            className="relative inline-block overflow-hidden rounded-2xl border border-cyan-400/30 bg-black/40 shadow-md backdrop-blur-xl"
                          >
                            <img
                              src={img}
                              alt={`Upload ${idx + 1} preview`}
                              className="h-20 w-20 rounded-2xl object-cover"
                            />
                            <button
                              type="button"
                              onClick={() => removePendingImage(idx)}
                              className="absolute right-1 top-1 grid h-5 w-5 place-items-center rounded-full bg-rose-500/80 text-white shadow-md backdrop-blur-xl transition hover:bg-rose-500"
                              title="Remove image"
                            >
                              <X className="h-3 w-3" />
                            </button>
                            <div className="absolute bottom-0.5 left-0.5 rounded-md bg-cyan-500/80 px-1 text-[9px] font-bold text-white">
                              {idx + 1}
                            </div>
                          </motion.div>
                        ))}
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          disabled={pendingImages.length >= 4}
                          className="grid h-20 w-20 place-items-center rounded-2xl border-2 border-dashed border-cyan-400/40 bg-cyan-500/5 text-cyan-300 transition hover:border-cyan-400/70 hover:bg-cyan-500/15 disabled:opacity-40"
                          title={pendingImages.length >= 4 ? 'Maximum 4 images' : 'Add more images'}
                        >
                          <Plus className="h-6 w-6" />
                          <span className="text-[10px] font-semibold">{pendingImages.length}/4</span>
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="flex items-end gap-1.5 sm:gap-2">
                    {/* Attachment buttons (functional) */}
                    <div className="flex items-center gap-1">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/png,image/jpeg,image/webp,image/gif"
                        multiple
                        className="hidden"
                        onChange={onPickImage}
                      />
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => fileInputRef.current?.click()}
                        className={`h-9 w-9 text-slate-400 hover:text-cyan-300 sm:h-10 sm:w-10 ${isPremiumUser ? 'premium-btn-float' : ''}`}
                        title="Upload image to AI"
                      >
                        <ImageIcon className="h-4 w-4 sm:h-5 sm:w-5" />
                      </Button>
                    </div>

                    {/* Input */}
                    <div className="relative flex-1">
                      <Input
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        placeholder={pendingImages.length > 0 ? `Ask about ${pendingImages.length === 1 ? 'the image' : `these ${pendingImages.length} images`}... (optional)` : `Message ${activePersonality.name}...  (paste image with Ctrl+V)`}
                        disabled={isThinking}
                        maxLength={4000}
                        className="h-10 rounded-2xl border-white/10 bg-white/[0.04] pr-10 text-sm text-white placeholder:text-slate-500 focus-visible:ring-cyan-400/50 hover:bg-white/[0.06] sm:h-12 sm:pr-12"
                      />
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute right-1 top-1/2 h-9 w-9 -translate-y-1/2 text-slate-400 hover:text-cyan-300 sm:h-10 sm:w-10"
                        title="Upload image"
                      >
                        <Paperclip className="h-4 w-4 sm:h-5 sm:w-5" />
                      </Button>
                    </div>

                  {/* Send / Stop button */}
                  {isThinking ? (
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        type="button"
                        onClick={stopGeneration}
                        className={`h-10 w-10 rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 p-0 text-white shadow-md shadow-rose-500/40 hover:shadow-rose-500/60 sm:h-12 sm:w-12 ${isPremiumUser ? 'premium-btn-shimmer' : ''}`}
                        title="Stop"
                      >
                        <Square className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ) : (
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        type="submit"
                        disabled={!inputMessage.trim() && pendingImages.length === 0}
                        className={`h-10 w-10 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-400 to-amber-500 p-0 text-black shadow-md shadow-amber-500/30 hover:from-amber-300 hover:to-yellow-400 disabled:opacity-40 disabled:shadow-none sm:h-12 sm:w-12 ${isPremiumUser ? 'premium-ring-pulse premium-gradient-shift premium-btn-shimmer' : ''}`}
                        title="Send"
                      >
                        <Send className="h-4 w-4 sm:h-5 sm:w-5" />
                      </Button>
                    </motion.div>
                  )}
                  </div>
                </form>
                <p className="mt-1.5 text-center text-[10px] text-slate-500 sm:mt-2">
                  ChatVerse AI may produce inaccurate info · Press Enter to send · Paste images with Ctrl+V or use 📎
                </p>
              </div>
            </>
          ) : (
            // --- Empty state ---
            <EmptyState
              onNewChat={() => createConversation('general')}
              onPickPersonality={createConversation}
              onTriggerFeature={(prompt) => {
                // Create a general chat if none exists, then auto-send the feature prompt
                let conv = activeConversation
                if (!conv) {
                  conv = {
                    id: uid(),
                    personalityId: 'general',
                    title: titleFrom(prompt),
                    messages: [],
                    createdAt: now(),
                    updatedAt: now(),
                  }
                  setConversations((prev) => [conv as Conversation, ...prev])
                  setActiveId(conv.id)
                }
                // Defer to next tick so the conversation is set, then send with override content
                setTimeout(() => {
                  sendMessage(undefined, prompt)
                }, 200)
              }}
            />
          )}
        </main>

        {/* ============================== Right context panel (AI Assistant info + team + actions) ============================== */}
        <AnimatePresence>
          {showContextPanel && activeConversation && activePersonality && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="hidden shrink-0 flex-col overflow-hidden border-l border-white/10 bg-black/40 backdrop-blur-2xl lg:flex"
            >
              <ContextPanel
                personality={activePersonality}
                conversation={activeConversation}
                onCopy={() => {
                  const text = activeConversation.messages
                    .map((m) => `${m.role === 'user' ? 'You' : activePersonality.name}: ${m.content}`)
                    .join('\n\n')
                  navigator.clipboard.writeText(text).then(() => toast.success('Conversation copied!'))
                }}
                onShare={() => toast.success('Share link copied to clipboard!')}
                onFollowUp={() => setInputMessage('Can you summarize our conversation and suggest a follow-up?')}
                onClose={() => setShowContextPanel(false)}
                currentUser={currentUser}
                ownerInfo={ownerInfo}
              />
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
      </div>

      {/* ============================== Personality picker modal ============================== */}
      <AnimatePresence>
        {showPersonalityPicker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowPersonalityPicker(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-slate-200/60 bg-white/90 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/90"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div>
                  <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Pick an AI</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Choose a personality to start chatting</p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setShowPersonalityPicker(false)}
                  className="h-8 w-8 text-slate-500"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2 p-3">
                {PERSONALITIES.map((p, i) => {
                  const Icon = p.icon
                  return (
                    <motion.button
                      key={p.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      whileHover={{ scale: 1.02, x: 2 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => createConversation(p.id)}
                      className="flex w-full items-center gap-3 rounded-2xl border border-slate-200/60 bg-white p-3 text-left transition hover:teal-300 hover:teal-50/50 dark:border-slate-800/60 dark:bg-slate-800/40 dark:hover:teal-700 dark:hover:teal-900/20"
                    >
                      <div className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${p.gradient} text-white shadow-md`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold text-slate-900 dark:text-white">{p.name}</span>
                          <span className="text-lg">{p.emoji}</span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{p.tagline}</p>
                      </div>
                      <ChevronDown className="h-4 w-4 -rotate-90 text-slate-400" />
                    </motion.button>
                  )
                })}
              </div>
              <div className="border-t border-slate-200/60 p-3 text-center text-[11px] text-slate-400 dark:border-slate-800/60 dark:text-slate-500">
                Created by Mohammed Zayyan · ChatVerse
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== AI Image generation modal ============================== */}
      <AnimatePresence>
        {showImageGenModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => imageGenStatus !== 'generating' && setShowImageGenModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg overflow-hidden rounded-3xl border teal-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:teal-800/60 dark:bg-slate-900/95"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 text-white shadow-md">
                    <ImageIcon className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">AI Image Generator</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Create images from text · 5 points per image</p>
                  </div>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => imageGenStatus !== 'generating' && setShowImageGenModal(false)}
                  className="h-8 w-8 text-slate-500"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-4 p-4">
                {!imageGenResult && imageGenStatus !== 'generating' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-sm font-semibold text-slate-800 dark:text-slate-200">Describe your image</Label>
                      <textarea
                        value={imageGenPrompt}
                        onChange={(e) => setImageGenPrompt(e.target.value)}
                        placeholder="e.g. A futuristic city at sunset with flying cars"
                        maxLength={500}
                        rows={3}
                        className="w-full resize-none rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-400 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                      <div className="flex flex-wrap gap-1.5">
                        {['A cat wearing a space suit', 'A cyberpunk city at night', 'A dragon flying over mountains', 'Underwater coral reef', 'A sunset over the ocean'].map((s) => (
                          <button
                            key={s}
                            onClick={() => setImageGenPrompt(s)}
                            className="rounded-full border teal-200 teal-50 px-2.5 py-1 text-[11px] font-medium teal-700 transition hover:teal-100 dark:teal-800 dark:teal-900/30 dark:amber-300"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                    <Button
                      onClick={generateImage}
                      disabled={!imageGenPrompt.trim()}
                      className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-lg shadow-teal-500/30 hover:from-teal-600 hover:to-cyan-600"
                    >
                      <ImageIcon className="mr-2 h-4 w-4" /> Generate image
                    </Button>
                    <p className="text-center text-[11px] text-slate-400 dark:text-slate-500">
                      ⏱️ Takes ~30-60 seconds · Please be patient · Saved as PNG · Downloadable
                    </p>
                  </>
                )}

                {imageGenStatus === 'generating' && (
                  <div className="flex flex-col items-center justify-center py-12">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                      className="mb-4 h-12 w-12 rounded-full border-4 teal-500/30 teal-500"
                    />
                    <p className="font-semibold text-slate-800 dark:text-slate-100">Generating your image...</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">This can take 30-60 seconds. Please don't close the window.</p>
                  </div>
                )}

                {imageGenStatus === 'error' && (
                  <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">
                    Something went wrong. Please try again.
                  </div>
                )}

                {imageGenResult && imageGenStatus === 'done' && (
                  <div className="space-y-3">
                    <img
                      src={imageGenResult.imageUrl}
                      alt={imageGenResult.prompt}
                      className="w-full rounded-2xl shadow-lg"
                    />
                    <div className="rounded-xl bg-slate-100/60 p-3 dark:bg-slate-800/60">
                      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Prompt</p>
                      <p className="text-sm text-slate-800 dark:text-slate-100">{imageGenResult.prompt}</p>
                    </div>
                    <div className="flex gap-2">
                      <a
                        href={imageGenResult.imageUrl}
                        download
                        className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 px-4 py-2.5 text-sm font-semibold text-white shadow-md"
                      >
                        <FileText className="h-4 w-4" /> Download
                      </a>
                      <Button
                        variant="outline"
                        onClick={() => { setImageGenResult(null); setImageGenStatus('idle') }}
                        className="flex-1 border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-200"
                      >
                        New image
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== AI Video modal ============================== */}
      <AnimatePresence>
        {showVideoModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => !videoStatus.generating && setShowVideoModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg overflow-hidden rounded-3xl border border-slate-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/95"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-amber-500 to-teal-500 text-white shadow-md">
                    <Film className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">AI Video Generator</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">5-second videos from your imagination</p>
                  </div>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setShowVideoModal(false)}
                  disabled={videoStatus === 'generating'}
                  className="h-8 w-8 text-slate-500"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-4 p-4">
                {!videoResult && videoStatus !== 'generating' && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="video-prompt" className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                        Describe your video
                      </Label>
                      <textarea
                        id="video-prompt"
                        value={videoPrompt}
                        onChange={(e) => setVideoPrompt(e.target.value)}
                        placeholder="e.g. A neon cyberpunk city at night with flying cars"
                        maxLength={500}
                        rows={3}
                        className="w-full resize-none rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-400 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                      <div className="flex flex-wrap gap-1.5">
                        {['A neon cyberpunk city at night', 'A serene beach at sunset', 'A dragon flying over mountains', 'Underwater coral reef with fish', 'A astronaut floating in space'].map((s) => (
                          <button
                            key={s}
                            onClick={() => setVideoPrompt(s)}
                            className="rounded-full border teal-200 teal-50 px-2.5 py-1 text-[11px] font-medium teal-700 transition hover:teal-100 dark:teal-800 dark:teal-900/30 dark:amber-300"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                    <Button
                      onClick={generateVideo}
                      disabled={!videoPrompt.trim()}
                      className="w-full bg-gradient-to-r from-amber-500 to-teal-500 text-white shadow-lg shadow-teal-500/30 hover:from-amber-600 hover:to-teal-600"
                    >
                      <Film className="mr-2 h-4 w-4" /> Generate 5-second video
                    </Button>
                    <p className="text-center text-[11px] text-slate-400 dark:text-slate-500">
                      ⏱️ Takes ~30-90 seconds · Please be patient · Generates an AI image then animates it
                    </p>
                  </>
                )}

                {videoStatus === 'generating' && (
                  <div className="flex flex-col items-center justify-center py-12">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                      className="mb-4 h-12 w-12 rounded-full border-4 teal-500/30 teal-500"
                    />
                    <p className="font-semibold text-slate-800 dark:text-slate-100">Generating your video...</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">This can take 30-90 seconds. Please don't close the window.</p>
                  </div>
                )}

                {videoStatus === 'error' && (
                  <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">
                    Something went wrong. Please try again.
                  </div>
                )}

                {videoResult && videoStatus === 'done' && (
                  <div className="space-y-3">
                    <video
                      src={videoResult.videoUrl}
                      controls
                      autoPlay
                      loop
                      muted
                      playsInline
                      className="w-full rounded-2xl bg-black shadow-lg"
                    />
                    <div className="rounded-xl bg-slate-100/60 p-3 dark:bg-slate-800/60">
                      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Prompt</p>
                      <p className="text-sm text-slate-800 dark:text-slate-100">{videoResult.prompt}</p>
                    </div>
                    <div className="flex gap-2">
                      <a
                        href={videoResult.videoUrl}
                        download
                        className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-teal-500 px-4 py-2.5 text-sm font-semibold text-white shadow-md"
                      >
                        <FileText className="h-4 w-4" /> Download
                      </a>
                      <Button
                        variant="outline"
                        onClick={() => { setVideoResult(null); setVideoStatus('idle') }}
                        className="flex-1 border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-200"
                      >
                        New video
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Post announcement modal (owner only) ============================== */}
      <AnimatePresence>
        {showAnnouncementModal && ownerInfo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowAnnouncementModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-slate-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/95"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-white shadow-md">
                    <Megaphone className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Global Announcement</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Posted by {ownerInfo.name} · {ownerInfo.role}</p>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowAnnouncementModal(false)} className="h-8 w-8 text-slate-500">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-3 p-4">
                <textarea
                  value={newAnnouncementText}
                  onChange={(e) => setNewAnnouncementText(e.target.value)}
                  placeholder="Write a short announcement that ALL users will see at the top of ChatVerse..."
                  maxLength={280}
                  rows={4}
                  className="w-full resize-none rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-400 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
                <p className="text-right text-[11px] text-slate-400">{newAnnouncementText.length}/280</p>
                <Button
                  onClick={postAnnouncement}
                  disabled={!newAnnouncementText.trim()}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-orange-500/30 hover:from-amber-600 hover:to-orange-600"
                >
                  <Megaphone className="mr-2 h-4 w-4" /> Post to everyone
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Owner panel modal ============================== */}
      <AnimatePresence>
        {showOwnerPanel && ownerInfo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowOwnerPanel(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-slate-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/95"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${ownerInfo.gradient} text-white shadow-md`}>
                    {ownerInfo.icon === 'crown' ? <Crown className="h-5 w-5" /> : <Shield className="h-5 w-5" />}
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Owner Panel</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">{ownerInfo.name} · {ownerInfo.role}</p>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowOwnerPanel(false)} className="h-8 w-8 text-slate-500">
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-3 p-4">
                {/* Live user count card */}
                <div className="rounded-2xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 p-4 dark:border-emerald-800 dark:from-emerald-900/30 dark:to-teal-900/30">
                  <div className="flex items-center gap-3">
                    <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 text-white shadow-md">
                      <Users className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-2xl font-extrabold text-emerald-900 dark:text-emerald-200">{onlineCount}</p>
                      <p className="text-xs text-emerald-700 dark:text-emerald-300">people using ChatVerse right now</p>
                    </div>
                  </div>
                </div>

                {/* Recent users list (quick view) */}
                <div className="rounded-2xl border border-slate-200/60 p-4 dark:border-slate-800/60">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Recent Users</p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => { setShowOwnerPanel(false); loadAllUsers(); setShowUsersModal(true) }}
                      className="h-6 px-2 text-[10px] text-slate-600 dark:text-slate-300"
                    >
                      View all →
                    </Button>
                  </div>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto">
                    {allUsers.length === 0 ? (
                      <p className="text-xs text-slate-400">No users yet. When people use ChatVerse, they'll appear here.</p>
                    ) : (
                      allUsers.slice(0, 5).map((u) => (
                        <div key={u.name} className="flex items-center gap-2 rounded-lg bg-slate-100/60 px-2 py-1.5 dark:bg-slate-800/60">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className={
                              u.plan === 'owner' ? 'bg-amber-400 to-orange-500 text-white' :
                              u.plan === 'premium' ? 'bg-amber-400 via-orange-500 to-rose-500 text-white' :
                              u.plan === 'plus' ? 'bg-teal-500 to-cyan-500 text-white' :
                              'bg-slate-400 to-slate-600 text-white'
                            }>
                              {u.name.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="truncate text-xs font-semibold text-slate-800 dark:text-slate-100">{u.name}</p>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400">
                              {u.plan === 'owner' ? 'OWNER · ∞ pts' : `${u.plan.toUpperCase()} · ${u.points} pts`}
                            </p>
                          </div>
                          <span className="text-[10px] text-slate-400">{formatRelative(u.lastActiveAt)}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Post announcement button */}
                <Button
                  onClick={() => { setShowOwnerPanel(false); setShowAnnouncementModal(true) }}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-orange-500/30 hover:from-amber-600 hover:to-orange-600"
                >
                  <Megaphone className="mr-2 h-4 w-4" /> Post global announcement
                </Button>

                {/* Post event button (NEW) */}
                <Button
                  onClick={() => {
                    setShowOwnerPanel(false)
                    setNewEvent({ title: '', description: '', date: '', time: '' })
                    setShowEventModal(true)
                  }}
                  className="w-full bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow-lg shadow-sky-500/30 hover:from-sky-600 hover:to-cyan-600"
                >
                  <CalendarDays className="mr-2 h-4 w-4" /> Post event
                </Button>

                {/* Manage users button (NEW) */}
                <Button
                  onClick={() => {
                    setShowOwnerPanel(false)
                    loadAllUsers()
                    setShowUsersModal(true)
                  }}
                  className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-lg shadow-teal-500/30 hover:from-teal-600 hover:to-cyan-600"
                >
                  <Users className="mr-2 h-4 w-4" /> Manage users ({allUsers.length || '...'})
                </Button>

                {/* Sign out */}
                <Button
                  variant="outline"
                  onClick={signOutOwner}
                  className="w-full border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-200"
                >
                  Sign out of owner mode
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Voice call modal (Push-To-Talk) ============================== */}
      <AnimatePresence>
        {showVoiceCallModal && activePersonality && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              if (voiceCallState !== 'listening' && voiceCallState !== 'transcribing' && voiceCallState !== 'thinking' && voiceCallState !== 'speaking') {
                endVoiceCall()
              }
            }}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-950/80 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.92, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-md overflow-hidden rounded-3xl border border-slate-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div className="flex items-center gap-2 text-white">
                  <span className="text-xs font-medium text-emerald-400">
                    <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 align-middle animate-pulse" />
                    Voice call
                  </span>
                </div>
                <button
                  onClick={endVoiceCall}
                  className="rounded-full bg-rose-500 px-3 py-1 text-xs font-bold text-white shadow-md hover:bg-rose-600"
                  title="End call"
                >
                  End call
                </button>
              </div>

              <div className="px-6 py-8 text-center">
                {/* AI avatar with pulsing ring */}
                <div className="relative mx-auto mb-5 h-28 w-28">
                  {voiceCallState === 'speaking' && (
                    <motion.div
                      animate={{ scale: [1, 1.25, 1], opacity: [0.7, 0, 0.7] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                      className={`absolute inset-0 rounded-full bg-gradient-to-br ${activePersonality.gradient}`}
                    />
                  )}
                  <motion.div
                    animate={voiceCallState === 'speaking' ? { scale: [1, 1.05, 1] } : {}}
                    transition={{ duration: 0.5, repeat: Infinity }}
                    className={`relative grid h-full w-full place-items-center rounded-full bg-gradient-to-br ${activePersonality.gradient} text-5xl shadow-2xl`}
                  >
                    {activePersonality.emoji}
                  </motion.div>
                </div>

                <h2 className="text-xl font-extrabold text-white">{activePersonality.name}</h2>
                <p className="text-xs text-slate-400">{activePersonality.tagline}</p>

                {/* Status text */}
                <div className="mt-4 min-h-[1.5rem] text-sm font-medium text-slate-300">
                  {voiceCallState === 'idle' && 'Tap the mic to talk'}
                  {voiceCallState === 'listening' && (
                    <span className="flex items-center justify-center gap-2 text-rose-400">
                      <motion.span
                        animate={{ scale: [1, 1.4, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity }}
                        className="inline-block h-2 w-2 rounded-full bg-rose-500"
                      />
                      Listening... tap again to stop
                    </span>
                  )}
                  {voiceCallState === 'transcribing' && 'Transcribing your voice...'}
                  {voiceCallState === 'thinking' && (
                    <span className="flex items-center justify-center gap-1">
                      <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="inline-block h-3.5 w-3.5 rounded-full border-2 teal-400/40 teal-400" />
                      {activePersonality.name} is thinking...
                    </span>
                  )}
                  {voiceCallState === 'speaking' && `${activePersonality.name} is speaking...`}
                  {voiceCallState === 'error' && <span className="text-rose-400">{voiceCallError}</span>}
                </div>

                {/* Transcript (user) */}
                {voiceCallTranscript && (
                  <div className="mt-4 rounded-xl bg-white/5 px-3 py-2 text-left text-sm text-slate-200">
                    <span className="text-[10px] font-semibold uppercase text-slate-500">You said</span>
                    <p className="mt-0.5">{voiceCallTranscript}</p>
                  </div>
                )}
                {/* AI response */}
                {voiceCallResponse && (
                  <div className="mt-2 rounded-xl bg-white/5 px-3 py-2 text-left text-sm text-slate-200">
                    <span className="text-[10px] font-semibold uppercase teal-400">{activePersonality.name} replied</span>
                    <p className="mt-0.5">{voiceCallResponse}</p>
                  </div>
                )}

                {/* Push-to-talk button */}
                <div className="mt-6 flex items-center justify-center gap-4">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      if (voiceCallState === 'listening') {
                        stopVoiceCallRecording()
                      } else if (voiceCallState === 'idle' || voiceCallState === 'error') {
                        startVoiceCall()
                      }
                    }}
                    disabled={voiceCallState === 'transcribing' || voiceCallState === 'thinking' || voiceCallState === 'speaking'}
                    className={`grid h-20 w-20 place-items-center rounded-full text-white shadow-xl transition disabled:opacity-50 ${
                      voiceCallState === 'listening'
                        ? 'bg-rose-500 shadow-rose-500/50'
                        : `bg-gradient-to-br ${activePersonality.gradient} shadow-teal-500/40`
                    }`}
                    title={voiceCallState === 'listening' ? 'Stop recording' : 'Tap to talk'}
                  >
                    {voiceCallState === 'listening' ? (
                      <Square className="h-7 w-7 fill-white" />
                    ) : (
                      <Mic className="h-8 w-8" />
                    )}
                  </motion.button>
                </div>

                <p className="mt-4 text-[11px] text-slate-500">
                  🎙️ Push-to-talk · Mic → ASR → AI → TTS → Speaker
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Video call modal (Webcam + Push-To-Talk) ============================== */}
      <AnimatePresence>
        {showVideoCallModal && activePersonality && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              if (videoCallState !== 'listening' && videoCallState !== 'transcribing' && videoCallState !== 'thinking' && videoCallState !== 'speaking') {
                endVideoCall()
              }
            }}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-950/90 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.92, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-2xl overflow-hidden rounded-3xl border border-slate-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div className="flex items-center gap-2 text-white">
                  <span className="text-xs font-medium text-sky-400">
                    <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-sky-400 align-middle animate-pulse" />
                    Video call
                  </span>
                </div>
                <button
                  onClick={endVideoCall}
                  className="rounded-full bg-rose-500 px-3 py-1 text-xs font-bold text-white shadow-md hover:bg-rose-600"
                  title="End call"
                >
                  End call
                </button>
              </div>

              {/* Main video stage: AnimatedMan (large, center) + user webcam (PiP, bottom-right) */}
              <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                {/* AI animated avatar (background gradient + AnimatedMan) */}
                <div className={`absolute inset-0 grid place-items-center bg-gradient-to-br ${activePersonality.gradient}`}>
                  <div className="text-center">
                    <AnimatedMan
                      state={videoCallState}
                      gradient={activePersonality.gradient}
                      className="mx-auto mb-2 h-48 w-48 sm:h-56 sm:w-56"
                    />
                    <p className="text-2xl font-extrabold text-white drop-shadow">{activePersonality.name}</p>
                    <p className="text-sm text-white/80">{activePersonality.tagline}</p>
                  </div>
                </div>

                {/* Pulsing ring while AI is speaking */}
                {videoCallState === 'speaking' && (
                  <motion.div
                    animate={{ scale: [1, 1.15, 1], opacity: [0.6, 0, 0.6] }}
                    transition={{ duration: 1.4, repeat: Infinity }}
                    className="absolute inset-0 grid place-items-center"
                  >
                    <div className="h-64 w-64 rounded-full bg-white/20" />
                  </motion.div>
                )}

                {/* User webcam preview (picture-in-picture, bottom-right) */}
                <div className="absolute bottom-3 right-3 h-32 w-44 overflow-hidden rounded-2xl border-2 border-white/30 bg-slate-900 shadow-xl sm:h-40 sm:w-56">
                  <video
                    ref={videoCallVideoRef}
                    autoPlay
                    muted
                    playsInline
                    className="h-full w-full object-cover [transform:scaleX(-1)]"
                  />
                  <div className="absolute bottom-1 left-2 text-[10px] font-medium text-white/80 drop-shadow">
                    You
                  </div>
                </div>

                {/* Status overlay (top-left) */}
                <div className="absolute left-3 top-3 rounded-full bg-slate-900/70 px-3 py-1 text-xs font-medium text-white backdrop-blur">
                  {videoCallState === 'idle' && 'Ready'}
                  {videoCallState === 'listening' && (
                    <span className="flex items-center gap-1.5 text-rose-400">
                      <motion.span animate={{ scale: [1, 1.4, 1] }} transition={{ duration: 0.8, repeat: Infinity }} className="inline-block h-1.5 w-1.5 rounded-full bg-rose-500" />
                      Listening...
                    </span>
                  )}
                  {videoCallState === 'transcribing' && 'Transcribing...'}
                  {videoCallState === 'thinking' && (
                    <span className="flex items-center gap-1.5">
                      <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="inline-block h-3 w-3 rounded-full border-2 border-white/40 border-t-white" />
                      {activePersonality.name} is thinking...
                    </span>
                  )}
                  {videoCallState === 'speaking' && `${activePersonality.name} is speaking...`}
                  {videoCallState === 'error' && <span className="text-rose-400">{videoCallError}</span>}
                </div>
              </div>

              {/* Transcript + AI response below the video stage */}
              <div className="max-h-32 overflow-y-auto px-4 py-3 text-sm">
                {videoCallTranscript && (
                  <div className="mb-2 rounded-xl bg-white/5 px-3 py-2 text-left text-slate-200">
                    <span className="text-[10px] font-semibold uppercase text-slate-500">You said</span>
                    <p className="mt-0.5">{videoCallTranscript}</p>
                  </div>
                )}
                {videoCallResponse && (
                  <div className="rounded-xl bg-white/5 px-3 py-2 text-left text-slate-200">
                    <span className="text-[10px] font-semibold uppercase text-sky-400">{activePersonality.name} replied</span>
                    <p className="mt-0.5">{videoCallResponse}</p>
                  </div>
                )}
                {!videoCallTranscript && !videoCallResponse && !videoCallError && (
                  <p className="text-center text-slate-500">Tap the mic below to talk to {activePersonality.name}</p>
                )}
              </div>

              {/* Push-to-talk button */}
              <div className="flex items-center justify-center gap-4 px-6 py-4">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    if (videoCallState === 'listening') {
                      stopVideoCallRecording()
                    } else if (videoCallState === 'idle' || videoCallState === 'error') {
                      startVideoCall()
                    }
                  }}
                  disabled={videoCallState === 'transcribing' || videoCallState === 'thinking' || videoCallState === 'speaking'}
                  className={`grid h-16 w-16 place-items-center rounded-full text-white shadow-xl transition disabled:opacity-50 ${
                    videoCallState === 'listening'
                      ? 'bg-rose-500 shadow-rose-500/50'
                      : `bg-gradient-to-br ${activePersonality.gradient} shadow-teal-500/40`
                  }`}
                  title={videoCallState === 'listening' ? 'Stop recording' : 'Tap to talk'}
                >
                  {videoCallState === 'listening' ? (
                    <Square className="h-6 w-6 fill-white" />
                  ) : (
                    <Mic className="h-7 w-7" />
                  )}
                </motion.button>
              </div>

              <p className="pb-4 text-center text-[11px] text-slate-500">
                📹 Webcam preview · 🎙️ Push-to-talk · Mic → ASR → AI → TTS → Speaker
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Settings modal ============================== */}
      <AnimatePresence>
        {showSettingsModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowSettingsModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg max-h-[90vh] overflow-hidden rounded-3xl border border-slate-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/95 flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 text-white shadow-md">
                    <Settings className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Settings</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Customize your ChatVerse experience</p>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowSettingsModal(false)} className="h-8 w-8 text-slate-500">
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Scrollable content */}
              <div className="flex-1 overflow-y-auto p-4 space-y-5">
                {/* Account card */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Account</h3>
                  <div className="rounded-2xl border border-slate-200/60 bg-slate-100/50 p-3 dark:border-slate-800/60 dark:bg-slate-800/50">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-11 w-11">
                        {currentUser?.plan === 'owner' && ownerInfo ? (
                          <AvatarFallback className={`bg-gradient-to-br ${ownerInfo.gradient} text-white`}>
                            {ownerInfo.icon === 'crown' ? <Crown className="h-5 w-5" /> : <Shield className="h-5 w-5" />}
                          </AvatarFallback>
                        ) : currentUser ? (
                          <AvatarFallback className={
                            currentUser.plan === 'premium' ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 text-white' :
                            currentUser.plan === 'plus' ? 'bg-gradient-to-br from-teal-500 to-cyan-500 text-white' :
                            'bg-gradient-to-br from-slate-500 to-slate-700 text-white'
                          }>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        ) : (
                          <AvatarFallback className="bg-gradient-to-br from-slate-500 to-slate-700 text-white">
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-slate-900 dark:text-white">
                          {currentUser ? currentUser.name : 'Guest user'}
                        </p>
                        {currentUser?.email && (
                          <p className="truncate text-[11px] text-slate-500 dark:text-slate-400">{currentUser.email}</p>
                        )}
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {currentUser ? (
                            <>
                              <span className={`rounded px-1.5 py-0.5 font-bold uppercase text-white ${
                                currentUser.plan === 'owner' ? 'bg-amber-500' :
                                currentUser.plan === 'premium' ? 'bg-gradient-to-r from-amber-400 to-rose-500' :
                                currentUser.plan === 'plus' ? 'bg-gradient-to-r from-teal-500 to-cyan-500' :
                                'bg-slate-500'
                              }`}>{currentUser.plan}</span>
                              {' · '}
                              {currentUser.plan === 'owner' ? 'unlimited points' : `${currentUser.points} points`}
                            </>
                          ) : (
                            'Not signed in'
                          )}
                        </p>
                      </div>
                    </div>
                    {currentUser && (
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        {currentUser.plan !== 'owner' && (
                          <Button
                            size="sm"
                            onClick={() => { setShowSettingsModal(false); setShowPlansModal(true) }}
                            className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 text-xs font-bold text-white"
                          >
                            <Sparkles className="mr-1 h-3 w-3" /> Upgrade plan
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </section>

                {/* Appearance */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Appearance</h3>
                  <div className="rounded-2xl border border-slate-200/60 bg-slate-100/50 p-3 dark:border-slate-800/60 dark:bg-slate-800/50">
                    <Label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">Theme</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setTheme('light')}
                        className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm font-semibold transition ${
                          theme === 'light'
                            ? 'border-amber-400 bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-200'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
                        }`}
                      >
                        <Sun className="h-4 w-4" /> Light
                      </button>
                      <button
                        onClick={() => setTheme('dark')}
                        className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm font-semibold transition ${
                          theme === 'dark'
                            ? 'teal-400 teal-50 teal-700 dark:teal-900/30 dark:teal-200'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
                        }`}
                      >
                        <Moon className="h-4 w-4" /> Dark
                      </button>
                    </div>
                  </div>
                </section>

                {/* Voice / TTS */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">AI Voice (for calls)</h3>
                  <div className="rounded-2xl border border-slate-200/60 bg-slate-100/50 p-3 dark:border-slate-800/60 dark:bg-slate-800/50">
                    <Label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">Voice used in Voice / Video calls</Label>
                    <select
                      value={settingsTtsVoice}
                      onChange={(e) => setSettingsTtsVoice(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-400 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    >
                      <option value="tongtong">Tongtong — warm & friendly (default)</option>
                      <option value="chuichui">Chuichui — lively & cute</option>
                      <option value="xiaochen">Xiaochen — calm & professional</option>
                      <option value="jam">Jam — British gentleman</option>
                      <option value="kazi">Kazi — clear & standard</option>
                      <option value="douji">Douji — natural & fluent</option>
                      <option value="luodo">Luodo — emotional & engaging</option>
                    </select>
                    <p className="mt-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                      💡 Used when the AI speaks during Voice Call and Video Call. Changes are saved automatically.
                    </p>
                  </div>
                </section>

                {/* Default AI personality */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Default AI</h3>
                  <div className="rounded-2xl border border-slate-200/60 bg-slate-100/50 p-3 dark:border-slate-800/60 dark:bg-slate-800/50">
                    <Label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">Personality used when starting a new chat without picking</Label>
                    <select
                      value={settingsDefaultPersonality}
                      onChange={(e) => setSettingsDefaultPersonality(e.target.value as PersonalityId | 'ask')}
                      className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-400 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    >
                      <option value="ask">Ask me each time (show picker)</option>
                      {PERSONALITIES.map((p) => (
                        <option key={p.id} value={p.id}>{p.name} {p.emoji} — {p.tagline}</option>
                      ))}
                    </select>
                  </div>
                </section>

                {/* Data & privacy */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Data & Privacy</h3>
                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        if (confirm('Clear ALL conversations? This cannot be undone.')) {
                          setConversations([])
                          setActiveId(null)
                          try {
                            if (currentUser) localStorage.removeItem(getUserStorageKey(currentUser.name))
                          } catch {}
                          toast.success('All conversations cleared')
                          setShowSettingsModal(false)
                        }
                      }}
                      className="flex w-full items-center gap-3 rounded-2xl border border-rose-200/60 bg-rose-50/50 p-3 text-left transition hover:bg-rose-100 dark:border-rose-800/60 dark:bg-rose-900/20 dark:hover:bg-rose-900/30"
                    >
                      <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-rose-500 to-pink-500 text-white shadow-md">
                        <Trash2 className="h-4 w-4" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-semibold text-rose-700 dark:text-rose-300">Clear all conversations</p>
                        <p className="text-[11px] text-rose-600/80 dark:text-rose-400/80">Delete every chat from this device. Cannot be undone.</p>
                      </div>
                    </button>
                  </div>
                </section>

                {/* Owner (only shown if owner) */}
                {ownerInfo && (
                  <section>
                    <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">Owner</h3>
                    <div className="space-y-2">
                      <button
                        onClick={() => { setShowSettingsModal(false); setShowOwnerPanel(true) }}
                        className="flex w-full items-center gap-3 rounded-2xl border border-amber-200/60 bg-amber-50/50 p-3 text-left transition hover:bg-amber-100 dark:border-amber-800/60 dark:bg-amber-900/20 dark:hover:bg-amber-900/30"
                      >
                        <div className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${ownerInfo.gradient} text-white shadow-md`}>
                          {ownerInfo.icon === 'crown' ? <Crown className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-amber-700 dark:text-amber-300">Open owner panel</p>
                          <p className="text-[11px] text-amber-600/80 dark:text-amber-400/80">Post announcements, see live count, copy owner links</p>
                        </div>
                      </button>
                      <button
                        onClick={() => { signOutOwner(); setShowSettingsModal(false) }}
                        className="flex w-full items-center gap-3 rounded-2xl border border-slate-200/60 bg-white p-3 text-left transition hover:bg-slate-50 dark:border-slate-700/60 dark:bg-slate-800/50 dark:hover:bg-slate-800"
                      >
                        <div className="grid h-9 w-9 place-items-center rounded-xl bg-slate-500 text-white shadow-md">
                          <LogOut className="h-4 w-4" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">Sign out of owner mode</p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">Return to a normal user account</p>
                        </div>
                      </button>
                    </div>
                  </section>
                )}

                {/* About */}
                <section>
                  <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">About</h3>
                  <div className="rounded-2xl border teal-200/60 bg-gradient-to-br teal-50 to-amber-50 p-3 dark:teal-800/60 dark:from-teal-900/30 dark:to-amber-900/30">
                    <div className="mb-2 flex items-center gap-2">
                      <Sparkles className="h-4 w-4 teal-600 dark:amber-300" />
                      <p className="text-sm font-bold teal-900 dark:teal-200">ChatVerse</p>
                      <span className="rounded-full teal-500/20 px-2 py-0.5 text-[10px] font-semibold teal-700 dark:amber-300">v11.0</span>
                    </div>
                    <p className="text-[11px] leading-relaxed teal-800/80 dark:teal-200/80">
                      AI chat assistant built by Mohammed Zayyan. Image upload, voice &amp; video calls, AI image &amp; video generation, and more.
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <span className="rounded-md bg-amber-100 px-2 py-0.5 text-[10px] font-semibold text-amber-800 dark:bg-amber-900/40 dark:text-amber-200">
                        👑 Created by Mohammed Zayyan
                      </span>
                      <span className="rounded-md teal-100 px-2 py-0.5 text-[10px] font-semibold teal-800 dark:teal-900/40 dark:teal-200">
                      </span>
                    </div>
                  </div>
                </section>
              </div>

              {/* Footer */}
              <div className="border-t border-slate-200/60 p-3 text-center text-[11px] text-slate-400 dark:border-slate-800/60 dark:text-slate-500">
                Settings are saved automatically on this device
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Incoming call modal (Accept / Decline) ============================== */}
      <AnimatePresence>
        {incomingCall && incomingCall.personality && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.85, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.85, y: 30, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 220, damping: 22 }}
              className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-slate-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl"
            >
              {/* Pulsing ring around the avatar */}
              <div className="relative px-6 pb-2 pt-10 text-center">
                <div className="relative mx-auto mb-4 h-32 w-32">
                  <motion.div
                    animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
                    transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut' }}
                    className={`absolute inset-0 rounded-full bg-gradient-to-br ${incomingCall.personality.gradient}`}
                  />
                  <motion.div
                    animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0, 0.4] }}
                    transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut', delay: 0.4 }}
                    className={`absolute inset-0 rounded-full bg-gradient-to-br ${incomingCall.personality.gradient}`}
                  />
                  <div className={`relative grid h-full w-full place-items-center rounded-full bg-gradient-to-br ${incomingCall.personality.gradient} text-6xl shadow-2xl ring-4 ring-white/20`}>
                    {incomingCall.personality.emoji}
                  </div>
                </div>

                <h2 className="text-2xl font-extrabold text-white">{incomingCall.personality.name}</h2>
                <p className="text-sm text-slate-300">{incomingCall.personality.tagline}</p>

                <motion.div
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                  className="mt-3 flex items-center justify-center gap-2 text-sm font-medium text-emerald-400"
                >
                  <Phone className="h-4 w-4" />
                  Incoming video call...
                </motion.div>
              </div>

              {/* Accept / Decline buttons */}
              <div className="grid grid-cols-2 gap-3 p-6 pt-2">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    const p = incomingCall.personality
                    setIncomingCall(null)
                    // Reset video call state and open the video call modal
                    setVideoCallHistory([])
                    setVideoCallState('idle')
                    setVideoCallTranscript('')
                    setVideoCallResponse('')
                    setVideoCallError('')
                    setShowVideoCallModal(true)
                    toast.success(`Call with ${p?.name} started 🎥`)
                  }}
                  className="flex flex-col items-center gap-1.5 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 px-4 py-4 text-white shadow-lg shadow-emerald-500/30 hover:from-emerald-600 hover:to-teal-600"
                >
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-white/20">
                    <VideoIcon className="h-6 w-6" />
                  </div>
                  <span className="text-sm font-bold">Accept</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => {
                    const p = incomingCall.personality
                    setIncomingCall(null)
                    toast.info(`Call from ${p?.name} declined`)
                  }}
                  className="flex flex-col items-center gap-1.5 rounded-2xl bg-gradient-to-br from-rose-500 to-red-500 px-4 py-4 text-white shadow-lg shadow-rose-500/30 hover:from-rose-600 hover:to-red-600"
                >
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-white/20">
                    <Phone className="h-6 w-6 rotate-[135deg]" />
                  </div>
                  <span className="text-sm font-bold">Decline</span>
                </motion.button>
              </div>

              <p className="pb-4 text-center text-[11px] text-slate-500">
                Accept to start the video call · Decline to dismiss
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== "What's your name?" modal (first visit only) ============================== */}
      <AnimatePresence>
        {showNameModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] grid place-items-center bg-black/90 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.92, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 20, opacity: 0 }}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-[#0a0f1a] to-[#05070d] shadow-2xl"
            >
              <div className="px-6 pb-2 pt-10 text-center">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5, type: 'spring', stiffness: 200 }}
                  whileHover={{ scale: 1.05, rotate: 4 }}
                  className="relative mx-auto mb-4 grid h-16 w-16 place-items-center overflow-hidden rounded-2xl shadow-lg shadow-cyan-500/30"
                >
                  <motion.span
                    animate={{ opacity: [0.4, 0.8, 0.4] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                    className="absolute inset-0 bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-md"
                  />
                  <Image
                    src="/chatverse-logo.png"
                    alt="ChatVerse AI"
                    width={64}
                    height={64}
                    className="relative z-10 h-16 w-16 rounded-2xl object-cover"
                    priority
                  />
                </motion.div>
                <h2 className="text-2xl font-extrabold text-gradient">Welcome to ChatVerse</h2>
                <p className="mt-2 text-sm text-slate-400">
                  What's your name? Enter it below to start chatting with AI.
                </p>
              </div>
              <form onSubmit={handleNameSubmit} className="space-y-3 p-6 pt-4">
                <Input
                  type="text"
                  value={enteredName}
                  onChange={(e) => setEnteredName(e.target.value)}
                  placeholder="Your name (e.g. Alex)..."
                  maxLength={40}
                  autoFocus
                  className="h-12 rounded-2xl border-white/10 bg-white/[0.04] text-white placeholder:text-slate-500 focus-visible:ring-cyan-400/50"
                />
                <Button
                  type="submit"
                  disabled={!enteredName.trim() || isLoggingIn}
                  className="h-12 w-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 text-base font-bold text-white shadow-lg shadow-cyan-500/30 hover:from-cyan-400 hover:to-blue-400"
                >
                  {isLoggingIn ? 'Please wait...' : 'Start chatting →'}
                </Button>
                <p className="text-center text-[10px] text-slate-500">
                  No password needed. Your name is saved on this device and used to identify your account + points.
                </p>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Plans / Upgrade modal ============================== */}
      <AnimatePresence>
        {showPlansModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowPlansModal(false)}
            className="fixed inset-0 z-[60] grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-3xl border border-slate-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div>
                  <h2 className="text-lg font-extrabold text-white">Choose your plan</h2>
                  <p className="text-[11px] text-slate-400">Free: 3 pts/msg, 50/day · Plus: 2 pts/msg, unlimited · Premium: 1 pt/msg, unlimited</p>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowPlansModal(false)} className="h-8 w-8 text-slate-400">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto p-4">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {([
                    { id: 'free', name: 'Free', gradient: 'from-slate-500 to-slate-700', price: '0 pts', features: ['50 messages per day', '3 pts per message', '5 pts per image', 'No video generation', '30 starting points (~10 msg)', 'Standard response speed'] },
                    { id: 'plus', name: 'Plus', gradient: 'from-cyan-500 to-blue-600', price: '300 pts', features: ['Unlimited messages', '2 pts per message (33% off)', '4 pts per image', 'Video generation (10 pts)', '300 starting points (~150 msg)', 'Fast reply (priority)', 'Premium button animations'], popular: true, cost: 300 },
                    { id: 'premium', name: 'Premium', gradient: 'from-amber-400 via-yellow-500 to-amber-600', price: '1000 pts', features: ['Unlimited messages', '1 pt per message (67% off)', '2 pts per image', 'Video generation (5 pts)', '1000 starting points (~1000 msg)', 'Priority support', 'Longer history (50 msgs)', 'Premium animations + early access'], cost: 1000 },
                  ] as const).map((plan) => {
                    const isCurrent = currentUser?.plan === plan.id
                    const canAfford = plan.id !== 'free' && currentUser && currentUser.points >= (plan as any).cost
                    return (
                      <div
                        key={plan.id}
                        className={`relative overflow-hidden rounded-2xl border p-4 ${
                          plan.popular ? 'border-amber-400/60 bg-amber-500/10' : 'border-slate-700 bg-slate-800/50'
                        }`}
                      >
                        {plan.popular && (
                          <div className="absolute right-3 top-3 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 px-2 py-0.5 text-[10px] font-bold text-black">
                            POPULAR
                          </div>
                        )}
                        <div className={`mb-2 inline-block rounded-xl bg-gradient-to-r ${plan.gradient} px-3 py-1 text-sm font-bold uppercase tracking-wide text-white`}>
                          {plan.name}
                        </div>
                        <p className="mb-3 text-xs font-semibold text-slate-300">{plan.price}</p>
                        <ul className="mb-4 space-y-1.5 text-xs text-slate-300">
                          {plan.features.map((f, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <Check className="mt-0.5 h-3 w-3 shrink-0 text-amber-400" />
                              <span>{f}</span>
                            </li>
                          ))}
                        </ul>
                        {isCurrent ? (
                          <div className="rounded-xl bg-emerald-500/20 px-3 py-2 text-center text-xs font-bold text-emerald-300">
                            ✓ Your current plan
                          </div>
                        ) : plan.id === 'free' ? (
                          <div className="rounded-xl bg-slate-700/50 px-3 py-2 text-center text-xs font-bold text-slate-400">
                            Default plan
                          </div>
                        ) : (
                          <Button
                            onClick={() => buyPlanWithPoints(plan.id as 'plus' | 'premium')}
                            disabled={!canAfford || buyingPlan === plan.id}
                            className={`w-full text-xs font-bold ${
                              canAfford
                                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black hover:from-amber-500 hover:to-yellow-600'
                                : 'bg-slate-700 text-slate-400'
                            }`}
                            title={canAfford ? `Buy with ${(plan as any).cost} points` : `You need ${(plan as any).cost} points (you have ${currentUser?.points ?? 0})`}
                          >
                            {buyingPlan === plan.id ? 'Processing…' : canAfford ? `Buy with ${(plan as any).cost} pts` : `Need ${(plan as any).cost} pts`}
                          </Button>
                        )}
                      </div>
                    )
                  })}
                </div>
                {currentUser?.plan === 'owner' && (
                  <div className="mt-4 rounded-2xl border border-amber-400/40 bg-amber-500/10 p-3 text-center text-sm text-amber-200">
                    👑 You're an owner — you have <strong>unlimited everything</strong>. Use "Manage users" in the Owner Panel to upgrade other users.
                  </div>
                )}
                <p className="mt-4 text-center text-[11px] text-slate-500">
                  Buy premium with your own points — or ask Mohammed Zayyan to gift you points.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Out of points modal ============================== */}
      <AnimatePresence>
        {showOutOfPointsModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowOutOfPointsModal(false)}
            className="fixed inset-0 z-[60] grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-rose-500/30 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl"
            >
              <div className="px-6 pb-2 pt-10 text-center">
                <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-rose-500 to-red-500 text-white shadow-lg">
                  <Zap className="h-8 w-8" />
                </div>
                <h2 className="text-2xl font-extrabold text-white">Out of points!</h2>
                <p className="mt-1 text-sm text-slate-400">
                  You've used all your free points. Each message costs 3 points. Upgrade to keep chatting — or ask an owner to gift you more points!
                </p>
              </div>
              <div className="space-y-2 p-6 pt-4">
                <Button
                  onClick={() => { setShowOutOfPointsModal(false); setShowPlansModal(true) }}
                  className="h-12 w-full bg-gradient-to-r from-teal-500 to-cyan-500 text-base font-bold text-white shadow-lg hover:from-teal-600 hover:to-cyan-600"
                >
                  <Sparkles className="mr-2 h-5 w-5" /> View plans
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowOutOfPointsModal(false)}
                  className="h-10 w-full border-slate-700 text-slate-300"
                >
                  Maybe later
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Knowledge Base modal (saved user notes) ============================== */}
      <KnowledgeBaseModal open={showKnowledgeBase} onClose={() => setShowKnowledgeBase(false)} userName={currentUser?.name ?? null} />

      {/* ============================== Image Lightbox (full-size image viewer — no 404 from data URLs) ============================== */}
      <AnimatePresence>
        {lightboxImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxImage(null)}
            className="fixed inset-0 z-[100] grid place-items-center bg-black/95 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[90vh] max-w-[95vw] overflow-hidden rounded-2xl"
            >
              <img src={lightboxImage} alt="Full size image" className="max-h-[90vh] max-w-[95vw] rounded-2xl object-contain" />
              {/* Download button (works for data URLs — converts to blob + downloads) */}
              <a
                href={lightboxImage}
                download={`chatverse-image-${Date.now()}.png`}
                onClick={(e) => e.stopPropagation()}
                className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-xl bg-black/60 text-white backdrop-blur-xl transition hover:bg-black/80"
                title="Download image"
              >
                <Download className="h-5 w-5" />
              </a>
            </motion.div>
            {/* Close button */}
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-xl bg-black/60 text-white backdrop-blur-xl transition hover:bg-black/80"
              title="Close (Esc)"
            >
              <X className="h-5 w-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Notifications modal (announcements + events) ============================== */}
      <AnimatePresence>
        {showNotificationsModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowNotificationsModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md max-h-[85vh] overflow-hidden rounded-3xl border border-teal-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-amber-500 text-white shadow-md">
                    <Bell className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-white">Notifications</h2>
                    <p className="text-[11px] text-slate-400">Announcements & upcoming events</p>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowNotificationsModal(false)} className="h-8 w-8 text-slate-400">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {announcements.length === 0 && events.length === 0 ? (
                  <div className="py-10 text-center">
                    <Bell className="mx-auto mb-2 h-10 w-10 text-slate-700" />
                    <p className="text-sm font-medium text-slate-500">No notifications yet</p>
                    <p className="text-xs text-slate-600">Announcements and events from owners will appear here.</p>
                  </div>
                ) : (
                  <>
                    {/* Announcements */}
                    {announcements.map((a) => (
                      <div key={a.id} className="rounded-2xl border border-amber-400/20 bg-amber-500/5 p-3">
                        <div className="flex items-start gap-2">
                          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-amber-500 to-orange-500 text-white">
                            <Megaphone className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-amber-200">{a.authorName}</span>
                              <span className="text-[10px] text-amber-400/60">{a.authorRole}</span>
                            </div>
                            <p className="mt-1 text-sm text-amber-100">{a.text}</p>
                            <p className="mt-1 text-[10px] text-slate-500">{new Date(a.createdAt).toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Events */}
                    {events.filter(e => {
                      const eventDate = new Date(`${e.date}T${e.time || '00:00'}`).getTime()
                      return eventDate + 24*60*60*1000 > Date.now()
                    }).map((e) => (
                      <div key={e.id} className="rounded-2xl border border-teal-400/20 bg-teal-500/5 p-3">
                        <div className="flex items-start gap-2">
                          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-teal-500 to-cyan-500 text-white">
                            <CalendarDays className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-teal-200">{e.authorName}</span>
                              <span className="text-[10px] text-teal-400/60">{e.authorRole}</span>
                            </div>
                            <p className="mt-1 text-sm font-semibold text-teal-100">{e.title}</p>
                            <p className="text-xs text-teal-300/80">{formatEventDate(e.date, e.time)}</p>
                            {e.description && <p className="mt-1 text-xs text-slate-400">{e.description}</p>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Owner Users dashboard modal ============================== */}
      <AnimatePresence>
        {showUsersModal && ownerInfo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowUsersModal(false)}
            className="fixed inset-0 z-[60] grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 20, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-3xl max-h-[90vh] overflow-hidden rounded-3xl border border-slate-200/20 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-white/10 p-4">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 text-white shadow-md">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-white">All Users</h2>
                    <p className="text-[11px] text-slate-400">{allUsers.length} total · gift points + upgrade plans for free</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => loadAllUsers()}
                    className="border-slate-700 text-slate-300"
                  >
                    Refresh
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => setShowUsersModal(false)} className="h-8 w-8 text-slate-400">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {allUsers.length === 0 ? (
                  <p className="py-10 text-center text-sm text-slate-500">No users yet — when people log in, they'll appear here.</p>
                ) : (
                  allUsers.map((u) => (
                    <div key={u.name} className="rounded-2xl border border-slate-700 bg-slate-800/50 p-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className={
                            u.plan === 'owner' ? 'bg-gradient-to-br from-amber-400 to-orange-500 text-white' :
                            u.plan === 'premium' ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 text-white' :
                            u.plan === 'plus' ? 'bg-gradient-to-br from-teal-500 to-cyan-500 text-white' :
                            'bg-gradient-to-br from-slate-500 to-slate-700 text-white'
                          }>
                            {u.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="truncate text-sm font-bold text-white">{u.name}</p>
                          <div className="flex items-center gap-2 text-[11px]">
                            <span className={`rounded px-1.5 py-0.5 font-bold uppercase tracking-wide text-white ${
                              u.plan === 'owner' ? 'bg-gradient-to-r from-amber-400 to-orange-500' :
                              u.plan === 'premium' ? 'bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500' :
                              u.plan === 'plus' ? 'bg-gradient-to-r from-teal-500 to-cyan-500' :
                              'bg-gradient-to-r from-slate-500 to-slate-700'
                            }`}>
                              {u.plan}
                            </span>
                            <span className="text-slate-400">
                              {u.plan === 'owner' ? '∞ points' : `${u.points} pts`}
                            </span>
                          </div>
                        </div>
                      </div>
                      {u.plan !== 'owner' && (
                        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                          {/* Gift points */}
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              placeholder="Gift pts"
                              value={giftPointsAmount[u.name] || ''}
                              onChange={(e) => setGiftPointsAmount((prev) => ({ ...prev, [u.name]: e.target.value }))}
                              className="h-8 w-24 rounded-lg border-slate-700 bg-slate-900 text-xs text-white"
                            />
                            <Button
                              size="sm"
                              onClick={() => {
                                const amt = parseInt(giftPointsAmount[u.name] || '0', 10)
                                if (amt && amt > 0) giftPointsToUser(u.name, amt)
                              }}
                              className="h-8 bg-emerald-500 px-2.5 text-xs font-bold text-white hover:bg-emerald-600"
                            >
                              + Gift
                            </Button>
                          </div>
                          {/* Upgrade plan */}
                          <div className="flex items-center gap-1">
                            <Button
                              size="sm"
                              onClick={() => upgradeUserPlan(u.name, 'plus')}
                              disabled={u.plan === 'plus' || u.plan === 'premium'}
                              className="h-8 flex-1 teal-500 px-2 text-[11px] font-bold text-white teal-600 disabled:opacity-30"
                            >
                              → Plus
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => upgradeUserPlan(u.name, 'premium')}
                              disabled={u.plan === 'premium'}
                              className="h-8 flex-1 bg-gradient-to-r from-amber-500 to-rose-500 px-2 text-[11px] font-bold text-white hover:opacity-90 disabled:opacity-30"
                            >
                              → Premium
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============================== Post event modal (owner only) ============================== */}
      <AnimatePresence>
        {showEventModal && ownerInfo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowEventModal(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-slate-900/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md overflow-hidden rounded-3xl border border-slate-200/60 bg-white/95 shadow-2xl backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-900/95"
            >
              <div className="flex items-center justify-between border-b border-slate-200/60 p-4 dark:border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-cyan-500 text-white shadow-md">
                    <CalendarDays className="h-5 w-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Post an Event</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Posted by {ownerInfo.name} · {ownerInfo.role}</p>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => setShowEventModal(false)} className="h-8 w-8 text-slate-500">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-3 p-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Event title *</Label>
                  <Input
                    value={newEvent.title}
                    onChange={(e) => setNewEvent((p) => ({ ...p, title: e.target.value }))}
                    placeholder="e.g. Live Q&A with Zara"
                    maxLength={80}
                    className="rounded-xl border-slate-200 dark:border-slate-700"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Date *</Label>
                    <Input
                      type="date"
                      value={newEvent.date}
                      onChange={(e) => setNewEvent((p) => ({ ...p, date: e.target.value }))}
                      className="rounded-xl border-slate-200 dark:border-slate-700"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Time</Label>
                    <Input
                      type="time"
                      value={newEvent.time}
                      onChange={(e) => setNewEvent((p) => ({ ...p, time: e.target.value }))}
                      className="rounded-xl border-slate-200 dark:border-slate-700"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Description</Label>
                  <textarea
                    value={newEvent.description}
                    onChange={(e) => setNewEvent((p) => ({ ...p, description: e.target.value }))}
                    placeholder="What's this event about?"
                    maxLength={280}
                    rows={3}
                    className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-400 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                  <p className="text-right text-[11px] text-slate-400">{newEvent.description.length}/280</p>
                </div>
                <Button
                  onClick={postEvent}
                  disabled={!newEvent.title.trim() || !newEvent.date}
                  className="w-full bg-gradient-to-r from-sky-500 to-cyan-500 text-white shadow-lg shadow-sky-500/30 hover:from-sky-600 hover:to-cyan-600"
                >
                  <CalendarDays className="mr-2 h-4 w-4" /> Post event
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}


// --- Format relative time for chat list ---
function formatRelative(ts: number): string {
  const diff = Date.now() - ts
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'now'
  if (m < 60) return `${m}m`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h`
  const d = Math.floor(h / 24)
  if (d < 7) return `${d}d`
  return new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' })
}

// --- Message bubble component (WhatsApp + Discord hybrid) ---
function MessageBubble({
  message,
  personality,
  onCopy,
  onImageClick,
}: {
  message: ChatMessage
  personality: Personality
  onCopy: () => void
  onImageClick?: (img: string) => void
}) {
  const isUser = message.role === 'user'
  const isError = message.status === 'error'
  const isEmpty = !message.content && message.status === 'sending'
  const isGenerating = message.status === 'generating'

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 220, damping: 22 }}
      className={`group flex items-end gap-2 ${isUser ? 'flex-row-reverse' : ''}`}
    >
      {/* Avatar (Discord style — both sides) */}
      {!isUser && (
        <Avatar className="h-8 w-8 shrink-0 ring-2 ring-cyan-400/30">
          <AvatarFallback className={`bg-gradient-to-br ${personality.gradient} text-sm`}>
            {personality.emoji}
          </AvatarFallback>
        </Avatar>
      )}
      {isUser && (
        <Avatar className="h-8 w-8 shrink-0">
          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white ring-2 ring-blue-400/30">
            <User className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      )}

      {/* Bubble */}
      <div
        className={`group/bubble max-w-[80%] overflow-hidden rounded-2xl px-3.5 py-2.5 text-sm shadow-md transition-all duration-300 hover:shadow-lg sm:max-w-[75%] ${
          isUser
            ? 'bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 text-white rounded-br-md shadow-blue-500/30'
            : isError
            ? 'bg-rose-500/10 text-rose-200 ring-1 ring-rose-500/30 rounded-bl-md'
            : 'border border-white/10 bg-white/[0.04] text-slate-100 rounded-bl-md backdrop-blur-xl hover:bg-white/[0.06] hover:border-cyan-400/20'
        }`}
      >
        {/* Discord-style name header for AI messages */}
        {!isUser && (
          <div className="mb-1 flex items-center gap-2">
            <span className="text-xs font-bold text-white">{personality.name}</span>
            <span className="text-[10px] text-slate-400">AI · {formatTime(message.timestamp)}</span>
          </div>
        )}
        {isUser && (
          <div className="mb-0.5 flex items-center justify-end gap-1">
            <span className="text-[10px] text-blue-100/80">You · {formatTime(message.timestamp)}</span>
            {message.status === 'sent' && <CheckCheck className="h-3 w-3 text-blue-100" />}
            {message.status === 'sending' && <Check className="h-3 w-3 text-blue-200/60" />}
          </div>
        )}

        {/* Content (markdown for AI, plain for user) */}
        {isGenerating ? (
          <SciFiLoadingScreen
            label={message.generatingType === 'video' ? 'GENERATING VIDEO' : message.generatingType === 'news' ? 'FETCHING NEWS' : message.generatingType === 'weather' ? 'FETCHING WEATHER' : message.generatingType === 'search' ? 'SEARCHING WEB' : 'GENERATING IMAGE'}
            sublabel={message.generatingType === 'video' ? 'Creating AI image + animating... 30-90 seconds' : message.generatingType === 'news' ? 'Fetching latest news from around the world...' : message.generatingType === 'weather' ? 'Getting real-time weather data...' : message.generatingType === 'search' ? 'Searching the internet for latest info...' : 'Creating from your description... 30-60 seconds'}
          />
        ) : isEmpty ? (
          <div className="flex gap-1 py-1">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                animate={{ y: [0, -3, 0], opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
                className="inline-block h-2 w-2 rounded-full bg-cyan-400"
              />
            ))}
          </div>
        ) : isUser ? (
          <div className="space-y-1.5">
            {/* Display images for user messages */}
            {message.imageBase64 && !message.imagesBase64 && (
              <button type="button" onClick={() => onImageClick?.(message.imageBase64!)} className="block" title="Click to open full size">
                <img src={message.imageBase64} alt="Uploaded by user" className="max-h-48 w-auto rounded-xl bg-white/10 object-cover transition hover:opacity-90" />
              </button>
            )}
            {message.imagesBase64 && message.imagesBase64.length > 0 && (
              <div className={`grid gap-1.5 ${message.imagesBase64.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                {message.imagesBase64.map((img, idx) => (
                  <button key={idx} type="button" onClick={() => onImageClick?.(img)} className="block" title={`Image ${idx + 1}`}>
                    <img src={img} alt={`Uploaded ${idx + 1}`} className="max-h-40 w-full rounded-xl bg-white/10 object-cover transition hover:opacity-90" />
                  </button>
                ))}
              </div>
            )}
            {message.content && (
              <div className="whitespace-pre-wrap break-words leading-snug">{message.content}</div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {/* Display AI-generated images (for inline image generation) */}
            {message.imagesBase64 && message.imagesBase64.length > 0 && (
              <div className="grid gap-1.5">
                {message.imagesBase64.map((img, idx) => (
                  <button key={idx} type="button" onClick={() => onImageClick?.(img)} className="block" title="Click to open full size">
                    <img src={img} alt={`AI generated image ${idx + 1}`} className="max-h-80 w-full rounded-xl shadow-md transition hover:opacity-90" />
                  </button>
                ))}
              </div>
            )}
            {/* Display AI text response (markdown) */}
            {message.content && (
              <div className="prose prose-sm max-w-none leading-snug dark:prose-invert prose-p:my-1 prose-ul:my-1 prose-ol:my-1 prose-pre:my-2 prose-code:before:content-none prose-code:after:content-none prose-code:rounded prose-code:bg-slate-100 prose-code:px-1.5 prose-code:py-0.5 prose-code:teal-700 dark:prose-code:bg-slate-900 dark:prose-code:amber-300 prose-headings:my-2 prose-headings:font-bold">
                <SmartMarkdown content={message.content} onCopy={onCopy} />
              </div>
            )}
          </div>
        )}

        {/* Copy button on hover (Discord-style) */}
        {!isEmpty && !isError && (
          <div className="mt-1 flex justify-end">
            <button
              onClick={onCopy}
              className="rounded-md px-1.5 py-0.5 text-[10px] font-medium opacity-0 transition group-hover:opacity-100"
              style={{
                color: isUser ? 'rgba(255,255,255,0.7)' : undefined,
              }}
            >
              <span className={isUser ? 'text-white/70 hover:text-white' : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}>
                <Copy className="inline h-3 w-3" /> Copy
              </span>
            </button>
          </div>
        )}
      </div>
    </motion.div>
  )
}

// --- Right context panel (AI Assistant info + Team + Actions) — like the ChatVerse AI template ---
type ContextPanelProps = {
  personality: Personality
  conversation: Conversation
  onCopy: () => void
  onShare: () => void
  onFollowUp: () => void
  onClose: () => void
  currentUser: UserInfo | null
  ownerInfo: any
}

function ContextPanel({ personality, conversation, onCopy, onShare, onFollowUp, onClose, currentUser, ownerInfo }: ContextPanelProps) {
  const [teamFilter, setTeamFilter] = useState<'unassigned' | 'mine' | 'all'>('unassigned')
  const messageCount = conversation.messages.length
  const userMessages = conversation.messages.filter((m) => m.role === 'user').length
  const aiMessages = conversation.messages.filter((m) => m.role === 'assistant').length

  return (
    <div className="flex h-full w-80 flex-col">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b border-white/10 px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl">
            <motion.span
              animate={{ opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute inset-0 bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-sm"
            />
            <Image src="/chatverse-logo.png" alt="ChatVerse" width={40} height={40} className="relative z-10 h-10 w-10 rounded-xl object-cover" />
          </div>
          <div>
            <div className="text-sm font-extrabold text-white">{personality.name}</div>
            <div className="text-[10px] text-slate-400">AI Assistant · {personality.tagline}</div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-white/[0.06] hover:text-rose-400"
          title="Close panel"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-4 [scrollbar-width:thin]">
        {/* Contact info card */}
        <div className="mb-4 rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-500/5 via-black/30 to-fuchsia-500/5 p-4 backdrop-blur-xl">
          <div className="mb-3 flex items-center gap-3">
            <div className="relative">
              <Avatar className="h-12 w-12 ring-2 ring-cyan-400/40">
                <AvatarFallback className={`bg-gradient-to-br ${personality.gradient} text-lg`}>
                  {personality.emoji}
                </AvatarFallback>
              </Avatar>
              <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-black bg-cyan-400 shadow-[0_0_6px_rgba(34,211,238,0.7)]" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-bold text-white">{personality.name}</div>
              <div className="flex items-center gap-1 text-[11px] text-cyan-300">
                <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-400" />
                online · ready to chat
              </div>
            </div>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-400">
            {personality.tagline}. Online and ready to help with anything you need — chat, code, images, video, and more.
          </p>
        </div>

        {/* Team section */}
        <div className="mb-4">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            <Users className="h-3 w-3" /> Team
          </div>
          <div className="space-y-1.5">
            {([
              { id: 'unassigned', label: 'Unassigned', count: 0, icon: User },
              { id: 'mine', label: 'Assigned to me', count: currentUser ? 1 : 0, icon: User },
              { id: 'all', label: 'All team members', count: currentUser ? 1 : 0, icon: Users },
            ] as const).map((opt) => (
              <button
                key={opt.id}
                onClick={() => setTeamFilter(opt.id)}
                className={`flex w-full items-center justify-between gap-2 rounded-xl border px-3 py-2 text-xs font-semibold transition ${
                  teamFilter === opt.id
                    ? 'border-cyan-400/40 bg-cyan-500/10 text-cyan-200'
                    : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.06]'
                }`}
              >
                <span className="flex items-center gap-2">
                  <opt.icon className="h-3.5 w-3.5" />
                  {opt.label}
                </span>
                <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-bold ${
                  teamFilter === opt.id ? 'bg-cyan-400/30 text-cyan-100' : 'bg-white/[0.06] text-slate-400'
                }`}>
                  {opt.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Conversation stats */}
        <div className="mb-4">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            <ClipboardList className="h-3 w-3" /> Conversation
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-2">
              <div className="text-base font-bold text-white">{messageCount}</div>
              <div className="text-[9px] uppercase tracking-wider text-slate-500">Messages</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-2">
              <div className="text-base font-bold text-cyan-300">{userMessages}</div>
              <div className="text-[9px] uppercase tracking-wider text-slate-500">From you</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-2">
              <div className="text-base font-bold text-amber-300">{aiMessages}</div>
              <div className="text-[9px] uppercase tracking-wider text-slate-500">From AI</div>
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="mb-4">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            <Zap className="h-3 w-3" /> Quick actions
          </div>
          <div className="space-y-1.5">
            <button
              onClick={onFollowUp}
              className="flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-xs font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/10"
            >
              <PenSquare className="h-3.5 w-3.5 text-cyan-300" />
              Write message
              <ChevronDown className="ml-auto h-3 w-3 -rotate-90 text-slate-500" />
            </button>
            <button
              onClick={onCopy}
              className="flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-xs font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/10"
            >
              <ClipboardList className="h-3.5 w-3.5 text-cyan-300" />
              Log interaction
              <ChevronDown className="ml-auto h-3 w-3 -rotate-90 text-slate-500" />
            </button>
            <button
              onClick={() => toast.success('AI suggestion: Try asking for a summary!')}
              className="flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-xs font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/10"
            >
              <Lightbulb className="h-3.5 w-3.5 text-cyan-300" />
              Suggest interaction
              <ChevronDown className="ml-auto h-3 w-3 -rotate-90 text-slate-500" />
            </button>
            <button
              onClick={onShare}
              className="flex w-full items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-left text-xs font-medium text-slate-200 transition hover:border-cyan-400/30 hover:bg-cyan-500/10"
            >
              <Share2 className="h-3.5 w-3.5 text-cyan-300" />
              Share transcript
              <ChevronDown className="ml-auto h-3 w-3 -rotate-90 text-slate-500" />
            </button>
          </div>
        </div>

        {/* Plan badge */}
        {currentUser && (
          <div className="rounded-2xl border border-amber-400/30 bg-gradient-to-br from-amber-500/10 to-blue-500/10 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Crown className="h-4 w-4 text-amber-300" />
                <span className="text-xs font-bold uppercase tracking-wider text-amber-200">
                  {currentUser.plan === 'owner' ? 'OWNER' : currentUser.plan}
                </span>
              </div>
              <span className="text-[10px] font-bold text-amber-300">
                {currentUser.plan === 'owner' ? '∞ pts' : `${currentUser.points} pts`}
              </span>
            </div>
            <button
              onClick={() => toast.success('Opening premium page…')}
              className="mt-2 w-full rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 px-3 py-1.5 text-[11px] font-bold text-black transition hover:from-amber-300 hover:to-yellow-400"
            >
              {currentUser.plan === 'free' ? 'Upgrade plan' : 'Manage plan'}
            </button>
          </div>
        )}
      </div>

      {/* Footer — Follow up button */}
      <div className="border-t border-white/10 p-3">
        <button
          onClick={onFollowUp}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-cyan-500/30 transition-transform hover:scale-[1.02]"
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            <Zap className="h-4 w-4" /> Follow up
          </span>
          <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
        </button>
      </div>
    </div>
  )
}

// --- Knowledge Base modal (saved notes for the user) ---
function KnowledgeBaseModal({ open, onClose, userName }: { open: boolean; onClose: () => void; userName: string | null }) {
  const [notes, setNotes] = useState<Array<{ id: string; title: string; content: string; createdAt: number }>>([])
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')

  // Load notes from localStorage on mount
  useEffect(() => {
    if (!userName) return
    try {
      const raw = localStorage.getItem(`chatverse:kb:${userName.toLowerCase()}`)
      if (raw) {
        // Defer to avoid cascading render
        Promise.resolve().then(() => setNotes(JSON.parse(raw)))
      }
    } catch {}
  }, [userName])

  // Persist whenever notes change
  useEffect(() => {
    if (!userName) return
    try {
      localStorage.setItem(`chatverse:kb:${userName.toLowerCase()}`, JSON.stringify(notes))
    } catch {}
  }, [notes, userName])

  const addNote = () => {
    const t = title.trim()
    const c = content.trim()
    if (!t || !c) return
    setNotes((prev) => [{ id: Math.random().toString(36).slice(2), title: t, content: c, createdAt: Date.now() }, ...prev])
    setTitle('')
    setContent('')
    toast.success('Note saved to knowledge base!')
  }

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id))
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-[60] grid place-items-center bg-slate-950/85 p-4 backdrop-blur-md"
        >
          <motion.div
            initial={{ scale: 0.95, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 20, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-500 text-white shadow-lg">
                  <BookOpen className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-white">Knowledge Base</h2>
                  <p className="text-[11px] text-slate-400">Save notes, facts, and references for the AI to use</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-white/[0.06] hover:text-rose-400"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Add note form */}
            <div className="border-b border-white/10 p-4">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Note title (e.g., My project requirements)"
                className="mb-2 w-full rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
              />
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Note content — anything you want the AI to remember…"
                rows={3}
                className="mb-2 w-full resize-none rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
              />
              <button
                onClick={addNote}
                disabled={!title.trim() || !content.trim()}
                className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 px-4 py-2 text-sm font-bold text-white shadow-md shadow-cyan-500/30 transition hover:from-cyan-400 hover:to-blue-400 disabled:opacity-40"
              >
                <Plus className="mr-1 inline h-4 w-4" /> Save note
              </button>
            </div>

            {/* Notes list */}
            <div className="flex-1 overflow-y-auto p-4 [scrollbar-width:thin]">
              {notes.length === 0 ? (
                <div className="py-10 text-center">
                  <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-cyan-300">
                    <BookOpen className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium text-slate-300">No notes yet</p>
                  <p className="mt-1 text-xs text-slate-500">Save facts, reminders, or context you want the AI to remember.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {notes.map((n) => (
                    <motion.div
                      key={n.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="group rounded-2xl border border-white/10 bg-white/[0.03] p-3 transition hover:border-cyan-400/20"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-sm font-bold text-white">{n.title}</h3>
                        <button
                          onClick={() => deleteNote(n.id)}
                          className="shrink-0 rounded-md p-1 text-slate-500 opacity-0 transition hover:text-rose-400 group-hover:opacity-100"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <p className="mt-1 text-xs leading-relaxed text-slate-300">{n.content}</p>
                      <div className="mt-2 text-[10px] uppercase tracking-wider text-slate-500">
                        {new Date(n.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="border-t border-white/10 p-3 text-center">
              <p className="text-[11px] text-slate-500">
                💡 Tip: Notes are saved locally on this device, scoped to your account ({userName || 'guest'}).
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

// --- Empty state (no conversations) ---
// --- Empty state (no conversations) — with clickable feature cards that trigger real actions ---
const EMPTY_FEATURES: Array<{ name: string; icon: any; color: string; desc: string; prompt: string }> = [
  { name: 'AI Chat', icon: MessageSquare, color: 'from-blue-500 to-cyan-500', desc: 'Real-time conversations', prompt: "Hi! What can you help me with today?" },
  { name: 'Image Generator', icon: ImageIcon, color: 'from-amber-400 to-yellow-500', desc: 'Create AI art', prompt: "Create a beautiful futuristic city skyline at sunset with neon lights, ultra detailed, 8K quality" },
  { name: 'Weather Center', icon: Cloud, color: 'from-cyan-400 to-blue-500', desc: 'Live forecasts', prompt: "What's the weather like in my location right now?" },
  { name: 'News Center', icon: Newspaper, color: 'from-amber-500 to-orange-500', desc: 'Breaking headlines', prompt: "Show me the latest news headlines from my country" },
  { name: 'Voice Assistant', icon: Bot, color: 'from-purple-500 to-pink-500', desc: 'Talk to AI', prompt: "I want to start a voice call with you. CALL_OFFER:video" },
  { name: 'Document Analyzer', icon: FileText, color: 'from-emerald-400 to-teal-500', desc: 'PDF + web analysis', prompt: "I have a document to analyze — what can you extract from text, PDFs, or web pages?" },
  { name: 'Code Generator', icon: Code, color: 'from-indigo-500 to-purple-500', desc: 'Build with code', prompt: "Write me a Python function that checks if a number is prime, with example usage" },
]

function EmptyState({
  onNewChat,
  onPickPersonality,
  onTriggerFeature,
}: {
  onNewChat: () => void
  onPickPersonality: (p: PersonalityId) => void
  onTriggerFeature: (prompt: string) => void
}) {
  return (
    <div className="flex flex-1 flex-col items-center justify-start overflow-y-auto p-4 text-center sm:p-6 [scrollbar-width:thin]">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, type: 'spring', stiffness: 200 }}
        whileHover={{ scale: 1.05, rotate: 4 }}
        className="relative mb-5 grid h-20 w-20 place-items-center overflow-hidden rounded-3xl shadow-2xl shadow-cyan-500/30 sm:h-24 sm:w-24"
      >
        <motion.span
          animate={{ opacity: [0.4, 0.8, 0.4] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute inset-0 bg-gradient-to-br from-cyan-400/40 via-fuchsia-500/30 to-amber-400/30 blur-md"
        />
        <Image
          src="/chatverse-logo.png"
          alt="ChatVerse AI"
          width={96}
          height={96}
          className="relative z-10 h-20 w-20 rounded-3xl object-cover sm:h-24 sm:w-24"
          priority
        />
      </motion.div>
      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-2xl font-extrabold sm:text-4xl text-gradient"
      >
        Welcome to ChatVerse
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-2 max-w-md text-sm text-slate-400 sm:text-base"
      >
        Your AI assistant — chat, create images, generate videos, check weather, get news, and more.
      </motion.p>

      {/* Feature cards grid — clicking any card creates a chat and triggers the action */}
      <div className="mt-6 grid w-full max-w-3xl grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {EMPTY_FEATURES.map((f, i) => (
          <motion.button
            key={f.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.05 }}
            whileHover={{ y: -6, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onTriggerFeature(f.prompt)}
            className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left backdrop-blur-xl transition-colors hover:border-cyan-400/30"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-amber-500/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <div className={`mb-2.5 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${f.color} text-white shadow-lg transition-transform duration-300 group-hover:scale-110`}>
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white">{f.name}</h3>
            <p className="mt-0.5 text-[11px] leading-snug text-slate-400">{f.desc}</p>
            <div className="mt-2.5 flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-cyan-300 opacity-0 transition-opacity group-hover:opacity-100">
              Open <ChevronDown className="h-3 w-3 -rotate-90" />
            </div>
          </motion.button>
        ))}
      </div>

      {/* Start chatting CTA */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="mt-6"
      >
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onPickPersonality('general')}
          className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 px-8 py-3 text-base font-bold text-white shadow-lg shadow-cyan-500/30"
        >
          <Sparkles className="h-5 w-5" />
          Start chatting
        </motion.button>
      </motion.div>
    </div>
  )
}

// --- Format an event's date + time into a human-readable string ---
// e.g. "Fri, Oct 30 at 6:30 PM" or "Mon, Nov 2 at 9:00 AM" or "Today at 3:00 PM"
function formatEventDate(date: string, time: string): string {
  try {
    const d = new Date(`${date}T${time || '00:00'}`)
    if (isNaN(d.getTime())) return date
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const eventDay = new Date(d.getFullYear(), d.getMonth(), d.getDate())
    const diffDays = Math.round((eventDay.getTime() - today.getTime()) / (24 * 60 * 60 * 1000))
    let dayPart: string
    if (diffDays === 0) dayPart = 'Today'
    else if (diffDays === 1) dayPart = 'Tomorrow'
    else if (diffDays > 1 && diffDays < 7) dayPart = d.toLocaleDateString([], { weekday: 'short' })
    else dayPart = d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })
    const timePart = time ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''
    return timePart ? `${dayPart} at ${timePart}` : dayPart
  } catch {
    return date
  }
}

// --- Floating particles (subtle gold + cyan) for the premium background ---
function FloatingParticles() {
  // Generate particles only on the client (after mount) to avoid hydration mismatch from Math.random()
  const [particles, setParticles] = useState<Array<{ id: number; left: number; top: number; size: number; delay: number; duration: number; gold: boolean }>>([])
  useEffect(() => {
    Promise.resolve().then(() => setParticles(
      Array.from({ length: 18 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 3 + 1.2,
        delay: Math.random() * 6,
        duration: Math.random() * 8 + 6,
        gold: Math.random() > 0.5,
      }))
    ))
  }, [])
  if (particles.length === 0) return null
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            background: p.gold
              ? 'radial-gradient(circle, rgba(251,191,36,0.85), rgba(251,191,36,0))'
              : 'radial-gradient(circle, rgba(56,189,248,0.85), rgba(56,189,248,0))',
            boxShadow: p.gold ? '0 0 8px rgba(251,191,36,0.6)' : '0 0 8px rgba(56,189,248,0.6)',
          }}
          animate={{ y: [0, -25, 0], x: [0, 10, 0], opacity: [0.15, 0.7, 0.15] }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
    </div>
  )
}

// --- Permanent weather + news widget (always visible in sidebar) ---
type WeatherData = {
  ok: boolean; city?: string; temperature?: number; feelsLike?: number;
  humidity?: number; windSpeed?: number; description?: string; emoji?: string;
  daily?: Array<{ date: string; max: number; min: number; desc: string; emoji: string }>;
  error?: string;
}
type NewsItem = { title: string; description: string; link: string; pubDate: string; source?: string }

function PermanentWeatherNews() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [news, setNews] = useState<NewsItem[]>([])
  // Defaults: Dubai, UAE (matches Asia/Dubai timezone the app is configured for)
  const [city, setCity] = useState('Dubai')
  const [countryCode, setCountryCode] = useState('AE')
  const [countryName, setCountryName] = useState('United Arab Emirates')
  const [locationStatus, setLocationStatus] = useState<'detecting' | 'detected' | 'denied'>('detecting')
  const [cityInput, setCityInput] = useState('')
  const [editingCity, setEditingCity] = useState(false)
  const [tab, setTab] = useState<'weather' | 'news'>('weather')
  // 'my-country' = Google News RSS for the user's detected country code
  // Other categories use BBC feeds
  const [newsCategory, setNewsCategory] = useState('my-country')
  // Collapsed by default so it doesn't hide the chats list. User expands by clicking.
  const [expanded, setExpanded] = useState(false)

  // --- Auto-detect user's location using browser geolocation + reverse geocode ---
  useEffect(() => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      // Defer to avoid cascading render
      Promise.resolve().then(() => setLocationStatus('denied'))
      return
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords
          // Free reverse-geocode (no API key needed) — BigDataCloud
          const res = await fetch(
            `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
          )
          const data = await res.json()
          const detectedCity = data.city || data.locality || data.principalSubdivision || 'Dubai'
          const detectedCountry = data.countryName || 'United Arab Emirates'
          const detectedCode = (data.countryCode || 'AE').toUpperCase()
          setCity(detectedCity)
          setCountryCode(detectedCode)
          setCountryName(detectedCountry)
          setLocationStatus('detected')
        } catch (e) {
          // Reverse geocode failed — keep defaults (Dubai, UAE)
          setLocationStatus('denied')
        }
      },
      () => {
        // User denied or geolocation failed — keep defaults (Dubai, UAE)
        setLocationStatus('denied')
      },
      { timeout: 10000, enableHighAccuracy: false, maximumAge: 600000 }
    )
  }, [])

  // Load weather (whenever city changes — either by detection or manual entry)
  useEffect(() => {
    let cancelled = false
    fetch(`/api/weather?city=${encodeURIComponent(city)}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled) setWeather(d) })
      .catch(() => { if (!cancelled) setWeather({ ok: false, error: 'Failed to load' }) })
    return () => { cancelled = true }
  }, [city])

  // Load news (when category OR country code changes)
  useEffect(() => {
    let cancelled = false
    const url = newsCategory === 'my-country'
      ? `/api/news?category=country&q=${encodeURIComponent(countryCode)}`
      : `/api/news?category=${newsCategory}`
    fetch(url)
      .then((r) => r.json())
      .then((d) => { if (!cancelled && d?.news) setNews(d.news) })
      .catch(() => { if (!cancelled) setNews([]) })
    return () => { cancelled = true }
  }, [newsCategory, countryCode])

  const submitCity = () => {
    const c = cityInput.trim()
    if (c) {
      setCity(c)
      setEditingCity(false)
      setCityInput('')
    }
  }

  return (
    <div className="mx-3 mb-3 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-blue-500/5 via-black/30 to-amber-500/5 backdrop-blur-xl">
      {/* ====================== COLLAPSED (default) — compact single-row bar ====================== */}
      {!expanded && (
        <button
          onClick={() => setExpanded(true)}
          className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left transition hover:bg-white/[0.04]"
          title="Expand weather + news"
        >
          <div className="flex min-w-0 items-center gap-2">
            {/* Weather summary */}
            <span className="text-xl leading-none">{weather?.emoji || '⏳'}</span>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                <span className="truncate">{weather?.city || city}</span>
                <span className="text-cyan-300">
                  {weather?.ok ? `${weather.temperature}°C` : '—'}
                </span>
                {locationStatus === 'detected' && (
                  <span className="inline-flex items-center rounded-full bg-emerald-500/15 px-1 py-0.5 text-[8px] font-bold uppercase text-emerald-300" title="Auto-detected from your GPS location">
                    GPS
                  </span>
                )}
              </div>
              <div className="truncate text-[10px] text-slate-500">
                {weather?.ok
                  ? `${weather.description} · 💧${weather.humidity}% · 💨${weather.windSpeed}km/h`
                  : 'Tap to expand weather + news'}
              </div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5 text-[10px]">
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-1.5 py-0.5 font-bold uppercase tracking-wider text-amber-300">
              <Newspaper className="h-2.5 w-2.5" /> News
            </span>
            <ChevronDown className="h-3 w-3 text-slate-400 transition-transform" />
          </div>
        </button>
      )}

      {/* ====================== EXPANDED — full widget with Weather/News tabs ====================== */}
      {expanded && (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            {/* Top row: collapse button */}
            <div className="flex items-center justify-between border-b border-white/10 px-3 py-1.5">
              <button
                onClick={() => setExpanded(false)}
                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 hover:text-cyan-300"
                title="Collapse"
              >
                <ChevronDown className="h-3 w-3 rotate-180" />
                Collapse
              </button>
              <span className="text-[10px] font-semibold text-slate-500">
                {locationStatus === 'detecting' ? 'Locating…' : locationStatus === 'detected' ? `${countryName} · GPS` : `${countryName}`}
              </span>
            </div>

            {/* Tab toggle */}
            <div className="flex border-b border-white/10">
              <button
                onClick={() => setTab('weather')}
                className={`flex flex-1 items-center justify-center gap-1.5 py-2 text-[11px] font-bold uppercase tracking-wider transition ${
                  tab === 'weather' ? 'bg-cyan-500/10 text-cyan-300' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Cloud className="h-3.5 w-3.5" /> Weather
              </button>
              <button
                onClick={() => setTab('news')}
                className={`flex flex-1 items-center justify-center gap-1.5 py-2 text-[11px] font-bold uppercase tracking-wider transition ${
                  tab === 'news' ? 'bg-amber-500/10 text-amber-300' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Newspaper className="h-3.5 w-3.5" /> News
              </button>
            </div>

            {/* Weather tab */}
            {tab === 'weather' && (
              <div className="p-3">
                {/* City header (click to change) + location detection indicator */}
                <div className="mb-2 flex items-center justify-between gap-2">
                  {editingCity ? (
                    <input
                      type="text"
                      autoFocus
                      value={cityInput}
                      onChange={(e) => setCityInput(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') submitCity() }}
                      placeholder="Enter city..."
                      className="w-full rounded-md border border-cyan-400/40 bg-black/40 px-2 py-1 text-xs text-white outline-none placeholder:text-slate-500"
                    />
                  ) : (
                    <button
                      onClick={() => { setEditingCity(true); setCityInput(city) }}
                      className="flex items-center gap-1 text-xs font-semibold text-slate-300 hover:text-cyan-300"
                      title="Click to change city"
                    >
                      <MapPin className="h-3 w-3" />
                      <span className="truncate">{weather?.city || city}</span>
                      {locationStatus === 'detecting' && (
                        <span className="ml-1 inline-flex items-center gap-1 rounded-full bg-cyan-500/15 px-1.5 py-0.5 text-[8px] font-bold uppercase text-cyan-300">
                          <span className="inline-block h-1 w-1 animate-pulse rounded-full bg-cyan-400" />
                          Locating
                        </span>
                      )}
                      {locationStatus === 'detected' && (
                        <span className="ml-1 inline-flex items-center gap-0.5 rounded-full bg-emerald-500/15 px-1.5 py-0.5 text-[8px] font-bold uppercase text-emerald-300" title="Auto-detected from your GPS location">
                          GPS
                        </span>
                      )}
                      <ChevronDown className="h-3 w-3 opacity-50" />
                    </button>
                  )}
                  <button
                    onClick={() => setTab('news')}
                    className="shrink-0 text-[10px] text-slate-500 hover:text-amber-300"
                  >
                    News →
                  </button>
                </div>

                {weather === null ? (
                  <div className="space-y-2 py-2">
                    <div className="skeleton h-10 w-32 rounded-lg" />
                    <div className="skeleton h-2.5 w-40 rounded-full" />
                  </div>
                ) : weather.ok ? (
                  <>
                    <div className="flex items-center gap-3">
                      <span className="text-4xl">{weather.emoji}</span>
                      <div>
                        <div className="text-3xl font-black tracking-tight text-white">
                          {weather.temperature}°<span className="text-base text-slate-400">C</span>
                        </div>
                        <div className="text-xs text-slate-300">{weather.description}</div>
                      </div>
                    </div>
                    <div className="mt-3 grid grid-cols-3 gap-1.5 text-center">
                      <div className="rounded-lg border border-white/5 bg-white/[0.03] px-1 py-1.5">
                        <Droplets className="mx-auto mb-0.5 h-3 w-3 text-cyan-300" />
                        <div className="text-[11px] font-bold text-white">{weather.humidity}%</div>
                        <div className="text-[8px] uppercase tracking-wider text-slate-500">Humidity</div>
                      </div>
                      <div className="rounded-lg border border-white/5 bg-white/[0.03] px-1 py-1.5">
                        <Wind className="mx-auto mb-0.5 h-3 w-3 text-cyan-300" />
                        <div className="text-[11px] font-bold text-white">{weather.windSpeed}</div>
                        <div className="text-[8px] uppercase tracking-wider text-slate-500">km/h</div>
                      </div>
                      <div className="rounded-lg border border-white/5 bg-white/[0.03] px-1 py-1.5">
                        <Thermometer className="mx-auto mb-0.5 h-3 w-3 text-amber-300" />
                        <div className="text-[11px] font-bold text-white">{weather.feelsLike}°</div>
                        <div className="text-[8px] uppercase tracking-wider text-slate-500">Feels</div>
                      </div>
                    </div>
                    {weather.daily && weather.daily.length > 0 && (
                      <div className="mt-2 grid grid-cols-3 gap-1">
                        {weather.daily.slice(0, 3).map((d, i) => (
                          <div key={i} className="rounded-md border border-white/5 bg-white/[0.02] px-1 py-1 text-center">
                            <div className="text-[8px] font-semibold text-slate-400">
                              {i === 0 ? 'Today' : i === 1 ? 'Tom' : '+2'}
                            </div>
                            <div className="text-base">{d.emoji}</div>
                            <div className="text-[9px] text-white">{d.max}° <span className="text-slate-500">{d.min}°</span></div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <p className="py-2 text-xs text-rose-300">{weather.error || 'Failed to load weather.'}</p>
                )}
              </div>
            )}

            {/* News tab */}
            {tab === 'news' && (
              <div className="p-3">
                {/* Category chips — "My Country" is first and default */}
                <div className="mb-2 flex flex-wrap gap-1">
                  <button
                    onClick={() => setNewsCategory('my-country')}
                    className={`rounded-full px-2 py-0.5 text-[9px] font-semibold transition ${
                      newsCategory === 'my-country'
                        ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black'
                        : 'border border-white/10 bg-white/[0.04] text-slate-400 hover:text-slate-200'
                    }`}
                    title={`News from your country (${countryName})`}
                  >
                    🌍 My Country ({countryCode})
                  </button>
                  {['general', 'technology', 'business', 'science', 'health'].map((c) => (
                    <button
                      key={c}
                      onClick={() => setNewsCategory(c)}
                      className={`rounded-full px-2 py-0.5 text-[9px] font-semibold capitalize transition ${
                        newsCategory === c
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black'
                          : 'border border-white/10 bg-white/[0.04] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
                {news.length === 0 ? (
                  <div className="space-y-2 py-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i}>
                        <div className="skeleton h-2.5 w-3/4 rounded-full" />
                        <div className="skeleton mt-1 h-2 w-1/2 rounded-full" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="max-h-[280px] space-y-1.5 overflow-y-auto pr-1 [scrollbar-width:thin]">
                    {news.slice(0, 6).map((n, i) => (
                      <a
                        key={i}
                        href={n.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block rounded-lg border border-white/5 bg-white/[0.02] p-2 transition hover:border-amber-400/30 hover:bg-white/[0.05]"
                      >
                        <div className="flex items-start gap-1.5">
                          <span className="grid h-4 w-4 shrink-0 place-items-center rounded text-[9px] font-bold text-amber-300">
                            {i + 1}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="text-[11px] font-semibold leading-snug text-slate-100 line-clamp-2">{n.title}</div>
                            <div className="mt-0.5 text-[8px] uppercase tracking-wider text-slate-500">
                              {new Date(n.pubDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                              {n.source ? ` · ${n.source}` : (newsCategory === 'my-country' ? ' · Google News' : ' · BBC')}
                            </div>
                          </div>
                        </div>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  )
}

// --- Top status bar: live counter + announcements + owner badge ---
function TopStatusBar({
  onlineCount,
  announcements,
  events,
  isOwner,
  ownerInfo,
  onOpenAnnouncementModal,
  onOpenOwnerPanel,
  onSignOutOwner,
  onDeleteEvent,
}: {
  onlineCount: number
  announcements: Announcement[]
  events: Array<{ id: string; title: string; description: string; date: string; time: string; authorName: string; authorRole: string; createdAt: number }>
  isOwner: boolean
  ownerInfo: { name: string; role: string; badge: string; gradient: string; icon: 'crown' | 'shield' } | null
  onOpenAnnouncementModal: () => void
  onOpenOwnerPanel: () => void
  onSignOutOwner: () => void
  onDeleteEvent: (id: string) => void
}) {
  const latest = announcements[0]
  // Show up to 2 upcoming events (filter out past ones, sort by date asc)
  const upcomingEvents = events
    .filter((e) => {
      const eventDate = new Date(`${e.date}T${e.time || '00:00'}`).getTime()
      // Include events up to 24 hours after their start time
      return eventDate + 24 * 60 * 60 * 1000 > Date.now()
    })
    .sort((a, b) => {
      const aDate = new Date(`${a.date}T${a.time || '00:00'}`).getTime()
      const bDate = new Date(`${b.date}T${b.time || '00:00'}`).getTime()
      return aDate - bDate
    })
    .slice(0, 2)
  return (
    <div className="relative z-30 border-b border-white/10 bg-black/40 backdrop-blur-2xl" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
      {/* Live user counter pill (always visible) */}
      <div className="flex items-center justify-between gap-3 px-3 py-1.5 sm:px-4">
        <div className="flex items-center gap-2">
          {/* Online counter — ONLY visible to owners */}
          {isOwner && (
            <>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100/80 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
                <motion.span
                  animate={{ scale: [1, 1.3, 1], opacity: [1, 0.6, 1] }}
                  transition={{ duration: 1.6, repeat: Infinity }}
                  className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500"
                />
                {onlineCount} {onlineCount === 1 ? 'person' : 'people'} online
              </span>
              <span className="hidden text-[11px] text-slate-500 dark:text-slate-400 sm:inline">
                using ChatVerse right now
              </span>
            </>
          )}
          {/* Non-owners see nothing here */}
        </div>

        <div className="flex items-center gap-2">
          {isOwner && ownerInfo ? (
            <motion.button
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={onOpenOwnerPanel}
              className={`inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r ${ownerInfo.gradient} px-2.5 py-1 text-[11px] font-bold text-white shadow-sm`}
              title="Open owner panel"
            >
              {ownerInfo.icon === 'crown' ? <Crown className="h-3 w-3" /> : <Shield className="h-3 w-3" />}
              {ownerInfo.badge}
            </motion.button>
          ) : null}
        </div>
      </div>

      {/* Banners removed — announcements & events only show in the notification bell modal */}
    </div>
  )
}

// --- AnimatedMan: SVG character that animates based on the call state ---
// States: idle (gentle breathing + blink), listening (looking around), thinking (looking up),
//         transcribing (slight head nod), speaking (mouth open/close synced to speech),
//         error (concerned look)
//
// The character is a stylized friendly man with:
// - Breathing (subtle vertical motion of head + shoulders)
// - Blinking eyes (every ~3 seconds, faster when listening)
// - Mouth that opens/closes when speaking
// - Head bob and slight look-around when listening
// - Eyebrow raise when thinking
// - Personality-themed shirt color (uses the gradient's first color via a CSS variable hack)
function AnimatedMan({
  state,
  gradient,
  className = '',
}: {
  state: 'idle' | 'listening' | 'transcribing' | 'thinking' | 'speaking' | 'error'
  gradient: string
  className?: string
}) {
  // Detect if listening state needs faster blink
  const isSpeaking = state === 'speaking'
  const isListening = state === 'listening'
  const isThinking = state === 'thinking'
  const isError = state === 'error'

  // Breathing animation: vertical motion of head + body
  // Speaking: mouth y scale 1 → 1.8 → 1 cycle (open/close)
  // Listening: head slight rotation -2° → 2° → -2°
  // Thinking: head tilt up slightly + eyebrow raise
  return (
    <motion.svg
      viewBox="0 0 240 280"
      className={className}
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <defs>
        <linearGradient id="skinGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#fde4cf" />
          <stop offset="100%" stopColor="#f5c9a6" />
        </linearGradient>
        <linearGradient id="shirtGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="rgba(255,255,255,0.95)" />
          <stop offset="100%" stopColor="rgba(255,255,255,0.75)" />
        </linearGradient>
        <linearGradient id="hairGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3a2a1f" />
          <stop offset="100%" stopColor="#1f1510" />
        </linearGradient>
        <radialGradient id="cheekGrad" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="rgba(255,150,150,0.5)" />
          <stop offset="100%" stopColor="rgba(255,150,150,0)" />
        </radialGradient>
        <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#000" floodOpacity="0.18" />
        </filter>
      </defs>

      {/* Shadow under the character */}
      <ellipse cx="120" cy="262" rx="50" ry="6" fill="#000" opacity="0.12" />

      {/* Whole character group with breathing animation */}
      <motion.g
        animate={{ y: [0, -2, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        style={{ transformOrigin: '120px 200px' }}
      >
        {/* Shoulders + body (shirt) */}
        <motion.g
          animate={{ y: [0, -1.5, 0] }}
          transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          {/* Body / shoulders */}
          <path
            d="M60 220 Q60 195 90 188 L150 188 Q180 195 180 220 L180 280 L60 280 Z"
            fill="url(#shirtGrad)"
            filter="url(#softShadow)"
          />
          {/* Collar */}
          <path d="M100 188 Q120 200 140 188 L140 200 Q120 212 100 200 Z" fill="rgba(255,255,255,0.5)" />
        </motion.g>

        {/* Neck */}
        <rect x="108" y="170" width="24" height="22" rx="6" fill="url(#skinGrad)" />

        {/* Head group with state-based animation */}
        <motion.g
          animate={
            isListening
              ? { rotate: [-3, 3, -3], y: [0, -1, 0] }
              : isThinking
              ? { rotate: [-5, -5], y: [-3, -3] }
              : isError
              ? { rotate: [0, -3, 0] }
              : { rotate: 0, y: 0 }
          }
          transition={
            isListening
              ? { duration: 2.5, repeat: Infinity, ease: 'easeInOut' }
              : { duration: 0.4 }
          }
          style={{ transformOrigin: '120px 130px' }}
        >
          {/* Hair back */}
          <path
            d="M70 100 Q70 60 120 55 Q170 60 170 100 L170 130 Q170 95 150 90 Q120 90 90 90 Q70 95 70 130 Z"
            fill="url(#hairGrad)"
          />

          {/* Head */}
          <ellipse cx="120" cy="125" rx="42" ry="48" fill="url(#skinGrad)" filter="url(#softShadow)" />

          {/* Hair front */}
          <path
            d="M82 92 Q100 78 120 80 Q140 78 158 92 Q160 105 152 100 Q140 92 120 92 Q100 92 88 100 Q80 105 82 92 Z"
            fill="url(#hairGrad)"
          />

          {/* Ears */}
          <ellipse cx="78" cy="125" rx="5" ry="9" fill="url(#skinGrad)" />
          <ellipse cx="162" cy="125" rx="5" ry="9" fill="url(#skinGrad)" />

          {/* Cheeks (subtle blush) */}
          <circle cx="95" cy="135" r="9" fill="url(#cheekGrad)" />
          <circle cx="145" cy="135" r="9" fill="url(#cheekGrad)" />

          {/* Eyebrows */}
          <motion.g
            animate={isThinking ? { y: -4 } : { y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <path d="M92 113 Q102 110 112 113" stroke="#2a1a10" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M128 113 Q138 110 148 113" stroke="#2a1a10" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </motion.g>

          {/* Eyes (blink) */}
          <motion.g
            animate={{
              scaleY: isListening ? [1, 0.1, 1, 1, 0.1, 1] : [1, 1, 1, 0.1, 1],
            }}
            transition={
              isListening
                ? { duration: 4, repeat: Infinity, times: [0, 0.1, 0.2, 0.6, 0.7, 1] }
                : { duration: 4, repeat: Infinity, times: [0, 0.5, 0.9, 0.95, 1] }
            }
            style={{ transformOrigin: '120px 122px' }}
          >
            {/* Eye whites */}
            <ellipse cx="102" cy="122" rx="6" ry="7" fill="white" />
            <ellipse cx="138" cy="122" rx="6" ry="7" fill="white" />
            {/* Iris (looking direction depends on state) */}
            <motion.g
              animate={
                isListening
                  ? { x: [-1, 2, -1, -2, -1] }
                  : isThinking
                  ? { x: 0, y: -2 }
                  : { x: 0, y: 0 }
              }
              transition={
                isListening
                  ? { duration: 2.5, repeat: Infinity, ease: 'easeInOut' }
                  : { duration: 0.4 }
              }
            >
              <circle cx="102" cy="122" r="3" fill="#2a1a10" />
              <circle cx="138" cy="122" r="3" fill="#2a1a10" />
              {/* Eye highlights */}
              <circle cx="103" cy="121" r="1" fill="white" />
              <circle cx="139" cy="121" r="1" fill="white" />
            </motion.g>
          </motion.g>

          {/* Nose */}
          <path d="M118 130 L122 142 L116 144" stroke="#d4a07c" strokeWidth="1.5" strokeLinecap="round" fill="none" />

          {/* Mouth — animated based on speaking state */}
          <motion.g
            animate={
              isSpeaking
                ? { scaleY: [1, 2.2, 1, 1.8, 1], y: [0, -1, 0, -0.5, 0] }
                : isError
                ? { scaleY: 0.6, y: 2 }
                : { scaleY: 1, y: 0 }
            }
            transition={
              isSpeaking
                ? { duration: 0.6, repeat: Infinity, ease: 'easeInOut' }
                : { duration: 0.3 }
            }
            style={{ transformOrigin: '120px 152px' }}
          >
            {isSpeaking ? (
              // Open mouth (oval) when speaking
              <ellipse cx="120" cy="153" rx="9" ry="6" fill="#7a2020" />
            ) : isError ? (
              // Worried frown
              <path d="M108 156 Q120 148 132 156" stroke="#7a2020" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            ) : (
              // Friendly smile
              <path d="M108 150 Q120 158 132 150" stroke="#7a2020" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            )}
          </motion.g>
        </motion.g>
      </motion.g>
    </motion.svg>
  )
}

// --- GoogleAvatar: Google-style colored circular avatar with the user's initial ---
// Generates a stable gradient color from the user's name (so the same person always gets the same color).
function GoogleAvatar({ name, size = 36 }: { name: string; size?: number }) {
  // Pick a gradient from a set of Google-styled palettes based on the name's hash
  const palettes = [
    'from-orange-400 to-amber-500',     // orange (like Mohammed Zayyan #1 in the screenshot)
    'from-rose-400 to-pink-500',        // pink/rose
    'from-teal-500 to-cyan-500',   // purple (like Mohammed Zayyan .P in the screenshot)
    'from-emerald-400 to-teal-500',     // green
    'from-sky-400 to-blue-500',         // blue
    'from-amber-400 to-orange-500',     // amber
  ]
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = (hash << 5) - hash + name.charCodeAt(i)
    hash |= 0 // convert to 32-bit int
  }
  const palette = palettes[Math.abs(hash) % palettes.length]
  const initial = name.trim().charAt(0).toUpperCase() || '?'
  return (
    <div
      className={`grid shrink-0 place-items-center rounded-full bg-gradient-to-br ${palette} font-bold text-white shadow-sm`}
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initial}
    </div>
  )
}

// --- SmartMarkdown: renders markdown but detects HTML code blocks and renders them as playable games ---
function SmartMarkdown({ content, onCopy }: { content: string; onCopy: () => void }) {
  // Check if the content contains an HTML code block
  const htmlGameMatch = content.match(/```html\n([\s\S]*?)```/i)
  
  if (htmlGameMatch) {
    const htmlCode = htmlGameMatch[1].trim()
    const beforeGame = content.substring(0, content.indexOf('```html')).trim()
    const afterGame = content.substring(content.indexOf('```html') + htmlGameMatch[0].length).trim()
    
    return (
      <>
        {beforeGame && (
          <div className="mb-3">
            <ReactMarkdown>{beforeGame}</ReactMarkdown>
          </div>
        )}
        <GameRenderer htmlCode={htmlCode} onCopy={onCopy} />
        {afterGame && (
          <div className="mt-3">
            <ReactMarkdown>{afterGame}</ReactMarkdown>
          </div>
        )}
      </>
    )
  }
  
  // No HTML game detected — render as normal markdown
  return <ReactMarkdown>{content}</ReactMarkdown>
}

// --- GameRenderer: renders HTML code as a playable game in an iframe + copy code button ---
function GameRenderer({ htmlCode, onCopy }: { htmlCode: string; onCopy: () => void }) {
  const [showCode, setShowCode] = useState(false)
  const [copied, setCopied] = useState(false)
  
  const copyGameCode = () => {
    navigator.clipboard.writeText(htmlCode).then(() => {
      setCopied(true)
      toast.success('Game code copied!')
      setTimeout(() => setCopied(false), 2000)
    })
  }
  
  return (
    <div className="my-2 overflow-hidden rounded-2xl border border-teal-200/60 bg-white shadow-lg dark:border-teal-800/60 dark:bg-slate-900">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-teal-100 bg-gradient-to-r from-teal-50 to-amber-50 px-3 py-2 dark:border-teal-800/60 dark:from-teal-900/30 dark:to-amber-900/30">
        <div className="flex items-center gap-2">
          <div className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-teal-500 to-amber-500 text-white shadow-sm">
            <Sparkles className="h-4 w-4" />
          </div>
          <span className="text-xs font-bold text-teal-800 dark:text-teal-200">Playable Game</span>
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={copyGameCode}
            className="flex items-center gap-1 rounded-lg bg-teal-500 px-2.5 py-1 text-[11px] font-bold text-white shadow-sm transition hover:bg-teal-600"
          >
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            {copied ? 'Copied!' : 'Copy Code'}
          </button>
          <button
            onClick={() => setShowCode(!showCode)}
            className="rounded-lg bg-slate-200 px-2.5 py-1 text-[11px] font-bold text-slate-700 transition hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-200 dark:hover:bg-slate-600"
          >
            {showCode ? 'Hide Code' : 'Show Code'}
          </button>
        </div>
      </div>
      
      {/* Game iframe */}
      <div className="relative">
        <iframe
          srcDoc={htmlCode}
          className="h-[400px] w-full border-0"
          title="AI Generated Game"
          sandbox="allow-scripts allow-same-origin"
        />
      </div>
      
      {/* Code view (toggleable) */}
      <AnimatePresence>
        {showCode && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-auto"
          >
            <pre className="max-h-80 overflow-auto bg-slate-900 p-3 text-xs text-slate-200">
              <code>{htmlCode}</code>
            </pre>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// --- SciFiLoadingScreen: futuristic loading animation with progress bar ---
function SciFiLoadingScreen({ label, sublabel }: { label: string; sublabel: string }) {
  const [progress, setProgress] = useState(0)
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 95) return p // hold at 95% until the actual result arrives
        return p + Math.random() * 8 + 2
      })
    }, 600)
    return () => clearInterval(interval)
  }, [])
  const displayProgress = Math.min(Math.round(progress), 95)
  const segments = 20
  const filledSegments = Math.round((displayProgress / 100) * segments)

  return (
    <div className="relative flex flex-col items-center justify-center gap-4 py-8">
      {/* Progress bar capsule */}
      <div className="relative flex h-7 w-full max-w-xs items-center gap-[3px] rounded-full border-2 border-teal-400/40 bg-slate-900/80 p-1 shadow-[0_0_20px_-5px_rgba(45,212,191,0.4)]">
        {Array.from({ length: segments }).map((_, i) => (
          <motion.div
            key={i}
            className={`h-full flex-1 rounded-full transition-all duration-300 ${
              i < filledSegments
                ? 'bg-gradient-to-b from-teal-400 to-cyan-500 shadow-[0_0_8px_rgba(45,212,191,0.6)]'
                : 'bg-slate-700/40'
            }`}
            animate={i < filledSegments ? { opacity: [0.7, 1, 0.7] } : {}}
            transition={{ duration: 1, repeat: i < filledSegments ? Infinity : 0, delay: i * 0.05 }}
          />
        ))}
      </div>

      {/* Loading text */}
      <div className="flex items-center gap-2 text-sm font-mono">
        <span className="font-bold tracking-wider text-teal-400">{label}</span>
        <motion.span
          animate={{ opacity: [1, 0.4, 1] }}
          transition={{ duration: 1.2, repeat: Infinity }}
          className="font-bold text-amber-400"
        >
          {displayProgress}%
        </motion.span>
      </div>
      <p className="text-xs text-slate-400">{sublabel}</p>
    </div>
  )
}
