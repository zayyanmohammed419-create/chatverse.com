"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence, useInView } from "framer-motion";
import {
  Crown, Sparkles, Check, Zap, ShieldCheck, Clock, MessageSquare,
  Image as ImageIcon, Mic, Video, Brain, Code2, FileText, Globe,
  TrendingUp, Coins, Plane, Car, Users, Cloud, Key, Server, Lock,
  Star, ChevronDown, ArrowRight, Gift, Trophy, Flame, Award,
  Rocket, Palette, Gamepad2, Briefcase, FileBadge,
  UserCircle, BadgeCheck, Cpu, Layers, Network, Download,
} from "lucide-react";

/* ============================================================
   AI PREMIUM — premium landing page for ChatVerse
   Pricing in AI Points (no real money).
   Designed to look better than ChatGPT Plus, Gemini Advanced, Claude Pro
   ============================================================ */

/* ----------------------- Floating particles ----------------------- */
function FloatingParticles() {
  // Generate particles only on the client (after mount) to avoid hydration mismatch from Math.random()
  const [particles, setParticles] = useState<Array<{ id: number; left: number; top: number; size: number; delay: number; duration: number; gold: boolean }>>([]);
  useEffect(() => {
    Promise.resolve().then(() => setParticles(
      Array.from({ length: 28 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 4 + 1.5,
        delay: Math.random() * 6,
        duration: Math.random() * 8 + 6,
        gold: Math.random() > 0.5,
      }))
    ));
  }, []);
  if (particles.length === 0) return null;
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            background: p.gold
              ? "radial-gradient(circle, rgba(251,191,36,0.9), rgba(251,191,36,0))"
              : "radial-gradient(circle, rgba(96,165,250,0.9), rgba(96,165,250,0))",
            boxShadow: p.gold
              ? "0 0 10px rgba(251,191,36,0.7)"
              : "0 0 10px rgba(96,165,250,0.7)",
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 12, 0],
            opacity: [0.2, 0.9, 0.2],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}

/* ----------------------- Animated background blobs ----------------------- */
function GradientBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-[#05070d]">
      {/* radial vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(251,191,36,0.08),transparent_55%),radial-gradient(ellipse_at_bottom,rgba(59,130,246,0.10),transparent_55%)]" />
      {/* animated blobs */}
      <motion.div
        className="absolute -top-32 -left-24 h-[480px] w-[480px] rounded-full bg-gradient-to-br from-amber-500/30 via-yellow-500/10 to-transparent blur-[120px]"
        animate={{ x: [0, 60, 0], y: [0, 40, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute top-1/3 -right-24 h-[520px] w-[520px] rounded-full bg-gradient-to-br from-blue-600/30 via-indigo-500/10 to-transparent blur-[120px]"
        animate={{ x: [0, -50, 0], y: [0, 60, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute -bottom-32 left-1/3 h-[420px] w-[420px] rounded-full bg-gradient-to-tr from-amber-400/20 via-pink-500/10 to-blue-500/20 blur-[120px]"
        animate={{ x: [0, 40, 0], y: [0, -30, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* subtle grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />
    </div>
  );
}

/* ----------------------- Animated counter hook ----------------------- */
function useCountUp(target: number, inView: boolean, duration = 1800) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, inView, duration]);
  return value;
}

function formatStat(value: number, suffix: string) {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M${suffix}`;
  if (value >= 1_000) return `${Math.floor(value / 1_000)}K${suffix}`;
  return `${Math.floor(value)}${suffix}`;
}

/* ----------------------- Single stat ----------------------- */
function StatCounter({ value, label, icon: Icon, suffix }: {
  value: number | null; label: string; icon: any; suffix?: string;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const hasValue = value !== null;
  const count = useCountUp(hasValue ? (value as number) : 0, inView && hasValue);
  return (
    <motion.div
      ref={ref}
      whileHover={{ y: -6, scale: 1.02 }}
      className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-7 text-center backdrop-blur-xl"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-blue-500/5 opacity-0 transition-opacity duration-300 hover:opacity-100" />
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-blue-500 text-white shadow-lg shadow-amber-500/20">
        <Icon className="h-7 w-7" />
      </div>
      {hasValue ? (
        <div className="text-4xl font-extrabold tracking-tight text-white">
          {formatStat(count, suffix ?? "")}+
        </div>
      ) : (
        <div className="skeleton mx-auto h-10 w-24 rounded-lg" />
      )}
      <div className="mt-1 text-sm font-medium text-slate-400">{label}</div>
      <div className="mt-1.5 inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider text-emerald-300">
        <span className="inline-block h-1 w-1 animate-pulse rounded-full bg-emerald-400" /> Live
      </div>
    </motion.div>
  );
}

/* ----------------------- Success toast ----------------------- */
function SuccessToast({ show, message, onClose }: {
  show: boolean; message: string; onClose: () => void;
}) {
  useEffect(() => {
    if (show) {
      const t = setTimeout(onClose, 3500);
      return () => clearTimeout(t);
    }
  }, [show, onClose]);
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          className="fixed left-1/2 top-6 z-[100] -translate-x-1/2"
        >
          <div className="flex items-center gap-3 rounded-full border border-emerald-400/40 bg-emerald-500/15 px-5 py-3 text-emerald-200 backdrop-blur-xl shadow-2xl shadow-emerald-500/20">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500 text-white">
              <Check className="h-4 w-4" />
            </div>
            <span className="text-sm font-semibold">{message}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ----------------------- Plan card ----------------------- */
type Plan = {
  id: string;
  name: string;
  tagline: string;
  points: number; // cost in AI points
  icon: any;
  accent: string; // tailwind gradient
  border: string;
  popular?: boolean;
  premium?: boolean;
  features: { label: string; icon: any }[];
};

const PLANS: Plan[] = [
  {
    id: "free",
    name: "Free",
    tagline: "Get started with the basics.",
    points: 0,
    icon: Sparkles,
    accent: "from-slate-500 to-slate-700",
    border: "border-white/10",
    features: [
      { label: "50 messages per day", icon: MessageSquare },
      { label: "Basic AI model", icon: Brain },
      { label: "Standard response speed", icon: Clock },
      { label: "Limited features", icon: Layers },
      { label: "Community support", icon: Users },
    ],
  },
  {
    id: "premium",
    name: "Premium",
    tagline: "The full ChatVerse experience.",
    points: 1000,
    icon: Crown,
    accent: "from-amber-400 via-yellow-400 to-amber-500",
    border: "border-amber-400/50",
    popular: true,
    premium: true,
    features: [
      { label: "Unlimited messages", icon: MessageSquare },
      { label: "Fast response speed", icon: Zap },
      { label: "Image generation", icon: ImageIcon },
      { label: "AI image analysis", icon: Brain },
      { label: "Real-time weather updates", icon: Cloud },
      { label: "Real-time news collection", icon: Globe },
      { label: "Voice chat", icon: Mic },
      { label: "Text-to-speech", icon: Mic },
      { label: "Speech-to-text", icon: Mic },
      { label: "Advanced coding assistant", icon: Code2 },
      { label: "Homework helper", icon: FileText },
      { label: "PDF analysis", icon: FileText },
      { label: "Document summarizer", icon: FileText },
      { label: "Website analysis", icon: Globe },
      { label: "YouTube video summarizer", icon: Video },
      { label: "Memory system", icon: Brain },
      { label: "Custom AI personalities", icon: UserCircle },
      { label: "Premium themes", icon: Palette },
      { label: "Priority servers", icon: Server },
      { label: "Advanced search", icon: Globe },
      { label: "Trend analysis", icon: TrendingUp },
      { label: "Currency conversion", icon: Coins },
      { label: "Stock tracking", icon: TrendingUp },
      { label: "Crypto tracking", icon: Coins },
      { label: "Prayer times", icon: Clock },
      { label: "Travel planner", icon: Plane },
      { label: "Car expert assistant", icon: Car },
      { label: "Unlimited file uploads", icon: Download },
      { label: "Premium support", icon: ShieldCheck },
      { label: "Early access to new features", icon: Rocket },
    ],
  },
  {
    id: "premium-plus",
    name: "Premium Plus",
    tagline: "For power users & teams.",
    points: 2500,
    icon: Trophy,
    accent: "from-blue-400 via-indigo-500 to-purple-500",
    border: "border-blue-400/50",
    premium: true,
    features: [
      { label: "Everything in Premium", icon: Check },
      { label: "GPT-5 level reasoning", icon: Cpu },
      { label: "AI Agents", icon: Network },
      { label: "Video generation", icon: Video },
      { label: "Multi-image generation", icon: ImageIcon },
      { label: "Custom AI training", icon: Brain },
      { label: "Team workspace", icon: Users },
      { label: "API access", icon: Key },
      { label: "Personal AI workspace", icon: Briefcase },
      { label: "Cloud sync", icon: Cloud },
      { label: "Private memory storage", icon: Lock },
    ],
  },
];

function PlanCard({ plan, onBuy, buying, currentPoints, currentPlan }: {
  plan: Plan;
  onBuy: (planId: string) => void;
  buying: string | null;
  currentPoints: number;
  currentPlan: string | null;
}) {
  const isCurrent = currentPlan === plan.id || (plan.id === "premium" && (currentPlan === "premium" || currentPlan === "owner"));
  const canAfford = plan.points === 0 || (typeof currentPoints === "number" && currentPoints >= plan.points);

  return (
    <motion.div
      whileHover={{ y: -10 }}
      transition={{ type: "spring", stiffness: 280, damping: 22 }}
      className={`relative flex flex-col rounded-3xl border ${plan.border} ${
        plan.popular
          ? "bg-gradient-to-b from-amber-500/[0.08] via-transparent to-blue-500/[0.05] shadow-2xl shadow-amber-500/10"
          : "bg-white/[0.02]"
      } p-7 backdrop-blur-xl`}
    >
      {plan.popular && (
        <>
          <motion.div
            className="absolute -top-px left-1/2 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-amber-400 to-transparent"
            animate={{ opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-1 text-[10px] font-extrabold uppercase tracking-widest text-black shadow-lg shadow-amber-500/40">
            Most Popular
          </div>
        </>
      )}
      <div className="mb-5 flex items-center gap-3">
        <div
          className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${plan.accent} text-white shadow-lg`}
        >
          <plan.icon className="h-6 w-6" />
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-white">{plan.name}</h3>
          <p className="text-xs text-slate-400">{plan.tagline}</p>
        </div>
      </div>

      <div className="mb-6 flex items-end gap-1.5">
        <Coins className="mb-1 h-7 w-7 text-amber-400" />
        <span className="text-4xl font-black tracking-tight text-white">
          {plan.points.toLocaleString()}
        </span>
        <span className="mb-1 text-sm text-slate-400">pts</span>
        {plan.points > 0 && (
          <span className="mb-1.5 ml-2 rounded-full bg-blue-500/15 px-2 py-0.5 text-[10px] font-bold text-blue-300">
            one-time
          </span>
        )}
      </div>

      <ul className="mb-7 flex-1 space-y-2.5">
        {plan.features.map((f, i) => (
          <li key={i} className="flex items-start gap-2.5 text-sm text-slate-200">
            <div className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-amber-400/80 to-blue-500/80">
              <Check className="h-3 w-3 text-white" />
            </div>
            <span className="leading-snug">{f.label}</span>
          </li>
        ))}
      </ul>

      <PlanButton
        plan={plan}
        isCurrent={isCurrent}
        canAfford={canAfford}
        buying={buying === plan.id}
        onBuy={onBuy}
      />
    </motion.div>
  );
}

/* ----------------------- Plan button (point-based, with toast) ----------------------- */
function PlanButton({
  plan,
  isCurrent,
  canAfford,
  buying,
  onBuy,
}: {
  plan: Plan;
  isCurrent: boolean;
  canAfford: boolean;
  buying: boolean;
  onBuy: (id: string) => void;
}) {
  if (isCurrent) {
    return (
      <div className="mt-auto rounded-2xl bg-emerald-500/15 px-4 py-3 text-center text-sm font-bold text-emerald-300">
        ✓ Your current plan
      </div>
    );
  }
  if (plan.id === "free") {
    return (
      <a
        href="/"
        className="mt-auto block w-full rounded-2xl border border-white/15 bg-white/[0.05] px-6 py-3 text-center text-sm font-bold text-white transition hover:bg-white/[0.1]"
      >
        Back to Chat
      </a>
    );
  }
  const disabled = buying || !canAfford;
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onBuy(plan.id)}
      className={`group relative w-full overflow-hidden rounded-2xl px-6 py-3 text-sm font-bold transition-all duration-300 ${
        disabled
          ? "border border-white/10 bg-white/[0.03] text-slate-500"
          : plan.popular
          ? "bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black hover:shadow-xl hover:shadow-amber-500/40"
          : "bg-gradient-to-r from-blue-500 to-indigo-500 text-white hover:shadow-xl hover:shadow-blue-500/40"
      }`}
      title={canAfford ? `Buy with ${plan.points} pts` : `You need ${plan.points} pts`}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {buying ? (
          <>
            <motion.span
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="inline-block h-4 w-4 rounded-full border-2 border-current border-t-transparent"
            />
            Processing…
          </>
        ) : canAfford ? (
          <>
            Buy with {plan.points.toLocaleString()} pts
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </>
        ) : (
          <>Need {plan.points.toLocaleString()} pts</>
        )}
      </span>
      {!disabled && (
        <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
      )}
    </button>
  );
}

/* ----------------------- Extra Premium Feature card ----------------------- */
const EXTRA_FEATURES = [
  { name: "AI Avatar Creator", icon: UserCircle, color: "from-amber-400 to-orange-500" },
  { name: "AI Logo Generator", icon: BadgeCheck, color: "from-blue-400 to-cyan-500" },
  { name: "AI Thumbnail Generator", icon: ImageIcon, color: "from-purple-400 to-pink-500" },
  { name: "AI Wallpaper Studio", icon: Palette, color: "from-emerald-400 to-teal-500" },
  { name: "AI Story Generator", icon: FileText, color: "from-rose-400 to-red-500" },
  { name: "AI Game Generator", icon: Gamepad2, color: "from-indigo-400 to-purple-500" },
  { name: "AI Website Builder", icon: Globe, color: "from-cyan-400 to-blue-500" },
  { name: "AI Resume Builder", icon: FileBadge, color: "from-amber-400 to-yellow-500" },
  { name: "AI Business Assistant", icon: Briefcase, color: "from-slate-400 to-slate-600" },
];

/* ----------------------- Achievements ----------------------- */
const ACHIEVEMENTS = [
  { name: "User Levels", icon: TrendingUp, color: "from-amber-400 to-yellow-500" },
  { name: "Daily Streaks", icon: Flame, color: "from-orange-400 to-red-500" },
  { name: "Premium Badges", icon: Award, color: "from-blue-400 to-indigo-500" },
  { name: "XP System", icon: Zap, color: "from-purple-400 to-pink-500" },
  { name: "AI Coins", icon: Coins, color: "from-yellow-400 to-amber-500" },
  { name: "Rewards", icon: Gift, color: "from-emerald-400 to-teal-500" },
];

/* ----------------------- FAQ ----------------------- */
const FAQS = [
  {
    q: "How is ChatVerse Premium different from ChatGPT Plus or Gemini Advanced?",
    a: "ChatVerse Premium combines everything those services offer — image generation, video generation, voice chat, AI agents, real-time news & weather, a memory system, custom personalities, and a full creative studio (avatars, logos, thumbnails, games, websites, resumes) — into one premium experience built by Mohammed Zayyan. You get more features for a lower price, with priority servers and early access to new tools.",
  },
  {
    q: "Can I try Premium before paying?",
    a: "Yes. Every new account starts with a free trial of Premium features so you can experience unlimited messages, image generation, voice chat, and more before you decide to upgrade.",
  },
  {
    q: "What happens to my data when I upgrade to Premium Plus?",
    a: "Premium Plus includes private memory storage and cloud sync. Your conversations, custom AI personalities, and uploaded files are encrypted, synced across devices, and never used to train shared models.",
  },
  {
    q: "Do points expire?",
    a: "No. Points you earn or are gifted never expire. Daily streaks and levels give you bonus AI Coins that you can redeem for premium features, custom themes, or gifted upgrades to friends.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Absolutely. Plans are bought with AI Points (one-time), so there's no recurring charge. If you want to switch plans, you just pay the points difference. Owners can also reset your plan for free.",
  },
  {
    q: "Is there a discount for students?",
    a: "Yes. Students can ask Mohammed Zayyan directly for a free points top-up — ChatVerse is built for students first. Owners can also gift points to anyone for free.",
  },
];

function FaqItem({ q, a, idx }: { q: string; a: string; idx: number }) {
  const [open, setOpen] = useState(idx === 0);
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-xl">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between gap-4 p-5 text-left"
      >
        <span className="text-base font-semibold text-white">{q}</span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.25 }}>
          <ChevronDown className="h-5 w-5 shrink-0 text-amber-400" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <p className="px-5 pb-5 text-sm leading-relaxed text-slate-300">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ----------------------- Testimonials ----------------------- */
const TESTIMONIALS = [
  {
    name: "Aisha K.",
    role: "University Student",
    avatar: "AK",
    text: "ChatVerse Premium replaced 4 apps I was paying for. The homework helper, PDF analysis, and YouTube summarizer alone are worth it. Best AI I've used.",
    rating: 5,
  },
  {
    name: "Daniel R.",
    role: "Indie Game Dev",
    avatar: "DR",
    text: "The AI Game Generator and Code Generator are insane. I shipped two mini-games in a weekend. The video generation is buttery smooth on priority servers.",
    rating: 5,
  },
  {
    name: "Mariam K.",
    role: "Small Business Owner",
    avatar: "MK",
    text: "The AI Business Assistant + Resume Builder + Logo Generator saved me thousands. ChatVerse feels like having a full creative agency in my pocket.",
    rating: 5,
  },
  {
    name: "Yusuf A.",
    role: "Crypto Trader",
    avatar: "YA",
    text: "Real-time news, stock tracking, crypto tracking, trend analysis, currency conversion — all in one chat. The Premium Plus agents even summarize my portfolio every morning.",
    rating: 5,
  },
];

/* ============================================================
   MAIN PAGE
   ============================================================ */
export default function PremiumPage() {
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState("");
  const [loaded, setLoaded] = useState(false);
  // current user (for showing their points balance + current plan)
  const [currentUser, setCurrentUser] = useState<{ name: string; plan: string; points: number } | null>(null);
  const [buying, setBuying] = useState<string | null>(null);
  // Real aggregate stats (fetched from /api/stats — pulled from the actual user store)
  const [platformStats, setPlatformStats] = useState<{
    totalUsers: number; premiumMembers: number; totalPoints: number; online: number;
  } | null>(null);

  // Derived: is the current user on a premium plan? (plus / premium / owner)
  const isPremiumUser = !!(currentUser && (currentUser.plan === 'plus' || currentUser.plan === 'premium' || currentUser.plan === 'owner'));

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 50);
    return () => clearTimeout(t);
  }, []);

  // Load the current user from /api/users (GET) if available
  useEffect(() => {
    const name = typeof window !== "undefined" ? localStorage.getItem("chatverse:userName") : null;
    if (name) {
      fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d?.user) {
            setCurrentUser({ name: d.user.name, plan: d.user.plan, points: d.user.points });
          }
        })
        .catch(() => {});
    }
  }, []);

  // Fetch real platform-wide stats from /api/stats (live, refreshes every 15s)
  useEffect(() => {
    let cancelled = false;
    const load = () => {
      fetch("/api/stats")
        .then((r) => r.json())
        .then((d) => {
          if (cancelled || !d?.ok) return;
          setPlatformStats({
            totalUsers: d.totalUsers ?? 0,
            premiumMembers: d.premiumMembers ?? 0,
            totalPoints: d.totalPoints ?? 0,
            online: d.online ?? 0,
          });
        })
        .catch(() => {});
    };
    load();
    const interval = setInterval(load, 15_000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  const buyPlan = async (planId: string) => {
    if (!currentUser?.name) {
      triggerToast("Please sign in to ChatVerse first.");
      return;
    }
    setBuying(planId);
    try {
      const res = await fetch("/api/premium/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userName: currentUser.name, plan: planId }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        if (data?.error === "INSUFFICIENT_POINTS") {
          triggerToast(`You need ${data.needed} pts but only have ${data.have}. Ask Mohammed Zayyan to gift you points.`);
        } else {
          triggerToast(data?.error || "Failed to buy plan.");
        }
        return;
      }
      const newPlan = data.plan === "premium" ? "premium" : "plus";
      setCurrentUser({ name: data.user.name, plan: data.user.plan, points: data.user.points });
      triggerToast(`🎉 Upgraded to ${newPlan.toUpperCase()}! Enjoy your premium features.`);
    } catch (e: any) {
      triggerToast(e?.message || "Failed to buy plan");
    } finally {
      setBuying(null);
    }
  };

  // Demo profile for the Achievements display
  const demoProfile = {
    level: 35,
    streak: 125,
    messagesSent: 5000,
    imagesGenerated: 500,
  };

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setShowToast(true);
  };

  return (
    <main className="relative min-h-screen overflow-x-hidden text-white">
      <GradientBackground />
      <FloatingParticles />

      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-blue-500 text-black shadow-lg shadow-amber-500/30">
              <Crown className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-extrabold tracking-tight">
                ChatVerse <span className="text-amber-400">Premium</span>
              </div>
              <div className="text-[10px] text-slate-400">by Mohammed Zayyan</div>
            </div>
          </Link>

          <div className="hidden items-center gap-6 text-sm font-medium text-slate-300 md:flex">
            <a href="#plans" className="transition-colors hover:text-amber-400">Plans</a>
            <a href="#features" className="transition-colors hover:text-amber-400">Features</a>
            <a href="#achievements" className="transition-colors hover:text-amber-400">Rewards</a>
            <a href="#testimonials" className="transition-colors hover:text-amber-400">Reviews</a>
            <a href="#faq" className="transition-colors hover:text-amber-400">FAQ</a>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="hidden rounded-xl px-4 py-2 text-sm font-semibold text-slate-300 transition-colors hover:text-white sm:block"
            >
              Back to Chat
            </Link>
            <button
              onClick={() => document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth' })}
              className="rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 px-4 py-2 text-sm font-bold text-black shadow-lg shadow-amber-500/30 transition-transform hover:scale-105"
            >
              See Plans
            </button>
          </div>
        </div>
      </nav>

      <SuccessToast show={showToast} message={toastMsg} onClose={() => setShowToast(false)} />

      {/* ============================== HERO ============================== */}
      <section className="relative mx-auto max-w-7xl px-4 pb-12 pt-20 text-center sm:px-6 sm:pt-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={loaded ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          {/* Premium badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/10 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-amber-300 backdrop-blur-xl">
            <motion.span
              animate={{ scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="h-3.5 w-3.5" />
            </motion.span>
            Premium Experience · 2026
          </div>

          {/* Animated crown */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0, rotate: -10 }}
            animate={loaded ? { scale: 1, opacity: 1, rotate: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="relative mx-auto mb-8 flex h-24 w-24 items-center justify-center"
          >
            <motion.div
              animate={{ boxShadow: [
                "0 0 30px rgba(251,191,36,0.5)",
                "0 0 60px rgba(251,191,36,0.8)",
                "0 0 30px rgba(251,191,36,0.5)",
              ] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute inset-0 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 opacity-40 blur-2xl"
            />
            <div className="relative flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-amber-300 via-amber-400 to-yellow-600 shadow-2xl shadow-amber-500/40">
              <Crown className="h-12 w-12 text-black" />
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mx-auto max-w-4xl text-balance text-5xl font-black leading-tight tracking-tight sm:text-7xl"
          >
            {isPremiumUser ? (
              <>Welcome back, <span className="bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-500 bg-clip-text text-transparent">Premium Member</span></>
            ) : (
              <>Unlock <span className="bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-500 bg-clip-text text-transparent">AI Premium</span></>
            )}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mx-auto mt-5 max-w-2xl text-lg text-slate-300 sm:text-xl"
          >
            {isPremiumUser
              ? `You're on the ${currentUser?.plan?.toUpperCase()} plan — enjoy unlimited messages, cheaper points, premium animations, and exclusive tools.`
              : "Experience the most powerful version of our AI — unlimited generation, voice, vision, agents, and a complete creative suite, in one futuristic premium experience."}
          </motion.p>

          {/* Premium-only welcome banner — shown only for premium users */}
          {isPremiumUser && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={loaded ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="mx-auto mt-5 flex max-w-md items-center gap-3 rounded-2xl border border-amber-400/40 bg-gradient-to-r from-amber-500/15 to-blue-500/10 px-5 py-3 backdrop-blur-xl"
            >
              <Crown className="h-5 w-5 shrink-0 text-amber-300" />
              <div className="text-sm">
                <span className="font-bold text-amber-200">{currentUser?.plan?.toUpperCase()} ACTIVE</span>
                <span className="ml-2 text-slate-300">{currentUser?.points.toLocaleString()} pts · unlimited messages</span>
              </div>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            {isPremiumUser ? (
              <>
                <Link
                  href="/"
                  className="group relative overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 px-8 py-3.5 text-base font-extrabold text-white shadow-2xl shadow-cyan-500/30 transition-transform hover:scale-105"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <Rocket className="h-5 w-5" />
                    Open Premium Chat
                  </span>
                  <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
                </Link>
                <Link
                  href="/dashboard"
                  className="rounded-2xl border border-white/20 bg-white/[0.05] px-8 py-3.5 text-base font-bold text-white backdrop-blur-xl transition-colors hover:bg-white/[0.1]"
                >
                  Premium Dashboard
                </Link>
              </>
            ) : (
              <>
                <button
                  onClick={() => document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth' })}
                  className="group relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 px-8 py-3.5 text-base font-extrabold text-black shadow-2xl shadow-amber-500/30 transition-transform hover:scale-105"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <Rocket className="h-5 w-5" />
                    Upgrade with points
                  </span>
                  <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
                </button>
                <Link
                  href="/"
                  className="rounded-2xl border border-white/20 bg-white/[0.05] px-8 py-3.5 text-base font-bold text-white backdrop-blur-xl transition-colors hover:bg-white/[0.1]"
                >
                  Back to Chat
                </Link>
              </>
            )}
          </motion.div>

          {/* security badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={loaded ? { opacity: 1 } : {}}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400"
          >
            <span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-emerald-400" /> SSL Secured</span>
            <span className="inline-flex items-center gap-1.5"><Lock className="h-4 w-4 text-emerald-400" /> GDPR Compliant</span>
            <span className="inline-flex items-center gap-1.5"><BadgeCheck className="h-4 w-4 text-amber-400" /> 7-day Money-back</span>
            <span className="inline-flex items-center gap-1.5"><Server className="h-4 w-4 text-blue-400" /> 99.9% Uptime SLA</span>
          </motion.div>
        </motion.div>
      </section>

      {/* ============================== STATS ============================== */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4">
          <StatCounter value={platformStats ? platformStats.totalUsers : null} label="Total Registered Users" icon={Users} />
          <StatCounter value={platformStats ? platformStats.online : null} label="Active Users Right Now" icon={MessageSquare} />
          <StatCounter value={platformStats ? platformStats.premiumMembers : null} label="Premium Members" icon={Crown} />
          <StatCounter value={platformStats ? platformStats.totalPoints : null} label="Total AI Points" icon={Coins} />
        </div>
      </section>

      {/* ============================== PLANS ============================== */}
      {/* Premium users already have a plan — hide the plans section, show a "your active plan" card instead */}
      {isPremiumUser ? (
        <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={loaded ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="overflow-hidden rounded-3xl border border-amber-400/40 bg-gradient-to-br from-amber-500/15 via-transparent to-blue-500/15 p-8 text-center backdrop-blur-xl"
          >
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-black shadow-2xl shadow-amber-500/40"
            >
              <Crown className="h-8 w-8" />
            </motion.div>
            <h2 className="text-2xl font-black tracking-tight sm:text-3xl">
              You're a <span className="bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">{currentUser?.plan?.toUpperCase()} Member</span>
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-slate-300">
              Enjoy unlimited messages, cheaper points, premium button animations, video generation, and the context panel — all unlocked.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: 'Plan', value: currentUser?.plan?.toUpperCase() },
                { label: 'Points', value: currentUser?.points.toLocaleString() },
                { label: 'Msg cost', value: currentUser?.plan === 'premium' ? '1 pt' : '2 pts' },
                { label: 'Daily limit', value: '∞' },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-center">
                  <div className="text-xl font-black text-white">{s.value}</div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">{s.label}</div>
                </div>
              ))}
            </div>
            <Link
              href="/"
              className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-cyan-500/30 transition-transform hover:scale-105"
            >
              <Rocket className="h-4 w-4" /> Open Chat
            </Link>
          </motion.div>
        </section>
      ) : (
      <section id="plans" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="Pricing"
          title="Choose your Premium plan"
          subtitle="Buy premium with AI Points — earned by chatting or gifted by Mohammed Zayyan. One-time purchase, no real money."
        />

        {/* Current user balance card */}
        <div className="mx-auto mt-7 flex max-w-fit items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-2.5 text-sm backdrop-blur-xl">
          <Coins className="h-5 w-5 text-amber-400" />
          <span className="text-slate-300">
            Your balance:
            <span className="ml-1.5 font-extrabold text-amber-300">
              {currentUser ? currentUser.points.toLocaleString() : "—"} pts
            </span>
          </span>
          {currentUser && (
            <span className="rounded-full bg-blue-500/15 px-2 py-0.5 text-[10px] font-bold uppercase text-blue-300">
              {currentUser.plan}
            </span>
          )}
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {PLANS.map((plan) => (
            <PlanCard
              key={plan.id}
              plan={plan}
              onBuy={buyPlan}
              buying={buying}
              currentPoints={currentUser?.points ?? 0}
              currentPlan={currentUser?.plan ?? null}
            />
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="#compare"
            className="rounded-2xl px-7 py-3 text-sm font-semibold text-amber-300 hover:text-amber-200"
          >
            Compare Plans →
          </a>
        </div>
        <p className="mt-6 text-center text-xs text-slate-400">
          Don't have enough points? Chat more to earn them — or ask Mohammed Zayyan to gift you points.
        </p>
      </section>
      )}

      {/* ============================== EXTRA PREMIUM FEATURES ============================== */}
      <section id="features" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="Creative Suite"
          title="Extra premium tools"
          subtitle="A full creative agency inside one AI — generate, design, build, and ship."
        />
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-9">
          {EXTRA_FEATURES.map((f, i) => (
            <motion.div
              key={f.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              whileHover={{ y: -6 }}
              className="group flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-center backdrop-blur-xl transition-colors hover:border-white/25"
            >
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${f.color} text-white shadow-lg transition-transform duration-300 group-hover:scale-110`}>
                <f.icon className="h-6 w-6" />
              </div>
              <div className="text-sm font-semibold text-slate-100">{f.name}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ============================== ACHIEVEMENTS ============================== */}
      <section id="achievements" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="Rewards"
          title="Achievements system"
          subtitle="Level up, keep streaks, earn AI Coins, and unlock exclusive premium badges."
        />

        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {ACHIEVEMENTS.map((a, i) => (
            <motion.div
              key={a.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
              whileHover={{ y: -6, scale: 1.04 }}
              className="flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-center backdrop-blur-xl"
            >
              <div className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${a.color} text-white shadow-lg`}>
                <a.icon className="h-6 w-6" />
              </div>
              <div className="text-sm font-semibold text-slate-100">{a.name}</div>
            </motion.div>
          ))}
        </div>

        {/* Demo profile */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mt-10 overflow-hidden rounded-3xl border border-amber-400/30 bg-gradient-to-br from-amber-500/10 via-transparent to-blue-500/10 p-6 backdrop-blur-2xl sm:p-10"
        >
          <div className="mb-6 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-2xl font-black text-black shadow-lg shadow-amber-500/30">
                ZA
              </div>
              <div>
                <div className="text-lg font-extrabold">Zayyan A.</div>
                <div className="flex items-center gap-1.5 text-xs text-amber-300">
                  <Crown className="h-3.5 w-3.5" /> Premium Member
                </div>
              </div>
            </div>
            <div className="rounded-full border border-amber-400/40 bg-amber-500/15 px-3 py-1 text-xs font-bold text-amber-300">
              Level {demoProfile.level}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <DemoStat icon={Flame} label="Day Streak" value={demoProfile.streak} color="from-orange-400 to-red-500" />
            <DemoStat icon={MessageSquare} label="Messages Sent" value={demoProfile.messagesSent} color="from-blue-400 to-indigo-500" />
            <DemoStat icon={ImageIcon} label="Images Generated" value={demoProfile.imagesGenerated} color="from-amber-400 to-yellow-500" />
            <DemoStat icon={Coins} label="AI Coins" value={2840} color="from-yellow-400 to-amber-500" />
          </div>

          {/* XP bar */}
          <div className="mt-6">
            <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
              <span>Level {demoProfile.level} → Level {demoProfile.level + 1}</span>
              <span>7,840 / 10,000 XP</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
              <motion.div
                initial={{ width: 0 }}
                whileInView={{ width: "78%" }}
                viewport={{ once: true }}
                transition={{ duration: 1.4, ease: "easeOut" }}
                className="h-full rounded-full bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 shadow-lg shadow-amber-500/40"
              />
            </div>
          </div>
        </motion.div>
      </section>

      {/* ============================== COMPARE TABLE ============================== */}
      <section id="compare" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="Compare"
          title="Free vs Premium vs Premium Plus"
          subtitle="See exactly what you unlock at each tier."
        />
        <div className="mt-10 overflow-x-auto rounded-3xl border border-white/10 bg-white/[0.02] backdrop-blur-xl">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-slate-300">
                <th className="p-5 font-semibold">Feature</th>
                <th className="p-5 text-center font-semibold text-slate-400">Free</th>
                <th className="p-5 text-center font-semibold text-amber-300">Premium</th>
                <th className="p-5 text-center font-semibold text-blue-300">Premium Plus</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Messages per day", "50", "Unlimited", "Unlimited"],
                ["Image generation", "—", "✓", "✓ Multi-image"],
                ["Video generation", "—", "—", "✓"],
                ["Voice chat + TTS/STT", "—", "✓", "✓"],
                ["Real-time news & weather", "—", "✓", "✓"],
                ["AI Agents", "—", "—", "✓"],
                ["Custom AI training", "—", "—", "✓"],
                ["Team workspace", "—", "—", "✓"],
                ["API access", "—", "—", "✓"],
                ["Cloud sync + private memory", "—", "—", "✓"],
                ["Priority servers", "—", "✓", "✓"],
                ["Premium support", "Community", "Premium", "Priority 24/7"],
              ].map((row, i) => (
                <tr key={i} className="border-b border-white/5 last:border-0">
                  <td className="p-5 font-medium text-slate-200">{row[0]}</td>
                  <td className="p-5 text-center text-slate-400">{row[1]}</td>
                  <td className="p-5 text-center font-semibold text-amber-200">{row[2]}</td>
                  <td className="p-5 text-center font-semibold text-blue-200">{row[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ============================== TESTIMONIALS ============================== */}
      <section id="testimonials" className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="Loved by users"
          title="What our members say"
          subtitle="100,000+ users upgraded — here's why."
        />
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="flex flex-col gap-4 rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl"
            >
              <div className="flex gap-1">
                {Array.from({ length: t.rating }).map((_, s) => (
                  <Star key={s} className="h-4 w-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="flex-1 text-sm leading-relaxed text-slate-200">{t.text}</p>
              <div className="flex items-center gap-3 border-t border-white/10 pt-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-blue-500 text-sm font-bold text-black">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">{t.name}</div>
                  <div className="text-xs text-slate-400">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ============================== FAQ ============================== */}
      <section id="faq" className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <SectionHeading
          kicker="FAQ"
          title="Frequently asked questions"
          subtitle="Everything you need to know before you upgrade."
        />
        <div className="mt-8 space-y-3">
          {FAQS.map((f, i) => (
            <FaqItem key={i} q={f.q} a={f.a} idx={i} />
          ))}
        </div>
      </section>

      {/* ============================== FINAL CTA ============================== */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="relative overflow-hidden rounded-[2.5rem] border border-amber-400/30 bg-gradient-to-br from-amber-500/15 via-slate-900/40 to-blue-500/15 p-10 text-center backdrop-blur-2xl sm:p-16"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-gradient-to-br from-amber-400/30 to-transparent blur-3xl"
          />
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
            className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-gradient-to-br from-blue-500/30 to-transparent blur-3xl"
          />
          <div className="relative z-10">
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 text-black shadow-2xl shadow-amber-500/40"
            >
              <Crown className="h-8 w-8" />
            </motion.div>
            <h2 className="text-3xl font-black tracking-tight sm:text-5xl">
              Ready to unlock <span className="bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">Premium?</span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-base text-slate-300">
              Join 100,000+ members using the most powerful AI experience built by Mohammed Zayyan. Buy with AI Points — no real money.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                onClick={() => document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth' })}
                className="group relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 px-8 py-3.5 text-base font-extrabold text-black shadow-2xl shadow-amber-500/40 transition-transform hover:scale-105"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Rocket className="h-5 w-5" /> Upgrade with points
                </span>
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
              </button>
              <Link
                href="/"
                className="rounded-2xl border border-white/20 bg-white/[0.05] px-8 py-3.5 text-base font-bold text-white backdrop-blur-xl hover:bg-white/[0.1]"
              >
                Back to Chat
              </Link>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ============================== FOOTER ============================== */}
      <footer className="border-t border-white/10 bg-black/40 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 text-sm text-slate-400 sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <Crown className="h-4 w-4 text-amber-400" />
            <span>ChatVerse Premium · built by Mohammed Zayyan</span>
          </div>
          <div className="flex gap-5">
            <a href="#plans" className="hover:text-amber-300">Plans</a>
            <a href="#features" className="hover:text-amber-300">Features</a>
            <a href="#faq" className="hover:text-amber-300">FAQ</a>
            <Link href="/" className="hover:text-amber-300">Chat</Link>
          </div>
        </div>
      </footer>
    </main>
  );
}

/* ----------------------- Helper components ----------------------- */
function SectionHeading({ kicker, title, subtitle }: {
  kicker: string; title: string; subtitle: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5 }}
      className="text-center"
    >
      <div className="inline-block rounded-full border border-amber-400/30 bg-amber-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-amber-300">
        {kicker}
      </div>
      <h2 className="mx-auto mt-4 max-w-2xl text-3xl font-black tracking-tight sm:text-4xl">{title}</h2>
      <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-400 sm:text-base">{subtitle}</p>
    </motion.div>
  );
}

function DemoStat({ icon: Icon, label, value, color }: {
  icon: any; label: string; value: number; color: string;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const count = useCountUp(value, inView, 1500);
  return (
    <div ref={ref} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
      <div className={`mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br ${color} text-white`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="text-2xl font-extrabold tracking-tight text-white">
        {Math.floor(count).toLocaleString()}
      </div>
      <div className="text-xs text-slate-400">{label}</div>
    </div>
  );
}
