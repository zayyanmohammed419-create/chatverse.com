"use client";

import { useEffect, useState } from "react";
import { Download } from "lucide-react";

/**
 * InstallAppButton — shows an "Install App" button when the browser fires
 * `beforeinstallprompt` (Chrome on Android, Edge on desktop). When clicked,
 * it triggers the native install prompt, installing ChatVerse as a PWA with
 * the correct logo, name, and standalone display mode.
 *
 * On iOS Safari (which doesn't fire `beforeinstallprompt`), we show a hint
 * telling the user to use Share → Add to Home Screen.
 */
export default function InstallAppButton({ compact = false }: { compact?: boolean }) {
  const [promptEvent, setPromptEvent] = useState<any>(null);
  const [installed, setInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Detect iOS Safari (no beforeinstallprompt event on iOS)
    const ua = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(ua) && !(window as any).MSStream;
    Promise.resolve().then(() => {
      setIsIOS(isIOSDevice);
      // Check if already installed
      if (window.matchMedia("(display-mode: standalone)").matches) {
        setInstalled(true);
      }
    });

    const onBeforeInstall = (e: any) => {
      e.preventDefault();
      setPromptEvent(e);
    };
    const onInstalled = () => {
      setInstalled(true);
      setPromptEvent(null);
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const handleInstall = async () => {
    if (!promptEvent) return;
    promptEvent.prompt();
    const { outcome } = await promptEvent.userChoice;
    if (outcome === "accepted") {
      setInstalled(true);
    }
    setPromptEvent(null);
  };

  // Already installed — don't show the button
  if (installed) return null;

  // iOS — show a "Add to Home Screen" hint button (can't auto-install on iOS)
  if (isIOS) {
    return (
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          alert("To install ChatVerse on iOS:\n\n1. Tap the Share button (square with up arrow) at the bottom of Safari.\n2. Scroll down and tap 'Add to Home Screen'.\n3. Tap 'Add'.\n\nChatVerse will appear on your home screen with the correct logo!")
        }}
        className={`flex items-center gap-1.5 rounded-xl border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-xs font-bold text-cyan-200 transition hover:bg-cyan-500/20 ${compact ? 'h-8' : 'h-10'}`}
        title="Install on iOS"
      >
        <Download className="h-3.5 w-3.5" />
        {!compact && <span>Add to Home Screen</span>}
        {compact && <span className="hidden sm:inline">Install</span>}
      </a>
    );
  }

  // Android / desktop Chrome / Edge — show the install button only when the prompt is available
  if (!promptEvent) return null;
  return (
    <button
      onClick={handleInstall}
      className={`flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 px-3 py-2 text-xs font-bold text-white shadow-lg shadow-cyan-500/30 transition-transform hover:scale-105 ${compact ? 'h-8' : 'h-10'}`}
      title="Install ChatVerse AI as an app"
    >
      <Download className="h-3.5 w-3.5" />
      {!compact && <span>Install App</span>}
      {compact && <span className="hidden sm:inline">Install</span>}
    </button>
  );
}
