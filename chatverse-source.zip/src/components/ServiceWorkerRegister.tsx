"use client";

import { useEffect, useState } from "react";

/**
 * ServiceWorkerRegister — client component that registers the service worker
 * for PWA install + offline support. Also captures the `beforeinstallprompt`
 * event so we can show an "Install App" button to the user.
 */

// Globally expose the deferred prompt so the InstallButton component can access it
let deferredPrompt: any = null;
export function getInstallPrompt() { return deferredPrompt; }
export function clearInstallPrompt() { deferredPrompt = null; }

export default function ServiceWorkerRegister() {
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;

    // Register the service worker
    const register = () => {
      navigator.serviceWorker.register("/sw.js").then((reg) => {
        console.log("[ChatVerse] Service Worker registered:", reg.scope);
      }).catch((err) => {
        console.warn("[ChatVerse] Service Worker registration failed:", err);
      });
    };
    if (document.readyState === "complete") register();
    else window.addEventListener("load", register);

    // Capture the install prompt (fired by Chrome on Android + Edge desktop)
    const onBeforeInstall = (e: any) => {
      e.preventDefault();
      deferredPrompt = e;
      console.log("[ChatVerse] Install prompt captured — user can install via the Install button");
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);

    // Detect if already installed (running as standalone PWA)
    const onInstalled = () => {
      setInstalled(true);
      deferredPrompt = null;
      console.log("[ChatVerse] App installed to home screen");
    };
    window.addEventListener("appinstalled", onInstalled);
    if (window.matchMedia("(display-mode: standalone)").matches) {
      Promise.resolve().then(() => setInstalled(true));
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  return null;
}
